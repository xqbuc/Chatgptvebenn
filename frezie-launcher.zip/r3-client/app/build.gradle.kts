plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.sneinle.client"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.sneinle.client"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    packaging {
        resources {
            excludes += setOf(
                "META-INF/INDEX.LIST", "META-INF/DEPENDENCIES", "META-INF/LICENSE*", "META-INF/NOTICE*",
                "META-INF/AL2.0", "META-INF/LGPL2.1", "META-INF/*.kotlin_module", "META-INF/versions/**",
                "META-INF/license/**", "META-INF/native-image/**", "**/module-info.class"
            )
            pickFirsts += setOf("META-INF/io.netty.versions.properties")
        }
    }
}
// CloudburstMC surumu workflow tarafindan -Pcbv=... ile (en yeni snapshot) verilir.
val cbv = (project.findProperty("cbv") as String?) ?: "3.0.0.Beta5-SNAPSHOT"
dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("org.cloudburstmc.protocol:bedrock-codec:$cbv")
    implementation("org.cloudburstmc.protocol:bedrock-connection:$cbv")
    implementation("net.raphimc:MinecraftAuth:5.0.2")
    implementation("com.google.code.gson:gson:2.11.0")
    implementation("app.cash.quickjs:quickjs-android:0.9.2")
}
