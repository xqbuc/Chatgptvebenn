import { defineModule } from "@protohax/userscript";

// r3-client AndromedaBridge: scaffold gibi, ayagin altina ve ilerisine otomatik blok koyar.
const say = (ctx, message) => {
  try {
    ctx.session.connection.sendIncomingPacket("text", {
      type: "raw", needs_translation: false, message,
      xuid: "", platform_chat_id: "", has_filtered_message: false,
    });
  } catch (e) { console.log(message); }
};

const FACE = [
  { d: [0, -1, 0], f: 1 }, // altindaki blogun ust yuzu
  { d: [0, 1, 0], f: 0 },
  { d: [0, 0, -1], f: 3 },
  { d: [0, 0, 1], f: 2 },
  { d: [-1, 0, 0], f: 5 },
  { d: [1, 0, 0], f: 4 },
];

defineModule(
  { name: "AndromedaBridge", defaultState: false, description: "Otomatik kopru / scaffold" },
  {
    delay: { type: "number", name: "Blok Gecikmesi (tick)", def: 1, min: 1, max: 10, step: 1 },
    ahead: { type: "number", name: "Ileri Tahmin (tick)", def: 2, min: 0, max: 8, step: 1 },
    perTick: { type: "number", name: "Tick Basina Max Blok", def: 1, min: 1, max: 4, step: 1 },
    extend: { type: "number", name: "Ek Genisleme (blok)", def: 0, min: 0, max: 4, step: 1 },
    onlyWhenBlock: { type: "boolean", name: "Sadece Blok Elde", def: true },
    onlyWhenMoving: { type: "boolean", name: "Sadece Hareket Ederken", def: false },
    keepY: { type: "boolean", name: "Y Seviyesini Koru (duz kopru)", def: false },
    tower: { type: "boolean", name: "Ziplayinca Yukari Kule Yap", def: true },
    towerSpeed: { type: "number", name: "Kule Hizi", def: 0.42, min: 0.2, max: 0.6, step: 0.02 },
    swing: { type: "boolean", name: "Kol Salla", def: true },
    pauseOnContainer: { type: "boolean", name: "Envanter Acikken Dur", def: true },
    debug: { type: "boolean", name: "Debug Mesajlari", def: false },
  },
  (ctx) => {
    let tick = 0, offset = null, lastY = null, containerOpen = false, warned = false;

    ctx.onEnable(() => { tick = 0; offset = null; lastY = null; warned = false; });
    ctx.onPacket("transfer", () => { offset = null; lastY = null; });
    ctx.on("container_open", () => { containerOpen = true; });
    ctx.on("container_close", () => { containerOpen = false; });

    const blockName = (x, y, z) => {
      try {
        const b = ctx.session.levelState.getBlock(x, y, z);
        return b && b.name ? b.name : "";
      } catch (_) { return ""; }
    };
    const solid = (x, y, z) => {
      const n = blockName(x, y, z);
      return n !== "" && !n.includes("air") && !n.includes("water") && !n.includes("lava");
    };
    const replaceable = (x, y, z) => {
      const n = blockName(x, y, z);
      return n === "" ? false : (n.includes("air") || n.includes("water") || n.includes("lava") || n.includes("grass") && !n.includes("block"));
    };

    function holdingBlock(p) {
      try {
        const n = String(p.inventory?.hand?.name ?? p.inventory?.hand?.identifier ?? "");
        if (n === "") return false;
        const tools = ["sword", "pickaxe", "axe", "shovel", "hoe", "bow", "rod", "spear", "trident", "shield", "apple", "bread", "potion", "pearl", "elytra", "mace"];
        return !tools.some((t) => n.includes(t));
      } catch (_) { return true; }
    }

    // Surume gore degisen yerlestirme fonksiyonlari denenir.
    function place(p, sx, sy, sz, face) {
      const tries = [
        () => p.placeBlock({ x: sx, y: sy, z: sz }, face),
        () => p.placeBlock(sx, sy, sz, face),
        () => p.interactBlock({ x: sx, y: sy, z: sz }, face),
        () => p.useItemOn({ x: sx, y: sy, z: sz }, face),
        () => ctx.session.levelState.placeBlock({ x: sx, y: sy, z: sz }, face),
      ];
      const names = ["placeBlock", "placeBlock", "interactBlock", "useItemOn", null];
      for (let i = 0; i < tries.length; i++) {
        if (names[i] && typeof p[names[i]] !== "function") continue;
        if (!names[i] && typeof ctx.session.levelState.placeBlock !== "function") continue;
        try { tries[i](); return true; } catch (_) {}
      }
      return false;
    }

    function support(x, y, z) {
      for (const f of FACE) {
        const nx = x + f.d[0], ny = y + f.d[1], nz = z + f.d[2];
        if (solid(nx, ny, nz)) return { x: nx, y: ny, z: nz, face: f.f };
      }
      return null;
    }

    ctx.on("movement_tick", (state) => {
      try {
        const o = ctx.options;
        const p = ctx.session?.entityState?.localPlayer;
        if (!p) return;
        tick++;
        if (o.pauseOnContainer.value && containerOpen) return;
        if (o.onlyWhenBlock.value && !holdingBlock(p)) return;
        if (o.onlyWhenMoving.value && !state.isMoving && !state.isJumping) return;

        const pos = state.position;
        // konum goz hizasinda mi ayak hizasinda mi: yerdeyken otomatik anla
        if (offset === null && state.onGround) {
          for (const off of [0, 1.62]) {
            if (solid(Math.floor(pos.x), Math.floor(pos.y - off - 0.01), Math.floor(pos.z))) { offset = off; break; }
          }
        }
        const off = offset ?? 0;
        const feetY = pos.y - off;

        if (o.tower.value && state.isJumping && !state.isMoving && state.motion.y < o.towerSpeed.value && state.motion.y > -0.1) {
          state.setMotion({ x: 0, y: o.towerSpeed.value, z: 0 });
        }
        if (tick % o.delay.value !== 0) return;

        if (o.keepY.value) { if (lastY === null || state.onGround && !state.isJumping) lastY = Math.floor(feetY - 0.01); }
        else lastY = null;

        const m = state.motion;
        const aheadN = o.ahead.value;
        const baseX = pos.x + m.x * aheadN;
        const baseZ = pos.z + m.z * aheadN;
        const ty = lastY !== null ? lastY : Math.floor(feetY - 0.01);

        const spots = [[Math.floor(pos.x), ty, Math.floor(pos.z)], [Math.floor(baseX), ty, Math.floor(baseZ)]];
        const ex = o.extend.value;
        if (ex > 0) {
          const len = Math.hypot(m.x, m.z) || 1;
          for (let i = 1; i <= ex; i++) spots.push([Math.floor(baseX + (m.x / len) * i), ty, Math.floor(baseZ + (m.z / len) * i)]);
        }

        let placed = 0;
        for (const [x, y, z] of spots) {
          if (placed >= o.perTick.value) break;
          if (solid(x, y, z) || !replaceable(x, y, z)) continue;
          const s = support(x, y, z);
          if (!s) continue;
          if (!place(p, s.x, s.y, s.z, s.face)) {
            if (!warned) { warned = true; say(ctx, "§c[AndromedaBridge]§r bu surumde blok koyma fonksiyonu bulunamadi"); }
            return;
          }
          placed++;
          if (o.debug.value) say(ctx, "§b[Bridge]§r " + x + "," + y + "," + z);
        }
        if (placed > 0 && o.swing.value) p.swingItem();
      } catch (_) {}
    });
  }
);
