// AntiAFK — belirli aralıklarla kol sallar / zıplar / bakışı oynatır, AFK atılmanı geciktirir.
import { defineModule, utils } from "@protohax/userscript";

const N = (name, def, min, max, step) => ({ type: "number", name, def, min, max, step });
const B = (name, def) => ({ type: "boolean", name, def });
const say = (ctx, message) => {
  try {
    ctx.session.connection.sendIncomingPacket("text", {
      type: "raw", needs_translation: false, message,
      xuid: "", platform_chat_id: "", has_filtered_message: false,
    });
  } catch (e) { console.log(message); }
};

defineModule(
  { name: "AntiAFK" },
  {
    seconds: N("Interval (s)", 30, 5, 120, 5),
    random: N("Interval Randomness (+s)", 0, 0, 60, 1),
    swing: B("Swing Arm", true),
    jump: B("Jump", false),
    look: B("Wiggle Camera", false),
    lookAmount: N("Camera Wiggle (deg)", 8, 1, 45, 1),
    sneak: B("Tap Sneak", false),
    sneakTicks: N("Sneak Duration (ticks)", 4, 1, 20, 1),
    swingCount: N("Swings Per Action", 1, 1, 10, 1),
    onlyStill: B("Only When Standing Still", true),
    minHealth: N("Skip Below Health (0 = off)", 0, 0, 20, 1),
    // --- yeni ayarlar ---
    startDelay: N("Start Delay (s)", 0, 0, 120, 1),
    idleNeeded: N("Idle Time Needed (s, 0 = off)", 0, 0, 300, 5),
    pitchAmount: N("Pitch Wiggle (deg)", 0, 0, 30, 1),
    lookDur: N("Wiggle Duration (ticks)", 10, 4, 60, 2),
    lookRandom: N("Wiggle Amount Randomness (%)", 0, 0, 100, 5),
    jumpCount: N("Jumps Per Action", 1, 1, 5, 1),
    jumpGap: N("Gap Between Jumps (ticks)", 6, 2, 30, 1),
    sneakTaps: N("Sneak Taps Per Action", 1, 1, 6, 1),
    nudge: B("Tiny Walk Nudge", false),
    nudgePower: N("Nudge Power", 0.08, 0.01, 0.4, 0.01),
    randomAction: B("Pick One Random Action", false),
    chance: N("Action Chance (%)", 100, 1, 100, 1),
    burstActions: N("Actions Per Interval", 1, 1, 5, 1),
    maxActions: N("Stop After Actions (0 = off)", 0, 0, 1000, 10),
    chat: B("Chat Feedback", false),
  },
  (ctx) => {
    let ticks = 0, limit = 0, wantJump = 0, jumpWait = 0, sneakQueue = 0, sneakOn = 0, sneakOff = 0;
    let lookLeft = 0, lookTotal = 10, lookScale = 1, nudgeLeft = 0, nudgeDir = 0, idle = 0, elapsed = 0, done = 0;
    const me = () => ctx.session.entityState.localPlayer;
    const roll = () => { limit = (ctx.options.seconds.value + Math.random() * ctx.options.random.value) * 20; };

    ctx.onEnable(() => { ticks = 0; wantJump = 0; jumpWait = 0; sneakQueue = 0; sneakOn = 0; sneakOff = 0; lookLeft = 0; nudgeLeft = 0; idle = 0; elapsed = 0; done = 0; roll(); });
    ctx.onDisable(() => me().rotationScheduler.cancel(ctx));
    ctx.on("input_tick", (input) => {
      if (sneakOn > 0) { sneakOn--; input.setSneak(true); if (sneakOn === 0 && sneakQueue > 0) sneakOff = 2; return; }
      if (sneakOff > 0) { sneakOff--; return; }
      if (sneakQueue > 0) { sneakQueue--; sneakOn = ctx.options.sneakTicks.value; input.setSneak(true); sneakOn--; }
    });
    ctx.on("movement_tick", (state) => {
      const o = ctx.options;
      idle = state.isMoving ? 0 : idle + 1;
      if (jumpWait > 0) jumpWait--;
      if (wantJump > 0 && jumpWait === 0 && state.onGround) { wantJump--; state.jump(); jumpWait = o.jumpGap.value; }
      if (nudgeLeft > 0) {
        nudgeLeft--;
        state.addMotion({ x: Math.cos(nudgeDir) * o.nudgePower.value, y: 0, z: Math.sin(nudgeDir) * o.nudgePower.value });
      }
      if (lookLeft > 0) {
        lookLeft--;
        if (lookLeft === 0) { me().rotationScheduler.cancel(ctx); return; }
        const sgn = lookLeft > lookTotal / 2 ? 1 : -1;
        const step = (sgn * lookScale) / (lookTotal / 2);
        me().rotationScheduler.request(
          new utils.Vector2(state.rotation.x + step * o.pitchAmount.value, state.rotation.y + step * o.lookAmount.value),
          utils.SchedulerPriority.Low, ctx, 3);
      }
    });
    ctx.on("tick", () => {
      const o = ctx.options;
      elapsed++;
      if (elapsed < o.startDelay.value * 20) return;
      if (++ticks < limit) return;
      ticks = 0; roll();
      if (o.onlyStill.value && idle === 0) return;
      if (o.idleNeeded.value > 0 && idle < o.idleNeeded.value * 20) return;
      if (o.minHealth.value > 0 && me().health <= o.minHealth.value) return;
      if (o.maxActions.value > 0 && done >= o.maxActions.value) return;
      if (Math.random() * 100 >= o.chance.value) return;
      for (let a = 0; a < o.burstActions.value; a++) {
        const acts = [];
        if (o.swing.value) acts.push("swing");
        if (o.jump.value) acts.push("jump");
        if (o.sneak.value) acts.push("sneak");
        if (o.look.value) acts.push("look");
        if (o.nudge.value) acts.push("nudge");
        const run = o.randomAction.value && acts.length ? [acts[Math.floor(Math.random() * acts.length)]] : acts;
        for (const act of run) {
          if (act === "swing") for (let i = 0; i < o.swingCount.value; i++) me().swingItem("AntiAFK");
          if (act === "jump") wantJump += o.jumpCount.value;
          if (act === "sneak") sneakQueue += o.sneakTaps.value;
          if (act === "look") { lookTotal = o.lookDur.value; lookLeft = lookTotal; lookScale = 1 + (Math.random() * 2 - 1) * (o.lookRandom.value / 100); }
          if (act === "nudge") { nudgeLeft = 3; nudgeDir = Math.random() * Math.PI * 2; }
        }
        done++;
      }
      if (o.chat.value) say(ctx, `§a[AntiAFK]§r aksiyon #${done}`);
    });
  },
);
