import { defineModule } from "@protohax/userscript";

// r3-client ArmorBreaker: elinde ne olursa olsun (yumruk, kilic, kazma...) birine vurdugunda
// ayni hedefe ekstra vuruslar gonderir; zirh parcalari hizla kirilir ya da hedef asiri hasar alir.
const say = (ctx, message) => {
  try {
    ctx.session.connection.sendIncomingPacket("text", {
      type: "raw", needs_translation: false, message,
      xuid: "", platform_chat_id: "", has_filtered_message: false,
    });
  } catch (e) { console.log(message); }
};

// Paketin icinde hedef varligin runtime id'sini bulur (alan adi surume gore degisebilir).
function findTarget(body) {
  const seen = new Set();
  const walk = (o, depth) => {
    if (!o || typeof o !== "object" || depth > 5 || seen.has(o)) return null;
    seen.add(o);
    for (const k of Object.keys(o)) {
      const lk = k.toLowerCase();
      if ((lk === "runtime_entity_id" || lk === "runtimeentityid" || lk === "target_runtime_id") && o[k] !== undefined) return o[k];
    }
    for (const k of Object.keys(o)) { const r = walk(o[k], depth + 1); if (r !== null) return r; }
    return null;
  };
  return walk(body, 0);
}
// Paket bir "varliga vurma" mi?
function isAttack(body) {
  try {
    const s = JSON.stringify(body, (k, v) => (typeof v === "bigint" ? v.toString() : v)).toLowerCase();
    return s.includes("item_use_on_entity") && s.includes("attack");
  } catch (_) { return false; }
}

defineModule(
  { name: "ArmorBreaker", defaultState: false, description: "Vurdugunda hedefin zirhini kirar / asiri hasar verir" },
  {
    mode: { type: "enum", name: "Mod", def: "Zirh Kir", values: ["Zirh Kir", "Asiri Hasar"] },
    breakHits: { type: "number", name: "Zirh Kir: Ekstra Vurus", def: 40, min: 1, max: 400, step: 1 },
    damageHits: { type: "number", name: "Asiri Hasar: Ekstra Vurus", def: 12, min: 1, max: 100, step: 1 },
    perTick: { type: "number", name: "Tick Basina Max Vurus", def: 20, min: 1, max: 100, step: 1 },
    cooldownTicks: { type: "number", name: "Ayni Hedefe Bekleme (tick)", def: 0, min: 0, max: 40, step: 1 },
    swing: { type: "boolean", name: "Kol Salla", def: false },
    chat: { type: "boolean", name: "Sohbette Bildir", def: false },
  },
  (ctx) => {
    let pending = 0, target = null, sending = false, tick = 0, lastBurst = -999, warned = false;
    const conn = () => ctx.session.connection;
    const checker = {
      // Sadece gozlemler, hicbir paketi tutmaz.
      shouldQueue: (name, body, isIncoming) => {
        try {
          if (sending || isIncoming || name !== "inventory_transaction") return false;
          if (!isAttack(body)) return false;
          if (tick - lastBurst < ctx.options.cooldownTicks.value) return false;
          const id = findTarget(body);
          if (id === null) return false;
          target = id;
          pending = ctx.options.mode.value === "Zirh Kir" ? ctx.options.breakHits.value : ctx.options.damageHits.value;
          lastBurst = tick;
        } catch (_) {}
        return false;
      },
    };

    ctx.onEnable(() => {
      pending = 0; target = null; sending = false; tick = 0; lastBurst = -999; warned = false;
      try { conn().addPacketQueueChecker(checker); } catch (_) {
        say(ctx, "§c[ArmorBreaker]§r paket dinleme bu surumde yok");
      }
    });
    ctx.onDisable(() => { pending = 0; target = null; try { conn().removePacketQueueChecker(checker); } catch (_) {} });
    ctx.onPacket("transfer", () => { pending = 0; target = null; });

    ctx.on("tick", () => {
      tick++;
      if (pending <= 0 || target === null) return;
      try {
        const session = ctx.session;
        const p = session.entityState.localPlayer;
        if (!p) return;
        let ent = null;
        for (const e of session.entityState.entities.values()) {
          if (String(e.runtimeId) === String(target)) { ent = e; break; }
        }
        if (!ent || ent === p) { pending = 0; return; }
        const n = Math.min(pending, ctx.options.perTick.value);
        sending = true;
        for (let i = 0; i < n; i++) p.interactEntity(ent, true, p.serverSideRotation, "attack");
        sending = false;
        pending -= n;
        if (ctx.options.swing.value) p.swingItem();
        if (pending <= 0 && ctx.options.chat.value) say(ctx, "§c[ArmorBreaker]§r vurus tamamlandi");
      } catch (_) {
        sending = false;
        if (!warned) { warned = true; say(ctx, "§c[ArmorBreaker]§r ekstra vurus gonderilemedi"); }
        pending = 0;
      }
    });
  }
);
