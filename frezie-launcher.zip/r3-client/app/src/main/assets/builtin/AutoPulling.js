import { defineModule } from "@protohax/userscript";

// r3-client AutoPulling: oltayi eline alinca otomatik atar, delay (ms) sonra ceker, tekrar eder.
const say = (ctx, message) => {
  try {
    ctx.session.connection.sendIncomingPacket("text", {
      type: "raw", needs_translation: false, message,
      xuid: "", platform_chat_id: "", has_filtered_message: false,
    });
  } catch (e) { console.log(message); }
};

// Oyun surumune gore farkli isimlerle kullanma fonksiyonu aranir.
function useItem(p) {
  const names = ["useItem", "useHeldItem", "interactItem", "startUsingItem", "rightClick"];
  for (const n of names) {
    if (typeof p[n] === "function") { try { p[n](); return true; } catch (_) {} }
  }
  return false;
}

defineModule(
  { name: "AutoPulling", defaultState: false, description: "Olta ele alinca otomatik at-cek" },
  {
    castDelay: { type: "number", name: "Cekme Gecikmesi (ms)", def: 600, min: 1, max: 1900, step: 1 },
    recastDelay: { type: "number", name: "Tekrar Atma Gecikmesi (ms)", def: 300, min: 1, max: 1900, step: 1 },
    randomness: { type: "number", name: "Rastgele Sapma (+-ms)", def: 0, min: 0, max: 300, step: 5 },
    onlyWhenRod: { type: "boolean", name: "Sadece Olta Elde", def: true },
    pauseOnContainer: { type: "boolean", name: "Envanter Acikken Dur", def: true },
    chat: { type: "boolean", name: "Sohbet Bildirimi", def: false },
  },
  (ctx) => {
    let state = "idle";   // idle -> cast -> reel
    let nextAt = 0, containerOpen = false, warned = false;

    ctx.onEnable(() => { state = "idle"; nextAt = 0; warned = false; });
    ctx.onDisable(() => { state = "idle"; });
    ctx.on("container_open", () => { containerOpen = true; });
    ctx.on("container_close", () => { containerOpen = false; });

    const jitter = () => (Math.random() * 2 - 1) * ctx.options.randomness.value;
    function holdingRod(p) {
      try {
        const n = String(p.inventory?.hand?.name ?? p.inventory?.hand?.identifier ?? "");
        return n.includes("fishing_rod");
      } catch (_) { return false; }
    }

    ctx.on("tick", () => {
      try {
        const o = ctx.options;
        const session = ctx.session;
        if (!session) return;
        const p = session.entityState.localPlayer;
        if (!p) return;
        if (o.pauseOnContainer.value && containerOpen) return;
        if (o.onlyWhenRod.value && !holdingRod(p)) { state = "idle"; return; }
        const now = Date.now();
        if (now < nextAt) return;

        if (!useItem(p)) {
          if (!warned) { warned = true; say(ctx, "§c[AutoPulling]§r bu surumde esya kullanma fonksiyonu bulunamadi"); }
          return;
        }
        if (state === "cast") {          // olta suan havada -> cek
          state = "reel";
          nextAt = now + Math.max(1, o.recastDelay.value + jitter());
          if (o.chat.value) say(ctx, "§b[AutoPulling]§r cekildi");
        } else {                         // atilacakti
          state = "cast";
          nextAt = now + Math.max(1, o.castDelay.value + jitter());
          if (o.chat.value) say(ctx, "§b[AutoPulling]§r atildi");
        }
      } catch (_) {}
    });
  }
);
