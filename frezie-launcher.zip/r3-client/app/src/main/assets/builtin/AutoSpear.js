import { defineModule } from "@protohax/userscript";

// r3-client AutoSpear: spear (istenirse trident de) eline gecince otomatik ileri firlatir.
const say = (ctx, message) => {
  try {
    ctx.session.connection.sendIncomingPacket("text", {
      type: "raw", needs_translation: false, message,
      xuid: "", platform_chat_id: "", has_filtered_message: false,
    });
  } catch (e) { console.log(message); }
};
const call = (p, names) => {
  for (const n of names) if (typeof p[n] === "function") { try { p[n](); return true; } catch (_) {} }
  return false;
};

defineModule(
  { name: "AutoSpear", defaultState: false, description: "Spear ele gecince otomatik ileri atar" },
  {
    chargeTicks: { type: "number", name: "Sarj Suresi (tick)", def: 12, min: 1, max: 80, step: 1 },
    cooldownMs: { type: "number", name: "Atislar Arasi Bekleme (ms)", def: 400, min: 0, max: 5000, step: 50 },
    includeTrident: { type: "boolean", name: "Trident'i de At", def: true },
    onlyOnGround: { type: "boolean", name: "Sadece Yerdeyken", def: false },
    onlyMoving: { type: "boolean", name: "Sadece Hareket Ederken", def: false },
    pauseOnContainer: { type: "boolean", name: "Envanter Acikken Dur", def: true },
    chat: { type: "boolean", name: "Sohbet Bildirimi", def: false },
  },
  (ctx) => {
    let charging = 0, nextAt = 0, containerOpen = false, warned = false, count = 0;
    let ground = true, moving = false;

    ctx.onEnable(() => { charging = 0; nextAt = 0; warned = false; count = 0; });
    ctx.onDisable(() => {
      if (charging > 0) { try { call(ctx.session.entityState.localPlayer, ["releaseItem", "stopUsingItem"]); } catch (_) {} }
      charging = 0;
    });
    ctx.on("container_open", () => { containerOpen = true; });
    ctx.on("container_close", () => { containerOpen = false; });
    ctx.on("movement_tick", (s) => { ground = s.onGround; moving = s.isMoving; });

    function holdingSpear(p) {
      try {
        const n = String(p.inventory?.hand?.name ?? p.inventory?.hand?.identifier ?? "");
        return n.includes("spear") || (ctx.options.includeTrident.value && n.includes("trident"));
      } catch (_) { return false; }
    }

    ctx.on("tick", () => {
      try {
        const o = ctx.options;
        const p = ctx.session?.entityState?.localPlayer;
        if (!p) return;
        if (!holdingSpear(p) || (o.pauseOnContainer.value && containerOpen)) { charging = 0; return; }
        if (o.onlyOnGround.value && !ground) return;
        if (o.onlyMoving.value && !moving) return;

        if (charging > 0) {
          if (--charging === 0) {
            call(p, ["releaseItem", "stopUsingItem"]);   // firlat
            nextAt = Date.now() + o.cooldownMs.value;
            count++;
            if (o.chat.value) say(ctx, "§b[AutoSpear]§r atis #" + count);
          }
          return;
        }
        if (Date.now() < nextAt) return;
        if (!call(p, ["startUsingItem", "useItem", "useHeldItem", "interactItem"])) {
          if (!warned) { warned = true; say(ctx, "§c[AutoSpear]§r bu surumde esya kullanma fonksiyonu bulunamadi"); }
          return;
        }
        charging = o.chargeTicks.value;
      } catch (_) {}
    });
  }
);
