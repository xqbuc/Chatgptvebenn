import { defineModule } from "@protohax/userscript";

// r3-client BoatFly: tekne/arac uzerindeyken ucus. Binme durumu birden fazla alandan okunur.
defineModule(
  { name: "BoatFly", togglable: true, defaultState: false, description: "Teknede ucus" },
  {
    mode: { type: "enum", name: "Mod", def: "Motion", values: ["Motion", "Glide", "Hover"] },
    horizontalSpeed: { type: "number", name: "Yatay Hiz", def: 1.0, min: 0.1, max: 4.0, step: 0.05 },
    verticalSpeed: { type: "number", name: "Dikey Hiz", def: 0.45, min: 0.05, max: 3.0, step: 0.05 },
    glideStrength: { type: "number", name: "Glide Alcalma", def: 0.02, min: 0.0, max: 0.2, step: 0.005 },
    jumpAscend: { type: "boolean", name: "Ziplayinca Yuksel", def: true },
    sneakDescend: { type: "boolean", name: "Cokunce Alcal", def: true },
    holdHeight: { type: "boolean", name: "Yuksekligi Sabitle", def: true },
    freezeWhenIdle: { type: "boolean", name: "Tus Birakinca Dur", def: true },
    invertStrafe: { type: "boolean", name: "Strafe Yonunu Ters Cevir", def: false },
    forceWithoutBoat: { type: "boolean", name: "Tekne Algilanmasa da Calistir", def: false },
    nearBoatDetect: { type: "boolean", name: "Yakin Tekne Algila (yedek)", def: true },
    rampTicks: { type: "number", name: "Hizlanma Suresi (tick)", def: 4, min: 1, max: 20, step: 1 },
    maxStep: { type: "number", name: "Tick Basina Max Hiz Degisimi", def: 0.35, min: 0.05, max: 2.0, step: 0.05 },
    rubberbandGuard: { type: "boolean", name: "Geri Cekilmeyi Algila/Yavasla", def: true },
    antiKick: { type: "boolean", name: "Anti-Kick", def: true },
    antiKickInterval: { type: "number", name: "Anti-Kick Araligi (tick)", def: 25, min: 5, max: 100, step: 1 },
    antiKickDrop: { type: "number", name: "Anti-Kick Dusus", def: 0.04, min: 0.01, max: 0.3, step: 0.01 },
    maxHeight: { type: "number", name: "Max Yukseklik (0=sinirsiz)", def: 0, min: 0, max: 256, step: 1 },
    autoDisableOnDismount: { type: "boolean", name: "Inince Kapat", def: false },
  },
  (ctx) => {
    let tick = 0;
    let startY = null;
    let holdY = null;
    let moveTicks = 0;
    let curX = 0;
    let curZ = 0;
    let lastPos = null;
    let lastSet = null;
    let slowUntil = 0;

    function riding(p) {
      return !!(p.isRiding || p.riding || p.vehicle || p.ridingEntity || p.mount || (p.vehicleRuntimeId && p.vehicleRuntimeId !== 0));
    }

    // Yedek: oyuncunun hemen yaninda tekne/arac varliği varsa bindi say.
    function nearBoat(session, p) {
      try {
        for (const e of session.entityState.entities.values()) {
          if (e === p || !e.position) continue;
          const id = String(e.identifier || e.type || e.name || e.constructor?.name || "").toLowerCase();
          if (!(id.includes("boat") || id.includes("minecart"))) continue;
          const dx = e.position.x - p.position.x;
          const dy = e.position.y - p.position.y;
          const dz = e.position.z - p.position.z;
          if (dx * dx + dy * dy + dz * dz <= 6.25) return true;
        }
      } catch (_) {}
      return false;
    }

    function reset() {
      startY = null; holdY = null; moveTicks = 0; curX = 0; curZ = 0; lastPos = null; lastSet = null; slowUntil = 0;
    }

    ctx.onEnable(() => { tick = 0; reset(); });
    ctx.onDisable(() => { reset(); });
    ctx.onPacket("transfer", () => { reset(); });

    ctx.on("movement_tick", (state) => {
      const session = ctx.session;
      if (!session) return;
      const player = session.entityState?.localPlayer;
      if (!player) return;
      tick++;

      let onBoat = riding(player);
      if (!onBoat && ctx.options.nearBoatDetect.value) onBoat = nearBoat(session, player);
      if (!onBoat && !ctx.options.forceWithoutBoat.value) { reset(); return; }

      const pos = state.position;
      if (startY === null) startY = pos.y;

      // Sunucu bizi geri cektiyse (beklenen konumdan buyuk sapma) yuksekligi birak ve kisa sure yavasla.
      if (ctx.options.rubberbandGuard.value && lastSet && lastPos) {
        const ex = lastPos.x + lastSet.x, ey = lastPos.y + lastSet.y, ez = lastPos.z + lastSet.z;
        const dev = Math.hypot(pos.x - ex, pos.y - ey, pos.z - ez);
        if (dev > 1.5) { holdY = null; moveTicks = 0; curX = 0; curZ = 0; slowUntil = tick + 10; }
      }
      lastPos = { x: pos.x, y: pos.y, z: pos.z };

      const slow = tick < slowUntil ? 0.5 : 1;
      const hs = ctx.options.horizontalSpeed.value * slow;
      const vs = ctx.options.verticalSpeed.value * slow;
      let mx = 0;
      let mz = 0;
      const mi = state.moveInput;
      if (mi && (mi.x || mi.y)) {
        const f = mi.y;
        const s = ctx.options.invertStrafe.value ? -mi.x : mi.x;
        const yaw = (player.rotation.y * Math.PI) / 180;
        let x = -Math.sin(yaw) * f + Math.cos(yaw) * s;
        let z = Math.cos(yaw) * f + Math.sin(yaw) * s;
        const len = Math.sqrt(x * x + z * z) || 1;
        mx = (x / len) * hs; mz = (z / len) * hs;
      } else if (!ctx.options.freezeWhenIdle.value) {
        mx = state.motion.x; mz = state.motion.z;
      }

      let my = 0;
      const mode = ctx.options.mode.value;
      if (mode === "Glide") my = -ctx.options.glideStrength.value;
      let manual = false;
      if (ctx.options.jumpAscend.value && player.isJumping) { my = vs; manual = true; }
      if (ctx.options.sneakDescend.value && player.isSneaking) { my = -vs; manual = true; }

      if (manual) holdY = null;
      else if (ctx.options.holdHeight.value && mode !== "Glide") {
        if (holdY === null) holdY = pos.y;
        my = (holdY - pos.y) * 0.5;
      }

      if (ctx.options.antiKick.value && !manual && tick % ctx.options.antiKickInterval.value === 0) {
        my = -ctx.options.antiKickDrop.value; holdY = null;
      }

      const mh = ctx.options.maxHeight.value;
      if (mh > 0 && pos.y - startY >= mh && my > 0) my = 0;

      // Yumusak hizlanma + tick basina degisim siniri: ani hiz sicramalari geri cekilmeye yol acar.
      if (mx || mz) moveTicks = Math.min(moveTicks + 1, 1000); else moveTicks = 0;
      const ramp = Math.min(1, moveTicks / ctx.options.rampTicks.value);
      mx *= ramp; mz *= ramp;
      const step = ctx.options.maxStep.value;
      const dx = mx - curX, dz = mz - curZ;
      const dl = Math.hypot(dx, dz);
      if (dl > step) { curX += (dx / dl) * step; curZ += (dz / dl) * step; } else { curX = mx; curZ = mz; }
      if (!mx && !mz) { curX = 0; curZ = 0; }

      lastSet = { x: curX, y: my, z: curZ };
      state.setMotion({ x: curX, y: my, z: curZ });
    });

    ctx.on("tick", () => {
      if (!ctx.options.autoDisableOnDismount.value) return;
      const player = ctx.session?.entityState?.localPlayer;
      if (player && !riding(player)) { startY = null; holdY = null; }
    });
  }
);
