// CPSClicker — saniyede 1-700 tıklama (kol sallama) üretir. Çok sayıda desen ve ayar içerir.
import { defineModule } from "@protohax/userscript";

const N = (name, def, min, max, step) => ({ type: "number", name, def, min, max, step });
const B = (name, def) => ({ type: "boolean", name, def });
const say = (ctx, message) => {
  try {
    ctx.session.connection.sendIncomingPacket("text", {
      type: "raw", needs_translation: false, message,
      xuid: "", platform_chat_id: "", has_filtered_message: false,
    });
  } catch (e) { console.log(message); }
};

defineModule(
  { name: "CPSClicker" },
  {
    // --- kontrol ---
    toggle: { type: "trigger", name: "Toggle Clicking" },
    autoStart: B("Start Clicking When Enabled", true),
    pressFor: N("Click For (s) Per Press (0 = toggle)", 0, 0, 60, 1),
    // --- CPS ---
    cpsMin: N("CPS Min", 10, 1, 700, 1),
    cpsMax: N("CPS Max", 14, 1, 700, 1),
    hardCap: N("Hard CPS Cap", 700, 1, 700, 1),
    tps: N("Ticks Per Second", 20, 5, 40, 1),
    maxPerTick: N("Max Clicks Per Tick", 35, 1, 50, 1),
    // --- desen ---
    pattern: N("Pattern (0 Steady, 1 Random, 2 Burst, 3 Butterfly, 4 Drag, 5 Wave, 6 Jitter)", 0, 0, 6, 1),
    retarget: N("Re-roll Target Every (s)", 0.5, 0.05, 10, 0.05),
    smooth: N("CPS Smoothing (%)", 0, 0, 95, 5),
    jitter: N("Per-Tick CPS Jitter (%)", 0, 0, 100, 5),
    burstLen: N("Burst Length (ticks)", 6, 1, 100, 1),
    burstGap: N("Burst Gap (ticks)", 4, 0, 100, 1),
    burstMul: N("Burst CPS Multiplier (%)", 150, 50, 500, 10),
    gapCps: N("Gap CPS (Burst)", 0, 0, 100, 1),
    butterfly: N("Butterfly Extra Click Chance (%)", 35, 0, 100, 5),
    dragPeriod: N("Drag Period (ticks)", 40, 5, 400, 5),
    waveSpeed: N("Wave Speed", 0.15, 0.01, 2, 0.01),
    waveDepth: N("Wave Depth (%)", 100, 0, 100, 5),
    // --- ramp / yorgunluk ---
    startDelay: N("Start Delay (ticks)", 0, 0, 100, 1),
    rampUp: N("Ramp Up (ticks)", 0, 0, 200, 1),
    fatigueStart: N("Fatigue After (s, 0 = off)", 0, 0, 300, 1),
    fatigueSpan: N("Fatigue Duration (s)", 10, 1, 120, 1),
    fatigueMin: N("Fatigue Min CPS (%)", 60, 10, 100, 5),
    fatigueRecover: N("Fatigue Recover (s)", 5, 1, 120, 1),
    // --- insansılaştırma ---
    pauseChance: N("Random Pause Chance (% per s)", 0, 0, 100, 1),
    pauseMin: N("Pause Min (ticks)", 2, 1, 100, 1),
    pauseMax: N("Pause Max (ticks)", 6, 1, 200, 1),
    dropChance: N("Skip Tick Chance (%)", 0, 0, 90, 1),
    // --- süre / sınırlar ---
    maxDuration: N("Max Continuous Time (s, 0 = off)", 0, 0, 600, 5),
    cooldownAfter: N("Cooldown After Limit (s)", 3, 0, 120, 1),
    stopAfter: N("Stop After Clicks (0 = off)", 0, 0, 100000, 100),
    // --- koşullar ---
    onlyGround: B("Only On Ground", false),
    onlyAir: B("Only In Air", false),
    onlyMoving: B("Only While Moving", false),
    onlyStill: B("Only While Standing Still", false),
    onlyJumping: B("Only While Jumping", false),
    pitchMin: N("Only When Pitch Above (deg)", -90, -90, 90, 5),
    pitchMax: N("Only When Pitch Below (deg)", 90, -90, 90, 5),
    minHealth: N("Stop Below Health (0 = off)", 0, 0, 20, 1),
    maxHealth: N("Stop Above Health (0 = off)", 0, 0, 40, 1),
    // --- hasar tepkisi ---
    hurtStop: N("Pause After Hurt (ticks)", 0, 0, 100, 1),
    hurtBoost: N("Boost After Hurt (%)", 0, 0, 300, 10),
    hurtBoostTicks: N("Boost Duration (ticks)", 20, 1, 200, 1),
    lowHpBoost: N("Low Health Boost (%)", 0, 0, 300, 10),
    lowHpBelow: N("Low Health Below", 8, 1, 20, 1),
    // --- geri bildirim ---
    chat: B("Chat Feedback (start/stop)", false),
    report: N("Report Live CPS Every (s, 0 = off)", 0, 0, 60, 1),
    printStats: { type: "trigger", name: "Print Stats" },
    resetStats: { type: "trigger", name: "Reset Stats" },
  },
  (ctx) => {
    let enabled = false, clicking = false;
    let tick = 0, acc = 0, cur = 0, target = 0, retT = 0, runTicks = 0, activeTicks = 0;
    let pauseLeft = 0, cdLeft = 0, pressLeft = 0, hurtStopLeft = 0, hurtBoostLeft = 0, burstPos = 0;
    let fat = 0, total = 0, session = 0, secClicks = 0, liveCps = 0, peak = 0, repT = 0, lastHp = null;
    const st = { ground: true, moving: false, jumping: false, pitch: 0 };
    const o = () => ctx.options;
    const me = () => ctx.session.entityState.localPlayer;
    const pre = "§d[CPS]§r";
    const range = () => {
      const a = o().cpsMin.value, b = o().cpsMax.value;
      return [Math.min(a, b), Math.max(a, b)];
    };
    const rollTarget = () => { const [lo, hi] = range(); target = lo + Math.random() * (hi - lo); };
    const start = () => {
      if (cdLeft > 0 || clicking) return;
      clicking = true; runTicks = 0; activeTicks = 0; acc = 0; burstPos = 0; session = 0;
      if (o().pressFor.value > 0) pressLeft = o().pressFor.value * o().tps.value;
      if (o().chat.value) say(ctx, `${pre} ON`);
    };
    const stop = (why) => {
      if (!clicking) return;
      clicking = false; pressLeft = 0; acc = 0;
      if (o().chat.value) say(ctx, `${pre} OFF${why ? " (" + why + ")" : ""}`);
    };
    const conditionsOk = () => {
      const x = o(), hp = me().health;
      if (x.onlyGround.value && !st.ground) return false;
      if (x.onlyAir.value && st.ground) return false;
      if (x.onlyMoving.value && !st.moving) return false;
      if (x.onlyStill.value && st.moving) return false;
      if (x.onlyJumping.value && !st.jumping) return false;
      if (st.pitch < x.pitchMin.value || st.pitch > x.pitchMax.value) return false;
      if (x.minHealth.value > 0 && hp <= x.minHealth.value) return false;
      if (x.maxHealth.value > 0 && hp > x.maxHealth.value) return false;
      return true;
    };
    // seçilen desene göre o tick'in hedef CPS'i
    const patternCps = () => {
      const x = o(), [lo, hi] = range(), tps = x.tps.value;
      switch (x.pattern.value) {
        case 1: return lo + Math.random() * (hi - lo);
        case 2: {
          const per = x.burstLen.value + x.burstGap.value;
          const pos = burstPos++ % Math.max(1, per);
          return pos < x.burstLen.value ? target * (x.burstMul.value / 100) : x.gapCps.value;
        }
        case 4: {
          const ph = (activeTicks % x.dragPeriod.value) / x.dragPeriod.value;
          return lo + (hi - lo) * ph;
        }
        case 5: {
          const mid = (lo + hi) / 2, amp = ((hi - lo) / 2) * (x.waveDepth.value / 100);
          return mid + Math.sin(activeTicks * x.waveSpeed.value) * amp;
        }
        case 6: return target * (1 + (Math.random() * 2 - 1) * 0.5);
        default: return target;
      }
    };

    ctx.onEnable(() => {
      enabled = true; clicking = false; tick = 0; acc = 0; cur = 0; cdLeft = 0; pauseLeft = 0; fat = 0;
      hurtStopLeft = 0; hurtBoostLeft = 0; lastHp = null; liveCps = 0; secClicks = 0; repT = 0;
      rollTarget(); cur = target;
      if (o().autoStart.value) start();
    });
    ctx.onDisable(() => { enabled = false; clicking = false; });
    o().toggle.subscribe(() => { if (!enabled) return; clicking ? stop("toggle") : start(); });
    o().printStats.subscribe(() => {
      say(ctx, `${pre} Toplam: ${total} | Oturum: ${session} | Anlık: ${liveCps} CPS | Zirve: ${peak} CPS`);
    });
    o().resetStats.subscribe(() => { total = 0; session = 0; peak = 0; });

    ctx.on("movement_tick", (state) => {
      st.ground = state.onGround; st.moving = state.isMoving; st.jumping = !!state.isJumping; st.pitch = state.rotation.x;
    });

    ctx.on("tick", () => {
      const x = o(), p = me(), tps = x.tps.value;
      tick++;
      const hp = p.health;
      if (lastHp !== null && hp < lastHp) { hurtStopLeft = x.hurtStop.value; hurtBoostLeft = x.hurtBoostTicks.value; }
      lastHp = hp;
      if (cdLeft > 0) cdLeft--;

      // canlı CPS ölçümü
      if (tick % tps === 0) {
        liveCps = secClicks; secClicks = 0; if (liveCps > peak) peak = liveCps;
        if (x.report.value > 0 && ++repT >= x.report.value) { repT = 0; say(ctx, `${pre} ${liveCps} CPS`); }
      }
      if (!clicking) { activeTicks = 0; fat = Math.max(0, fat - 1 / (x.fatigueRecover.value * tps)); return; }

      if (pressLeft > 0 && --pressLeft === 0) { stop("press"); return; }
      runTicks++;
      if (x.maxDuration.value > 0 && runTicks > x.maxDuration.value * tps) { cdLeft = x.cooldownAfter.value * tps; stop("limit"); return; }
      if (x.stopAfter.value > 0 && session >= x.stopAfter.value) { stop("click limit"); return; }

      if (!conditionsOk()) { activeTicks = 0; fat = Math.max(0, fat - 1 / (x.fatigueRecover.value * tps)); return; }
      if (hurtStopLeft > 0) { hurtStopLeft--; return; }
      if (runTicks <= x.startDelay.value) return;
      activeTicks++;

      // hedef CPS'i yenile + yumuşat
      if (++retT >= x.retarget.value * tps) { retT = 0; rollTarget(); }
      let cps = patternCps();
      cur += (cps - cur) * (1 - x.smooth.value / 100);
      cps = x.smooth.value > 0 ? cur : cps;

      // yorgunluk
      if (x.fatigueStart.value > 0 && activeTicks > x.fatigueStart.value * tps) fat = Math.min(1, fat + 1 / (x.fatigueSpan.value * tps));
      else fat = Math.max(0, fat - 1 / (x.fatigueRecover.value * tps));
      cps *= 1 - fat * (1 - x.fatigueMin.value / 100);

      // ramp
      if (x.rampUp.value > 0) cps *= Math.min(1, activeTicks / x.rampUp.value);
      // hasar / düşük can artışı
      if (hurtBoostLeft > 0) { hurtBoostLeft--; cps *= 1 + x.hurtBoost.value / 100; }
      if (x.lowHpBoost.value > 0 && hp <= x.lowHpBelow.value) cps *= 1 + x.lowHpBoost.value / 100;
      // jitter
      if (x.jitter.value > 0) cps *= 1 + (Math.random() * 2 - 1) * (x.jitter.value / 100);

      // rastgele duraklama / tick atlama
      if (pauseLeft > 0) { pauseLeft--; return; }
      if (x.pauseChance.value > 0 && Math.random() * 100 < x.pauseChance.value / tps) {
        const a = Math.min(x.pauseMin.value, x.pauseMax.value), b = Math.max(x.pauseMin.value, x.pauseMax.value);
        pauseLeft = a + Math.floor(Math.random() * (b - a + 1));
        return;
      }
      if (x.dropChance.value > 0 && Math.random() * 100 < x.dropChance.value) return;

      cps = Math.max(0, Math.min(cps, x.hardCap.value));
      acc += cps / tps;
      let n = Math.floor(acc);
      acc -= n;
      if (x.pattern.value === 3 && Math.random() * 100 < x.butterfly.value) n += 1;
      n = Math.min(n, x.maxPerTick.value);
      if (x.stopAfter.value > 0) n = Math.min(n, x.stopAfter.value - session);
      if (n <= 0) return;
      for (let i = 0; i < n; i++) p.swingItem("CPSClicker");
      total += n; session += n; secClicks += n;
    });
  },
);
