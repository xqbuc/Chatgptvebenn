// DashKey — menüdeki butona basınca baktığın yöne ani hız verir.
import { defineModule } from "@protohax/userscript";

const N = (name, def, min, max, step) => ({ type: "number", name, def, min, max, step });
const B = (name, def) => ({ type: "boolean", name, def });
const say = (ctx, message) => {
  try {
    ctx.session.connection.sendIncomingPacket("text", {
      type: "raw", needs_translation: false, message,
      xuid: "", platform_chat_id: "", has_filtered_message: false,
    });
  } catch (e) { console.log(message); }
};

defineModule(
  { name: "DashKey" },
  {
    dash: { type: "trigger", name: "Dash!" },
    power: N("Power", 1.2, 0.3, 4, 0.1),
    lift: N("Lift", 0.2, 0, 1, 0.05),
    duration: N("Spread Over (ticks)", 1, 1, 20, 1),
    cooldown: N("Cooldown (ticks)", 0, 0, 200, 5),
    maxAirDashes: N("Max Air Dashes (0 = unlimited)", 0, 0, 10, 1),
    usePitch: B("Use Pitch (dash where you look)", false),
    pitchScale: N("Pitch Strength", 1, 0, 1, 0.05),
    resetMotion: B("Reset Motion First", false),
    keepVertical: B("Keep Vertical Motion", true),
    onlyMoving: B("Only While Moving", false),
    onlyAir: B("Only In Air", false),
    onlyGround: B("Only On Ground", false),
    randomness: N("Power Randomness", 0, 0, 0.5, 0.05),
    brakeAfter: N("Brake After Dash (%)", 0, 0, 100, 5),
    queue: N("Max Queued Dashes", 1, 1, 5, 1),
    minHealth: N("Disable Below Health (0 = off)", 0, 0, 20, 1),
    // --- yeni ayarlar ---
    angle: N("Direction Offset (deg)", 0, -180, 180, 5),
    angleJitter: N("Direction Jitter (deg)", 0, 0, 45, 1),
    backward: B("Dash Backward", false),
    groundMul: N("Ground Power (%)", 100, 10, 300, 5),
    airMul: N("Air Power (%)", 100, 10, 300, 5),
    airLift: N("Air Lift (%)", 100, 0, 300, 10),
    decay: N("Per-Tick Power Decay (%)", 0, 0, 50, 1),
    capH: N("Max Horizontal Speed (0 = off)", 0, 0, 5, 0.1),
    capV: N("Max Vertical Speed (0 = off)", 0, 0, 5, 0.1),
    slowerThan: N("Only If Slower Than (0 = off)", 0, 0, 5, 0.1),
    fasterThan: N("Only If Faster Than (0 = off)", 0, 0, 5, 0.1),
    jumpFirst: B("Jump Before Dash (ground)", false),
    delay: N("Start Delay (ticks)", 0, 0, 20, 1),
    auto: B("Auto Dash", false),
    autoEvery: N("Auto Dash Every (ticks)", 20, 2, 400, 1),
    maxTotal: N("Max Dashes Per Enable (0 = unlimited)", 0, 0, 500, 5),
    lowHpBoost: N("Low Health Boost (%)", 0, 0, 200, 10),
    lowHpBelow: N("Low Health Below", 8, 1, 20, 1),
    chat: B("Chat Feedback", false),
  },
  (ctx) => {
    let enabled = false, pending = 0, cd = 0, airDashes = 0, left = 0, brake = false;
    let total = 0, autoT = 0, arming = -1;
    let dir = { x: 0, y: 0, z: 0 }, pw = 0;

    ctx.onEnable(() => { enabled = true; pending = 0; cd = 0; airDashes = 0; left = 0; brake = false; total = 0; autoT = 0; arming = -1; });
    ctx.onDisable(() => { enabled = false; pending = 0; left = 0; });
    ctx.options.dash.subscribe(() => { if (enabled) pending = Math.min(pending + 1, ctx.options.queue.value); });

    ctx.on("movement_tick", (state) => {
      const o = ctx.options;
      const p = ctx.session.entityState.localPlayer;
      if (cd > 0) cd--;
      if (state.onGround) airDashes = 0;
      if (o.auto.value && ++autoT >= o.autoEvery.value) { autoT = 0; pending = Math.min(pending + 1, o.queue.value); }

      if (left === 0 && pending > 0 && cd === 0) {
        const m0 = state.motion;
        const hs = Math.hypot(m0.x, m0.z);
        const ok = !(o.onlyMoving.value && !state.isMoving) &&
          !(o.onlyAir.value && state.onGround) && !(o.onlyGround.value && !state.onGround) &&
          !(o.minHealth.value > 0 && p.health <= o.minHealth.value) &&
          !(!state.onGround && o.maxAirDashes.value > 0 && airDashes >= o.maxAirDashes.value) &&
          !(o.slowerThan.value > 0 && hs >= o.slowerThan.value) &&
          !(o.fasterThan.value > 0 && hs < o.fasterThan.value) &&
          !(o.maxTotal.value > 0 && total >= o.maxTotal.value);
        if (!ok) { pending = 0; arming = -1; return; }
        if (arming < 0) arming = o.delay.value;
        if (arming > 0) { arming--; return; }
        arming = -1;
        pending--;
        total++;
        if (!state.onGround) airDashes++;
        if (o.jumpFirst.value && state.onGround) state.jump();
        const jit = (Math.random() * 2 - 1) * o.angleJitter.value;
        const yaw = ((state.rotation.y + o.angle.value + jit + (o.backward.value ? 180 : 0)) * Math.PI) / 180;
        const pit = (state.rotation.x * Math.PI) / 180;
        const hz = o.usePitch.value ? Math.cos(pit * o.pitchScale.value) : 1;
        let mul = (state.onGround ? o.groundMul.value : o.airMul.value) / 100;
        if (o.lowHpBoost.value > 0 && p.health <= o.lowHpBelow.value) mul *= 1 + o.lowHpBoost.value / 100;
        pw = ((o.power.value + (Math.random() * 2 - 1) * o.randomness.value) * mul) / o.duration.value;
        dir = { x: -Math.sin(yaw) * hz, y: o.usePitch.value ? -Math.sin(pit) * o.pitchScale.value : 0, z: Math.cos(yaw) * hz };
        if (o.resetMotion.value) state.setMotion({ x: 0, y: o.keepVertical.value ? state.motion.y : 0, z: 0 });
        state.addMotion({ x: 0, y: o.lift.value * (state.onGround ? 1 : o.airLift.value / 100), z: 0 });
        left = o.duration.value;
        cd = o.cooldown.value;
        if (o.chat.value) say(ctx, `§b[Dash]§r #${total} ${state.onGround ? "yer" : "hava"}`);
      }
      if (left > 0) {
        left--;
        state.addMotion({ x: dir.x * pw, y: dir.y * pw, z: dir.z * pw });
        pw *= 1 - o.decay.value / 100;
        if (o.capH.value > 0 || o.capV.value > 0) {
          const m = state.motion;
          let x = m.x, y = m.y, z = m.z;
          const h = Math.hypot(x, z);
          if (o.capH.value > 0 && h > o.capH.value) { const k = o.capH.value / h; x *= k; z *= k; }
          if (o.capV.value > 0 && Math.abs(y) > o.capV.value) y = Math.sign(y) * o.capV.value;
          state.setMotion({ x, y, z });
        }
        if (left === 0 && o.brakeAfter.value > 0) brake = true;
      } else if (brake) {
        brake = false;
        const k = 1 - o.brakeAfter.value / 100, m = state.motion;
        state.setMotion({ x: m.x * k, y: m.y, z: m.z * k });
      }
    });
  },
);
