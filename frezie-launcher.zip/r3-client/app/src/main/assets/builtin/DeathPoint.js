// DeathPoint — öldüğünde koordinatlarını sohbete yazar, mesafeyi hatırlatır, geçmişi tutar.
import { defineModule } from "@protohax/userscript";

const N = (name, def, min, max, step) => ({ type: "number", name, def, min, max, step });
const B = (name, def) => ({ type: "boolean", name, def });
const say = (ctx, message) => {
  try {
    ctx.session.connection.sendIncomingPacket("text", {
      type: "raw", needs_translation: false, message,
      xuid: "", platform_chat_id: "", has_filtered_message: false,
    });
  } catch (e) { console.log(message); }
};

defineModule(
  { name: "DeathPoint" },
  {
    announce: B("Announce On Death", true),
    decimals: N("Decimals", 0, 0, 3, 1),
    reminder: N("Distance Reminder Every (s, 0 = off)", 0, 0, 120, 5),
    showDirection: B("Show Direction", true),
    announceOnRespawn: B("Repeat On Respawn", true),
    history: N("History Size", 5, 1, 20, 1),
    clearOnReach: N("Forget When Within (blocks, 0 = off)", 5, 0, 50, 1),
    printHistory: { type: "trigger", name: "Print History" },
    clearHistory: { type: "trigger", name: "Clear History" },
    color: N("Prefix Color (0-15)", 12, 0, 15, 1),
    // --- yeni ayarlar ---
    printNearest: { type: "trigger", name: "Print Nearest Death" },
    removeLatest: { type: "trigger", name: "Remove Latest Death" },
    printStats: { type: "trigger", name: "Print Stats" },
    lang: N("Language (0 TR, 1 EN)", 0, 0, 1, 1),
    showY: B("Show Y", true),
    sep: N("Separator (0 space, 1 comma, 2 slash)", 0, 0, 2, 1),
    showDistance: B("Show Distance On Respawn", true),
    showHeight: B("Show Height Difference", false),
    showTimeAlive: B("Show Time Survived", false),
    showCounter: B("Show Death Counter", true),
    minRemind: N("Remind Only Beyond (blocks)", 0, 0, 500, 5),
    remindMax: N("Max Reminders Per Death (0 = off)", 0, 0, 100, 1),
    awayWarn: B("Warn When Moving Away", false),
    ignoreNear: N("Ignore Death Within (blocks of last)", 0, 0, 50, 1),
    chatEveryRespawn: B("Print Full History On Respawn", false),
  },
  (ctx) => {
    const hex = "0123456789abcdef";
    let lastPos = null, wasAlive = true, enabled = false, since = 0, target = null;
    let aliveTicks = 0, lastLife = 0, deaths = 0, reminded = 0, lastDist = null, away = 0;
    const list = [];
    const o = () => ctx.options;
    const T = (tr, en) => (o().lang.value === 1 ? en : tr);
    const f = (v) => o().decimals.value > 0 ? v.toFixed(o().decimals.value) : String(Math.floor(v));
    const pre = () => `§${hex[o().color.value]}[DeathPoint]§r`;
    const fmt = (c) => {
      const s = [" ", ", ", " / "][o().sep.value];
      return (o().showY.value ? [f(c.x), f(c.y), f(c.z)] : [f(c.x), f(c.z)]).join(s);
    };
    const compass = (dx, dz) => {
      const tr = ["D", "GD", "G", "GB", "B", "KB", "K", "KD"];
      const en = ["E", "SE", "S", "SW", "W", "NW", "N", "NE"];
      const i = ((Math.round((Math.atan2(dz, dx) * 180) / Math.PI / 45) % 8) + 8) % 8;
      return (o().lang.value === 1 ? en : tr)[i];
    };

    ctx.onEnable(() => { enabled = true; lastPos = null; wasAlive = true; since = 0; aliveTicks = 0; reminded = 0; lastDist = null; away = 0; });
    ctx.onDisable(() => { enabled = false; });
    o().printHistory.subscribe(() => {
      if (!enabled) return;
      if (!list.length) return say(ctx, `${pre()} ${T("Geçmiş boş", "History empty")}`);
      list.forEach((c, i) => say(ctx, `${pre()} #${i + 1}: ${fmt(c)}`));
    });
    o().clearHistory.subscribe(() => { list.length = 0; target = null; });
    o().removeLatest.subscribe(() => { list.shift(); target = list[0] || null; });
    o().printNearest.subscribe(() => {
      if (!enabled || !lastPos || !list.length) return;
      let best = list[0], bd = Infinity;
      for (const c of list) { const d = Math.hypot(c.x - lastPos.x, c.z - lastPos.z); if (d < bd) { bd = d; best = c; } }
      say(ctx, `${pre()} ${T("En yakın", "Nearest")}: ${fmt(best)} (${Math.round(bd)}m)`);
    });
    o().printStats.subscribe(() => {
      say(ctx, `${pre()} ${T("Ölüm", "Deaths")}: ${deaths} | ${T("Son yaşam", "Last life")}: ${Math.round(lastLife / 20)}s`);
    });

    ctx.on("tick", () => {
      const p = ctx.session.entityState.localPlayer;
      if (p.health > 0) {
        aliveTicks++;
        if (!wasAlive) {
          if (o().announceOnRespawn.value && target) {
            let s = `${pre()} ${T("Ölüm noktası", "Death point")}: ${fmt(target)}`;
            if (o().showDistance.value) s += ` (${Math.round(Math.hypot(target.x - p.position.x, target.z - p.position.z))}m)`;
            say(ctx, s);
          }
          if (o().chatEveryRespawn.value) list.forEach((c, i) => say(ctx, `${pre()} #${i + 1}: ${fmt(c)}`));
          aliveTicks = 0; reminded = 0; lastDist = null; away = 0;
        }
        wasAlive = true;
        lastPos = { x: p.position.x, y: p.position.y, z: p.position.z };
        if (target) {
          const dx = target.x - lastPos.x, dz = target.z - lastPos.z;
          const d = Math.hypot(dx, dz);
          if (o().clearOnReach.value > 0 && d <= o().clearOnReach.value) { target = null; return; }
          if (o().reminder.value > 0 && ++since >= o().reminder.value * 20) {
            since = 0;
            const capped = o().remindMax.value > 0 && reminded >= o().remindMax.value;
            if (d >= o().minRemind.value && !capped) {
              reminded++;
              let s = `${pre()} ${Math.round(d)} ${T("blok", "blocks")}${o().showDirection.value ? " " + compass(dx, dz) : ""} → ${fmt(target)}`;
              if (o().showHeight.value) { const h = Math.round(target.y - lastPos.y); s += ` (${h >= 0 ? "+" : ""}${h}Y)`; }
              if (o().awayWarn.value && lastDist !== null && d > lastDist + 2) { away++; s += ` §c${T("uzaklaşıyorsun", "moving away")}§r`; }
              lastDist = d;
              say(ctx, s);
            }
          }
        }
      } else if (wasAlive && lastPos) {
        wasAlive = false; since = 0; lastLife = aliveTicks; deaths++;
        const dup = list.length && o().ignoreNear.value > 0 &&
          Math.hypot(list[0].x - lastPos.x, list[0].z - lastPos.z) <= o().ignoreNear.value;
        target = lastPos;
        if (!dup) {
          list.unshift(lastPos);
          while (list.length > o().history.value) list.pop();
        }
        if (o().announce.value) {
          let s = `${pre()} ${fmt(lastPos)}`;
          if (o().showCounter.value) s += ` §7#${deaths}§r`;
          if (o().showTimeAlive.value) s += ` §7(${Math.round(lastLife / 20)}s)§r`;
          say(ctx, s);
        }
      }
    });
  },
);
