import { defineModule, targets, EntityNetworkPlayer, EntityCreature } from "@protohax/userscript";

// r3-client ESP
// Overlay modu: oyuncu/mob verisini r3-client uygulamasina (127.0.0.1:19133) yollar,
// kutu + cizgi ekrana 2D olarak cizilir. Baglanti yoksa otomatik parcacik moduna duser.
// Renk cana gore: yesil dolu, turuncu orta, kirmizi az.
const COLORS = {
  green: "minecraft:villager_happy",
  orange: "minecraft:basic_flame_particle",
  red: "minecraft:redstone_ore_dust_particle",
};
const OVERLAY_URL = "http://127.0.0.1:19133/esp";

defineModule(
  { name: "ESP", defaultState: false, description: "Oyuncu etrafinda kutu + cizgi (ekran cizimi)" },
  {
    range: { type: "number", name: "Menzil (blok)", def: 40, min: 5, max: 120, step: 1 },
    box: { type: "boolean", name: "Kutu", def: true },
    tracer: { type: "boolean", name: "Cizgi (Tracer)", def: true },
    healthColor: { type: "boolean", name: "Cana Gore Renk", def: true },
    players: { type: "boolean", name: "Oyuncular", def: true },
    mobs: { type: "boolean", name: "Mob'lar", def: false },
    overlay: { type: "boolean", name: "Ekran Cizimi (Overlay)", def: true },
    fov: { type: "number", name: "FOV (overlay)", def: 70, min: 30, max: 110, step: 1 },
    interval: { type: "number", name: "Yenileme (tick)", def: 1, min: 1, max: 20, step: 1 },
    tracerStep: { type: "number", name: "Parcacik Cizgi Yogunlugu (blok)", def: 0.6, min: 0.2, max: 2.0, step: 0.1 },
    maxLine: { type: "number", name: "Parcacik Cizgi Max Uzunluk", def: 30, min: 5, max: 80, step: 1 },
  },
  (ctx) => {
    let tick = 0;
    let fails = 0;
    let inflight = false;
    const r2 = (n) => Math.round(n * 100) / 100;

    function particle(name, x, y, z) {
      const s = ctx.session.connection;
      const pos = { x, y, z };
      try { s.sendIncomingPacket("spawn_particle_effect", { dimension: 0, entity_id: BigInt(-1), position: pos, particle_name: name, molang_variables: undefined }); }
      catch (_) {
        try { s.sendIncomingPacket("spawn_particle_effect", { dimension_id: 0, unique_id: BigInt(-1), position: pos, particle_name: name }); } catch (__) {}
      }
    }
    function colorIdx(e) {
      if (!ctx.options.healthColor.value) return 0;
      const hp = e.health ?? 20;
      return hp <= 7 ? 2 : hp < 19 ? 1 : 0;
    }
    function pick(e) { const i = colorIdx(e); return i === 2 ? COLORS.red : i === 1 ? COLORS.orange : COLORS.green; }
    function boxOf(e) {
      const bb = e.aabb;
      if (bb && bb.min && bb.max) return bb;
      const p = e.position;
      return { min: { x: p.x - 0.3, y: p.y, z: p.z - 0.3 }, max: { x: p.x + 0.3, y: p.y + 1.8, z: p.z + 0.3 } };
    }

    function overlayUsable() {
      return ctx.options.overlay.value && typeof fetch === "function" && fails < 20;
    }

    function sendOverlay(me, list) {
      if (inflight) return;
      const o = ctx.options;
      const eye = me.eyePosition ?? { x: me.position.x, y: me.position.y + 1.62, z: me.position.z };
      const rot = me.rotation ?? { x: 0, y: 0 };
      const body = JSON.stringify({
        p: [r2(eye.x), r2(eye.y), r2(eye.z)],
        r: [r2(rot.x), r2(rot.y)],
        f: o.fov.value,
        b: o.box.value ? 1 : 0,
        t: o.tracer.value ? 1 : 0,
        e: list.map((it) => [r2(it.bb.min.x), r2(it.bb.min.y), r2(it.bb.min.z), r2(it.bb.max.x), r2(it.bb.max.y), r2(it.bb.max.z), it.c]),
      });
      inflight = true;
      try {
        fetch(OVERLAY_URL, { method: "POST", body })
          .then(() => { fails = 0; inflight = false; })
          .catch(() => { fails++; inflight = false; });
      } catch (_) { fails++; inflight = false; }
    }

    function drawParticles(me, list) {
      const o = ctx.options;
      for (const it of list) {
        const e = it.e, name = it.name, bb = it.bb;
        if (o.box.value) {
          const { min, max } = bb;
          for (const x of [min.x, max.x]) for (const z of [min.z, max.z]) for (let y = min.y; y <= max.y + 0.01; y += 0.5) particle(name, x, y, z);
          for (const y of [min.y, max.y]) for (const t of [0, 0.5, 1]) {
            particle(name, min.x + (max.x - min.x) * t, y, min.z); particle(name, min.x + (max.x - min.x) * t, y, max.z);
            particle(name, min.x, y, min.z + (max.z - min.z) * t); particle(name, max.x, y, min.z + (max.z - min.z) * t);
          }
        }
        if (o.tracer.value) {
          const a = me.eyePosition ?? me.position; const d = Math.sqrt(it.d2);
          const len = Math.min(d, o.maxLine.value);
          const n = Math.floor(len / o.tracerStep.value); const k = len / d;
          for (let i = 1; i <= n; i++) {
            const t = (i / n) * k;
            particle(name, a.x + (e.position.x - a.x) * t, a.y - 0.3 + (e.position.y + 1 - a.y + 0.3) * t, a.z + (e.position.z - a.z) * t);
          }
        }
      }
    }

    ctx.on("tick", () => {
      try {
        tick++;
        const o = ctx.options;
        const useOverlay = overlayUsable();
        // Parcacik modu daha seyrek yenilenir
        const step = useOverlay ? o.interval.value : Math.max(o.interval.value, 3);
        if (tick % step !== 0) return;
        const session = ctx.session; const me = session?.entityState?.localPlayer;
        if (!me) return;
        const rSq = o.range.value ** 2;
        const list = [];
        for (const e of session.entityState.entities.values()) {
          if (e === me) continue;
          const isP = e instanceof EntityNetworkPlayer, isM = e instanceof EntityCreature;
          if ((!isP && !isM) || (isP && !o.players.value) || (isM && !o.mobs.value)) continue;
          const dx = e.position.x - me.position.x, dy = e.position.y - me.position.y, dz = e.position.z - me.position.z;
          const d2 = dx * dx + dy * dy + dz * dz;
          if (d2 > rSq) continue;
          list.push({ e, d2, bb: boxOf(e), c: colorIdx(e), name: pick(e) });
        }
        if (useOverlay) sendOverlay(me, list); else drawParticles(me, list);
      } catch (_) {}
    });
  }
);
