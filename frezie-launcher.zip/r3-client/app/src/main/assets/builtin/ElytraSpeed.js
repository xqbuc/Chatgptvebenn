import { defineModule, SprintIntent } from "@protohax/userscript";

// r3-client ElytraSpeed: elytra ile suzulurken hiz kontrolu.
defineModule(
  { name: "ElytraSpeed", togglable: true, defaultState: false, description: "Elytra hizlandirici" },
  {
    mode: { type: "enum", name: "Mod", def: "Boost", values: ["Boost", "Constant", "Firework"] },
    speed: { type: "number", name: "Hiz (Constant)", def: 1.5, min: 0.3, max: 6.0, step: 0.1 },
    boostMultiplier: { type: "number", name: "Carpan (Boost)", def: 1.04, min: 1.0, max: 1.3, step: 0.01 },
    acceleration: { type: "number", name: "Ivme (Firework)", def: 0.06, min: 0.005, max: 0.5, step: 0.005 },
    maxSpeed: { type: "number", name: "Max Hiz", def: 3.0, min: 0.5, max: 10.0, step: 0.1 },
    minSpeed: { type: "number", name: "Min Hiz", def: 0.0, min: 0.0, max: 3.0, step: 0.1 },
    verticalControl: { type: "boolean", name: "Pitch ile Dikey Kontrol", def: true },
    verticalScale: { type: "number", name: "Dikey Olcek", def: 1.0, min: 0.0, max: 2.0, step: 0.05 },
    keepAltitude: { type: "boolean", name: "Irtifayi Koru (dusmeyi engelle)", def: false },
    onlyForward: { type: "boolean", name: "Sadece Ileri Tusunda", def: false },
    stopWhenSneak: { type: "boolean", name: "Cokunce Dur", def: true },
    requireSprint: { type: "boolean", name: "Sadece Sprintte", def: false },
    pitchLimit: { type: "number", name: "Pitch Siniri (derece)", def: 90, min: 10, max: 90, step: 5 },
    groundCancel: { type: "boolean", name: "Yere Inince Sifirla", def: true },
    smoothing: { type: "number", name: "Yumusatma", def: 0.2, min: 0.0, max: 0.9, step: 0.05 },
  },
  (ctx) => {
    let cur = 0;

    ctx.onEnable(() => { cur = 0; });
    ctx.onDisable(() => { cur = 0; });

    ctx.on("movement_tick", (state) => {
      const session = ctx.session;
      if (!session) return;
      const player = session.entityState?.localPlayer;
      if (!player) return;

      if (!player.gliding) { cur = 0; return; }
      if (ctx.options.groundCancel.value && state.onGround) { cur = 0; return; }
      if (ctx.options.stopWhenSneak.value && player.isSneaking) return;
      if (ctx.options.onlyForward.value && !(state.moveInput && state.moveInput.y > 0)) return;
      if (ctx.options.requireSprint.value && !player.sprinting) return;

      let pitch = player.rotation.x;
      const lim = ctx.options.pitchLimit.value;
      pitch = Math.max(-lim, Math.min(lim, pitch));
      const pr = (pitch * Math.PI) / 180;
      const yr = (player.rotation.y * Math.PI) / 180;
      const dx = -Math.sin(yr) * Math.cos(pr);
      const dy = -Math.sin(pr);
      const dz = Math.cos(yr) * Math.cos(pr);

      const m = state.motion;
      const now = Math.sqrt(m.x * m.x + m.y * m.y + m.z * m.z);
      if (cur === 0) cur = now;

      const mode = ctx.options.mode.value;
      let target = cur;
      if (mode === "Boost") target = cur * ctx.options.boostMultiplier.value;
      else if (mode === "Constant") target = ctx.options.speed.value;
      else target = cur + ctx.options.acceleration.value;

      target = Math.max(ctx.options.minSpeed.value, Math.min(ctx.options.maxSpeed.value, target));
      const sm = ctx.options.smoothing.value;
      cur = cur * sm + target * (1 - sm);

      let vy = ctx.options.verticalControl.value ? dy * cur * ctx.options.verticalScale.value : m.y;
      if (ctx.options.keepAltitude.value && vy < 0) vy = 0;

      state.setMotion({ x: dx * cur, y: vy, z: dz * cur });
      if (ctx.options.requireSprint.value) state.requestSprint(SprintIntent.Sprint);
    });
  }
);
