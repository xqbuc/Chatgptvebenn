import { defineModule, SprintIntent } from "@protohax/userscript";

// r3-client Fly: Motion / Glide / Jitter / Creative modlari, anti-kick ve yukseklik siniri.
defineModule(
  { name: "Fly", togglable: true, defaultState: false, description: "Detayli ucus modulu" },
  {
    mode: { type: "enum", name: "Mod", def: "Motion", values: ["Motion", "Glide", "Jitter", "Creative"] },
    horizontalSpeed: { type: "number", name: "Yatay Hiz", def: 0.6, min: 0.1, max: 3.0, step: 0.05 },
    verticalSpeed: { type: "number", name: "Dikey Hiz", def: 0.4, min: 0.05, max: 2.0, step: 0.05 },
    smoothing: { type: "number", name: "Yumusatma (0=kapali)", def: 0.0, min: 0.0, max: 0.95, step: 0.05 },
    jumpAscend: { type: "boolean", name: "Ziplayinca Yuksel", def: true },
    sneakDescend: { type: "boolean", name: "Cokunce Alcal", def: true },
    freezeWhenIdle: { type: "boolean", name: "Tus Birakinca Dur", def: true },
    invertStrafe: { type: "boolean", name: "Strafe Yonunu Ters Cevir", def: false },
    sprint: { type: "boolean", name: "Sprint Zorla", def: false },
    glideStrength: { type: "number", name: "Glide Alcalma", def: 0.01, min: 0.0, max: 0.1, step: 0.002 },
    jitterAmount: { type: "number", name: "Jitter Miktari", def: 0.04, min: 0.005, max: 0.2, step: 0.005 },
    jitterTicks: { type: "number", name: "Jitter Araligi (tick)", def: 2, min: 1, max: 10, step: 1 },
    antiKick: { type: "boolean", name: "Anti-Kick (aralikli dusus)", def: true },
    antiKickInterval: { type: "number", name: "Anti-Kick Araligi (tick)", def: 20, min: 5, max: 80, step: 1 },
    antiKickDrop: { type: "number", name: "Anti-Kick Dusus", def: 0.05, min: 0.01, max: 0.3, step: 0.01 },
    groundSpoof: { type: "boolean", name: "Ground Spoof", def: false },
    maxHeight: { type: "number", name: "Max Yukseklik (0=sinirsiz)", def: 0, min: 0, max: 256, step: 1 },
    stopOnHurt: { type: "boolean", name: "Hasar Alinca Dur", def: false },
    speedLimitGuard: { type: "boolean", name: "Hiz Siniri Korumasi", def: false },
  },
  (ctx) => {
    let tick = 0;
    let startY = null;
    let lastHurtTick = -100;
    let lastHealth = null;
    let vx = 0;
    let vz = 0;

    ctx.onEnable(() => {
      tick = 0; startY = null; vx = 0; vz = 0; lastHealth = null;
    });
    ctx.onDisable(() => { startY = null; vx = 0; vz = 0; });
    ctx.onPacket("transfer", () => { startY = null; tick = 0; });

    function inputDir(state, player) {
      const mi = state.moveInput;
      if (!mi) return null;
      const f = mi.y;
      const s = ctx.options.invertStrafe.value ? -mi.x : mi.x;
      if (!f && !s) return null;
      const yaw = (player.rotation.y * Math.PI) / 180;
      let x = -Math.sin(yaw) * f + Math.cos(yaw) * s;
      let z = Math.cos(yaw) * f + Math.sin(yaw) * s;
      const len = Math.sqrt(x * x + z * z) || 1;
      return { x: x / len, z: z / len };
    }

    ctx.on("movement_tick", (state) => {
      const session = ctx.session;
      if (!session) return;
      const player = session.entityState?.localPlayer;
      if (!player) return;
      tick++;

      const hp = player.health;
      if (lastHealth !== null && typeof hp === "number" && hp < lastHealth) lastHurtTick = tick;
      lastHealth = typeof hp === "number" ? hp : lastHealth;
      if (ctx.options.stopOnHurt.value && tick - lastHurtTick < 10) return;

      const pos = state.position;
      if (startY === null) startY = pos.y;

      const mode = ctx.options.mode.value;
      let hs = ctx.options.horizontalSpeed.value;
      const vs = ctx.options.verticalSpeed.value;
      if (ctx.options.speedLimitGuard.value) hs = Math.min(hs, 1.2);

      const dir = inputDir(state, player);
      let tx = 0;
      let tz = 0;
      if (dir) { tx = dir.x * hs; tz = dir.z * hs; }
      else if (!ctx.options.freezeWhenIdle.value) { tx = state.motion.x; tz = state.motion.z; }

      const sm = ctx.options.smoothing.value;
      vx = vx * sm + tx * (1 - sm);
      vz = vz * sm + tz * (1 - sm);

      let vy = 0;
      if (mode === "Glide") vy = -ctx.options.glideStrength.value;
      if (mode === "Jitter") vy = tick % ctx.options.jitterTicks.value === 0 ? ctx.options.jitterAmount.value : -ctx.options.jitterAmount.value * 0.5;
      if (mode === "Creative") vy = 0;

      if (ctx.options.jumpAscend.value && player.isJumping) vy = vs;
      if (ctx.options.sneakDescend.value && player.isSneaking) vy = -vs;

      if (ctx.options.antiKick.value && !player.isJumping && !player.isSneaking && tick % ctx.options.antiKickInterval.value === 0) {
        vy = -ctx.options.antiKickDrop.value;
      }

      const mh = ctx.options.maxHeight.value;
      if (mh > 0 && pos.y - startY >= mh && vy > 0) vy = 0;

      state.setMotion({ x: vx, y: vy, z: vz });
      if (ctx.options.groundSpoof.value) player.onGround = true;
      if (ctx.options.sprint.value) state.requestSprint(SprintIntent.Sprint);
    });
  }
);
