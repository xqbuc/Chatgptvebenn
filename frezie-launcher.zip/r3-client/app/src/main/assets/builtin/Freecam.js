import { defineModule } from "@protohax/userscript";

// r3-client Freecam: oyuncu serbestce uctugu gibi gezer; baslangic noktasindan "chunk" sinirini asamaz.
// Kapatinca baslangic noktasina geri doner (istege bagli).
defineModule(
  { name: "Freecam", defaultState: false, description: "Serbest kamera (hiz ve chunk siniri ayarli)" },
  {
    speed: { type: "number", name: "Hiz (1-59)", def: 10, min: 1, max: 59, step: 1 },
    chunks: { type: "number", name: "Chunk Siniri (1-30)", def: 8, min: 1, max: 30, step: 1 },
    verticalSpeed: { type: "number", name: "Dikey Hiz (1-59)", def: 10, min: 1, max: 59, step: 1 },
    noclip: { type: "boolean", name: "Bloklarin Icinden Gec (hareketi serbest birak)", def: true },
    returnOnDisable: { type: "boolean", name: "Kapatinca Basa Don", def: true },
    freezeWhenIdle: { type: "boolean", name: "Tus Birakinca Dur", def: true },
  },
  (ctx) => {
    let origin = null;

    ctx.onEnable(() => { origin = null; });
    ctx.onPacket("transfer", () => { origin = null; });
    ctx.onDisable(() => {
      try {
        if (origin && ctx.options.returnOnDisable.value) {
          const p = ctx.session.entityState.localPlayer;
          if (p && typeof p.setPosition === "function") p.setPosition(origin);
        }
      } catch (_) {}
      origin = null;
    });

    ctx.on("movement_tick", (state) => {
      const session = ctx.session;
      const player = session?.entityState?.localPlayer;
      if (!player) return;
      const pos = state.position;
      if (!origin) origin = { x: pos.x, y: pos.y, z: pos.z };

      const hs = ctx.options.speed.value * 0.1;           // 1..59 -> 0.1..5.9 blok/tick
      const vs = ctx.options.verticalSpeed.value * 0.1;
      const mi = state.moveInput;
      let vx = 0, vz = 0, vy = 0;
      if (mi && (mi.x || mi.y)) {
        const yaw = (player.rotation.y * Math.PI) / 180;
        const f = mi.y, s = mi.x;
        let x = -Math.sin(yaw) * f + Math.cos(yaw) * s;
        let z = Math.cos(yaw) * f + Math.sin(yaw) * s;
        const len = Math.sqrt(x * x + z * z) || 1;
        vx = (x / len) * hs; vz = (z / len) * hs;
      } else if (!ctx.options.freezeWhenIdle.value) {
        vx = state.motion.x; vz = state.motion.z;
      }
      if (state.isJumping) vy = vs;
      else if (player.isSneaking) vy = -vs;

      // chunk siniri: baslangictan en fazla chunks*16 blok uzaga
      const lim = ctx.options.chunks.value * 16;
      const nx = pos.x + vx - origin.x, nz = pos.z + vz - origin.z;
      if (Math.abs(nx) > lim) vx = 0;
      if (Math.abs(nz) > lim) vz = 0;

      state.setMotion({ x: vx, y: vy, z: vz });
    });
  }
);
