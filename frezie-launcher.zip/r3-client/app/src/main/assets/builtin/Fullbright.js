import { defineModule } from "@protohax/userscript";

// r3-client Fullbright+: gece gorusu efektini surekli yeniler, istege bagli olumsuz efektleri temizler.
const NIGHT_VISION = 16;
const ADD = 1;
const REMOVE = 3;

defineModule(
  { name: "Fullbright+", defaultState: false, description: "Her yer aydinlik" },
  {
    amplifier: { type: "number", name: "Efekt Seviyesi", def: 0, min: 0, max: 5, step: 1 },
    duration: { type: "number", name: "Efekt Suresi (tick)", def: 3600, min: 200, max: 20000, step: 100 },
    refreshTicks: { type: "number", name: "Yenileme Araligi (tick)", def: 40, min: 10, max: 400, step: 5 },
    hideParticles: { type: "boolean", name: "Parcacik Gizle", def: true },
    removeBlindness: { type: "boolean", name: "Korluk Efektini Temizle", def: true },
    removeDarkness: { type: "boolean", name: "Karanlik Efektini Temizle", def: true },
    reapplyOnRespawn: { type: "boolean", name: "Dirilince Tekrar Uygula", def: true },
    removeOnDisable: { type: "boolean", name: "Kapatinca Efekti Kaldir", def: true },
  },
  (ctx) => {
    let counter = 0;
    let wasDead = false;

    function send(effectId, op, amp, dur) {
      const session = ctx.session;
      const player = session?.entityState?.localPlayer;
      if (!player) return;
      const particles = !ctx.options.hideParticles.value;
      try {
        session.connection.sendIncomingPacket("mob_effect", {
          runtime_entity_id: player.runtimeId,
          event_id: op,
          effect_id: effectId,
          amplifier: amp,
          particles: particles,
          duration: dur,
          tick: 0,
          ambient: false,
        });
      } catch (_) {
        try {
          session.connection.sendIncomingPacket("mob_effect", {
            runtime_entity_id: player.runtimeId,
            operation: op,
            effect_type: effectId,
            amplifier: amp,
            particles: particles,
            duration: dur,
            tick: BigInt(0),
            ambient: false,
          });
        } catch (__) {}
      }
    }

    function apply() {
      send(NIGHT_VISION, ADD, ctx.options.amplifier.value, ctx.options.duration.value);
      if (ctx.options.removeBlindness.value) send(15, REMOVE, 0, 0);
      if (ctx.options.removeDarkness.value) send(30, REMOVE, 0, 0);
    }

    ctx.onEnable(() => { counter = 0; wasDead = false; apply(); });
    ctx.onDisable(() => {
      if (ctx.options.removeOnDisable.value) send(NIGHT_VISION, REMOVE, 0, 0);
      counter = 0;
    });

    ctx.on("tick", () => {
      const player = ctx.session?.entityState?.localPlayer;
      if (!player) return;
      if (ctx.options.reapplyOnRespawn.value && typeof player.health === "number") {
        if (player.health <= 0) wasDead = true;
        else if (wasDead) { wasDead = false; counter = 0; apply(); return; }
      }
      counter++;
      if (counter >= ctx.options.refreshTicks.value) { counter = 0; apply(); }
    });
  }
);
