import { defineModule, targets, EntityNetworkPlayer } from "@protohax/userscript";

// r3-client HealthTag: oyuncu isminin yanina can cubugu yazar (HP yazisi yok), cana gore renklenir.
// Kirmizi = az, Turuncu = orta, Yesil = tam dolu, Mavi = Enc. Apple (absorption / 20 ustu can).
// (Muzik artik uygulamadaki "Müzik" sekmesinde.)
// Vurus ses + animasyon efektleri: yumruk, Trigger, TPAura fark etmez; hedefin cani dusunce calisir.
const MC_RED = "\u00a7c", MC_ORANGE = "\u00a76", MC_GREEN = "\u00a7a", MC_BLUE = "\u00a79", MC_GRAY = "\u00a77", MC_WHITE = "\u00a7f", MC_RESET = "\u00a7r";
const ABSORPTION = 22;

defineModule(
  { name: "HealthTag", defaultState: false, description: "Isim + can cubugu, vurus sesi ve animasyonu" },
  {
    range: { type: "number", name: "Menzil (blok)", def: 40, min: 5, max: 150, step: 1 },
    barLength: { type: "number", name: "Cubuk Uzunlugu", def: 10, min: 4, max: 20, step: 1 },
    maxHealth: { type: "number", name: "Tam Can", def: 20, min: 10, max: 40, step: 1 },
    lowPercent: { type: "number", name: "Kirmizi Siniri (%)", def: 35, min: 5, max: 60, step: 5 },
    fullPercent: { type: "number", name: "Yesil Siniri (%)", def: 95, min: 60, max: 100, step: 5 },
    showName: { type: "boolean", name: "Ismi Goster", def: true },
    showNumber: { type: "boolean", name: "Can Sayisini Goster", def: false },
    showHearts: { type: "boolean", name: "Kalp Simgesi", def: true },
    enchApple: { type: "boolean", name: "Enc. Apple Mavi", def: true },
    alwaysShow: { type: "boolean", name: "Isim Hep Gorunsun", def: true },
    refreshTicks: { type: "number", name: "Yenileme (tick)", def: 5, min: 1, max: 40, step: 1 },
    hitSound: { type: "boolean", name: "Vurus Sesi", def: true },
    soundName: { type: "enum", name: "Ses", def: "random.orb", values: ["random.orb", "random.levelup", "random.anvil_land", "note.pling", "random.break", "mob.player.hurt"] },
    soundVolume: { type: "number", name: "Ses Seviyesi", def: 1.0, min: 0.1, max: 3.0, step: 0.1 },
    soundPitch: { type: "number", name: "Ses Tonu", def: 1.0, min: 0.5, max: 2.0, step: 0.05 },
    hurtFlash: { type: "boolean", name: "Hedefte Hasar Animasyonu", def: true },
    swingAnim: { type: "boolean", name: "Kol Sallama Animasyonu", def: true },
    ownHitOnly: { type: "boolean", name: "Sadece Yakindaki Vuruslar (6 blok)", def: true },
  },
  (ctx) => {
    const lastHp = new Map();
    const lastTag = new Map();
    const touched = new Map(); // runtimeId -> entity (kapatinca eski isme donmek icin)
    let tick = 0;

    function send(name, params) {
      try { ctx.session.connection.sendIncomingPacket(name, params); return true; } catch (_) { return false; }
    }

    function setNametag(e, text, always) {
      const meta = [{ key: "nametag", type: "string", value: text }];
      if (always) meta.push({ key: "always_show_nametag", type: "byte", value: 1 });
      const ok = send("set_entity_data", { runtime_entity_id: e.runtimeId, metadata: meta, properties: { ints: [], floats: [] }, tick: 0 });
      if (!ok) send("set_entity_data", { runtime_entity_id: e.runtimeId, metadata: meta, tick: BigInt(0) });
    }

    function hasAbsorption(e) {
      try {
        const eff = e.effects;
        if (!eff) return false;
        if (typeof eff.has === "function") return eff.has(ABSORPTION);
        if (Array.isArray(eff)) return eff.some((x) => (x?.id ?? x?.effectId ?? x) === ABSORPTION);
        return !!eff[ABSORPTION];
      } catch (_) { return false; }
    }

    function build(e) {
      const o = ctx.options;
      const max = o.maxHealth.value;
      const hp = Math.max(0, e.health ?? max);
      const pct = Math.min(100, (hp / max) * 100);
      const gold = o.enchApple.value && (hp > max || hasAbsorption(e));
      let color;
      if (gold) color = MC_BLUE;
      else if (pct >= o.fullPercent.value) color = MC_GREEN;
      else if (pct <= o.lowPercent.value) color = MC_RED;
      else color = MC_ORANGE;
      const len = o.barLength.value;
      const filled = gold ? len : Math.max(0, Math.min(len, Math.round((pct / 100) * len)));
      const bar = color + "|".repeat(filled) + MC_GRAY + "-".repeat(len - filled);
      const name = String(e.username ?? e.name ?? "");
      let t = "";
      if (o.showName.value) t += MC_WHITE + name + " ";
      if (o.showHearts.value) t += color + "\u2665 ";
      t += MC_GRAY + "<" + bar + MC_GRAY + ">";
      if (o.showNumber.value) t += " " + color + hp.toFixed(1);
      return t + MC_RESET;
    }

    function dist2(a, b) {
      const dx = a.x - b.x, dy = a.y - b.y, dz = a.z - b.z;
      return dx * dx + dy * dy + dz * dz;
    }

    function playSound(name, pos, vol, pitch) {
      send("play_sound", { name, coordinates: { x: Math.round(pos.x * 8), y: Math.round(pos.y * 8), z: Math.round(pos.z * 8) }, volume: vol, pitch });
    }

    function hitEffects(player, e) {
      const o = ctx.options;
      if (o.hitSound.value) playSound(o.soundName.value, e.position, o.soundVolume.value, o.soundPitch.value);
      if (o.hurtFlash.value) {
        if (!send("entity_event", { runtime_entity_id: e.runtimeId, event_id: "hurt_animation", data: 0 }))
          send("entity_event", { runtime_entity_id: e.runtimeId, event_id: 2, data: 0 });
      }
      if (o.swingAnim.value) {
        if (!send("animate", { action_id: "swing_arm", runtime_entity_id: player.runtimeId }))
          send("animate", { action_id: 1, runtime_entity_id: player.runtimeId });
      }
    }

    function restore() {
      for (const e of touched.values()) {
        try { setNametag(e, String(e.username ?? e.name ?? ""), false); } catch (_) {}
      }
      touched.clear(); lastTag.clear(); lastHp.clear();
    }

    ctx.onEnable(() => { tick = 0; lastHp.clear(); lastTag.clear(); });
    ctx.onDisable(() => { restore(); });
    ctx.onPacket("transfer", () => { lastHp.clear(); lastTag.clear(); touched.clear(); });

    ctx.on("tick", () => {
      try {
        const session = ctx.session;
        const player = session?.entityState?.localPlayer;
        if (!player) return;
        const o = ctx.options;
        tick++;

        const rSq = o.range.value ** 2;
        const refresh = tick % o.refreshTicks.value === 0;
        for (const e of session.entityState.entities.values()) {
          if (e === player || !(e instanceof EntityNetworkPlayer)) continue;
          const d = dist2(e.position, player.position);
          if (d > rSq) continue;

          const hp = e.health;
          if (typeof hp === "number") {
            const prev = lastHp.get(e.runtimeId);
            if (prev !== undefined && hp < prev && (!o.ownHitOnly.value || d <= 36)) hitEffects(player, e);
            lastHp.set(e.runtimeId, hp);
          }

          if (refresh) {
            const tag = build(e);
            if (lastTag.get(e.runtimeId) !== tag || tick % (o.refreshTicks.value * 8) === 0) {
              setNametag(e, tag, o.alwaysShow.value);
              lastTag.set(e.runtimeId, tag);
            }
            touched.set(e.runtimeId, e);
          }
        }
      } catch (_) {}
    });
  }
);
