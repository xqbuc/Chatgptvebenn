// HoldSneak — sneak tuşunu sürekli basılı tutar.
import { defineModule } from "@protohax/userscript";

const N = (name, def, min, max, step) => ({ type: "number", name, def, min, max, step });
const B = (name, def) => ({ type: "boolean", name, def });

defineModule(
  { name: "HoldSneak" },
  {
    onlyGround: B("Only On Ground", true),
    onlyAir: B("Only In Air", false),
    onlyMoving: B("Only While Moving", false),
    onlyStill: B("Only While Standing Still", false),
    pulse: B("Pulse (sneak on/off)", false),
    pulseOn: N("Pulse On (ticks)", 10, 1, 100, 1),
    pulseOff: N("Pulse Off (ticks)", 5, 1, 100, 1),
    pulseRandom: N("Pulse Randomness (+ticks)", 0, 0, 20, 1),
    startDelay: N("Start Delay (ticks)", 0, 0, 100, 1),
    maxTicks: N("Max Continuous Ticks (0 = off)", 0, 0, 1200, 20),
    restTicks: N("Rest After Limit (ticks)", 20, 1, 200, 5),
    minHealth: N("Disable Below Health (0 = off)", 0, 0, 20, 1),
    chance: N("Chance Per Tick (%)", 100, 1, 100, 1),
    // --- yeni ayarlar ---
    pauseTrig: { type: "trigger", name: "Pause / Resume" },
    pitchMin: N("Only When Pitch Above (deg)", -90, -90, 90, 5),
    pitchMax: N("Only When Pitch Below (deg)", 90, -90, 90, 5),
    minY: N("Only Above Y (0 = off)", 0, 0, 320, 1),
    maxY: N("Only Below Y (0 = off)", 0, 0, 320, 1),
    releaseJump: B("Release While Jumping", false),
    tapEvery: N("Release 1 Tick Every (ticks, 0 = off)", 0, 0, 200, 1),
    tapRandom: N("Release Interval Randomness (+ticks)", 0, 0, 40, 1),
    tapLength: N("Release Length (ticks)", 1, 1, 10, 1),
    dutyOn: N("Duty Cycle On (s, 0 = off)", 0, 0, 120, 1),
    dutyOff: N("Duty Cycle Off (s)", 5, 1, 120, 1),
    fadeRate: N("Chance Decay (%/s)", 0, 0, 20, 1),
    fadeMin: N("Chance Floor (%)", 50, 1, 100, 1),
    hurtPause: N("Release After Hurt (ticks)", 0, 0, 100, 1),
    onlyWhenHurt: N("Only For N Ticks After Hurt (0 = off)", 0, 0, 400, 5),
  },
  (ctx) => {
    let n = 0, run = 0, rest = 0, extra = 0, paused = false, pitch = 0, jumping = false;
    let lastHp = null, hurtLeft = 0, sinceHurt = 99999, tapIn = 0, tapLeft = 0, tapNext = 0;
    const me = () => ctx.session.entityState.localPlayer;
    const rollTap = () => { tapNext = ctx.options.tapEvery.value + Math.floor(Math.random() * (ctx.options.tapRandom.value + 1)); };
    ctx.onEnable(() => { n = 0; run = 0; rest = 0; extra = 0; paused = false; lastHp = null; hurtLeft = 0; sinceHurt = 99999; tapIn = 0; tapLeft = 0; rollTap(); });
    ctx.options.pauseTrig.subscribe(() => { paused = !paused; });
    ctx.on("movement_tick", (state) => { pitch = state.rotation.x; jumping = !!state.isJumping; });
    ctx.on("input_tick", (input) => {
      const o = ctx.options;
      const p = me();
      n++;
      const hp = p.health;
      if (lastHp !== null && hp < lastHp) { hurtLeft = o.hurtPause.value; sinceHurt = 0; } else sinceHurt++;
      lastHp = hp;
      if (paused) return;
      if (n <= o.startDelay.value) return;
      if (hurtLeft > 0) { hurtLeft--; return; }
      if (o.onlyWhenHurt.value > 0 && sinceHurt > o.onlyWhenHurt.value) return;
      if (rest > 0) { rest--; return; }
      if (o.dutyOn.value > 0) {
        const cyc = (o.dutyOn.value + o.dutyOff.value) * 20;
        if ((n % cyc) >= o.dutyOn.value * 20) return;
      }
      if (o.onlyGround.value && !input.onGround) return;
      if (o.onlyAir.value && input.onGround) return;
      if (o.onlyMoving.value && !input.isMoving) return;
      if (o.onlyStill.value && input.isMoving) return;
      if (o.releaseJump.value && jumping) return;
      if (pitch < o.pitchMin.value || pitch > o.pitchMax.value) return;
      const y = p.position.y;
      if (o.minY.value > 0 && y < o.minY.value) return;
      if (o.maxY.value > 0 && y > o.maxY.value) return;
      if (o.minHealth.value > 0 && hp <= o.minHealth.value) return;
      if (o.tapEvery.value > 0) {
        if (tapLeft > 0) { tapLeft--; return; }
        if (++tapIn >= tapNext) { tapIn = 0; tapLeft = o.tapLength.value - 1; rollTap(); return; }
      }
      let ch = o.chance.value;
      if (o.fadeRate.value > 0) ch = Math.max(o.fadeMin.value, ch - (run / 20) * o.fadeRate.value);
      if (Math.random() * 100 >= ch) return;
      run++;
      if (o.maxTicks.value > 0 && run > o.maxTicks.value) { run = 0; rest = o.restTicks.value; return; }
      if (o.pulse.value) {
        const period = o.pulseOn.value + o.pulseOff.value + extra;
        const pos = (run - 1) % period;
        if (pos === 0) extra = Math.floor(Math.random() * (o.pulseRandom.value + 1));
        if (pos >= o.pulseOn.value) return;
      }
      input.setSneak(true);
    });
  },
);
