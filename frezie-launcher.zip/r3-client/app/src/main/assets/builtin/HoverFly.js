// HoverFly — havada asılı kalır, hareket ederken yatay uçar.
import { defineModule } from "@protohax/userscript";

const N = (name, def, min, max, step) => ({ type: "number", name, def, min, max, step });
const B = (name, def) => ({ type: "boolean", name, def });
const say = (ctx, message) => {
  try {
    ctx.session.connection.sendIncomingPacket("text", {
      type: "raw", needs_translation: false, message,
      xuid: "", platform_chat_id: "", has_filtered_message: false,
    });
  } catch (e) { console.log(message); }
};

defineModule(
  { name: "HoverFly" },
  {
    speed: N("Speed", 0.5, 0.1, 2, 0.05),
    rise: N("Vertical Drift", 0, -0.5, 0.5, 0.01),
    upSpeed: N("Rise Speed While Jumping", 0, 0, 1, 0.02),
    ramp: N("Speed Ramp Up (ticks)", 0, 0, 40, 1),
    idleDamp: N("Idle Dampen (%)", 100, 0, 100, 5),
    bobAmp: N("Bob Amplitude", 0, 0, 0.2, 0.01),
    bobSpeed: N("Bob Speed", 0.2, 0.05, 1.5, 0.05),
    maxTicks: N("Max Hover Ticks (0 = off)", 0, 0, 1200, 20),
    cooldown: N("Cooldown After Limit (ticks)", 0, 0, 400, 10),
    onlyAir: B("Only In Air", false),
    startDelay: N("Start Delay (air ticks)", 0, 0, 40, 1),
    randomness: N("Speed Randomness", 0, 0, 0.3, 0.01),
    minHealth: N("Disable Below Health (0 = off)", 0, 0, 20, 1),
    minY: N("Don't Go Below Y (0 = off)", 0, 0, 320, 1),
    maxY: N("Don't Go Above Y (0 = off)", 0, 0, 320, 1),
    pulse: B("Pulse (hover on/off)", false),
    pulseOn: N("Pulse On (ticks)", 20, 1, 120, 1),
    pulseOff: N("Pulse Off (ticks)", 10, 1, 120, 1),
    // --- yeni ayarlar ---
    speedMul: N("Speed Multiplier (%)", 100, 10, 400, 5),
    capH: N("Max Horizontal Speed (0 = off)", 0, 0, 5, 0.1),
    momentum: N("Momentum Keep (%)", 0, 0, 95, 5),
    smoothY: N("Vertical Smoothing (%)", 100, 5, 100, 5),
    glide: N("Glide Fall Speed (0 = off)", 0, 0, 0.5, 0.01),
    burstTicks: N("Start Burst Length (ticks)", 0, 0, 40, 1),
    burstMul: N("Start Burst Speed (%)", 150, 50, 400, 10),
    onlyFalling: B("Start Only While Falling", false),
    fallStart: N("Min Fall Speed To Start", 0.1, 0, 1.5, 0.05),
    lowHpBoost: N("Low Health Speed Boost (%)", 0, 0, 200, 10),
    lowHpBelow: N("Low Health Below", 8, 1, 20, 1),
    downSpeed: N("Fall Speed When Idle Only (0 = off)", 0, 0, 0.5, 0.01),
    bobRandom: N("Bob Randomness (%)", 0, 0, 100, 5),
    totalLimit: N("Total Hover Ticks Per Enable (0 = off)", 0, 0, 20000, 100),
    chat: B("Chat Feedback", false),
  },
  (ctx) => {
    let active = 0, cd = 0, air = 0, t = 0, mv = 0, burst = 0, latched = false, total = 0, wasMoving = false;
    ctx.onEnable(() => { active = 0; cd = 0; air = 0; t = 0; mv = 0; burst = 0; latched = false; total = 0; wasMoving = false; });
    ctx.on("movement_tick", (state) => {
      const o = ctx.options;
      const p = ctx.session.entityState.localPlayer;
      if (cd > 0) cd--;
      if (state.onGround) { air = 0; latched = false; if (o.onlyAir.value) return; } else air++;
      if (cd > 0 || air < o.startDelay.value) return;
      if (o.minHealth.value > 0 && p.health <= o.minHealth.value) return;
      if (o.totalLimit.value > 0 && total >= o.totalLimit.value) return;
      const vy = state.motion.y;
      if (o.onlyFalling.value && !latched) {
        if (vy > -o.fallStart.value) return;
        latched = true;
      }
      t++;
      if (o.pulse.value && (t % (o.pulseOn.value + o.pulseOff.value)) >= o.pulseOn.value) return;
      active++; total++;
      if (o.maxTicks.value > 0 && active > o.maxTicks.value) {
        active = 0; cd = o.cooldown.value;
        if (o.chat.value) say(ctx, "§b[Hover]§r limit doldu");
        return;
      }
      let s = (o.speed.value + (Math.random() * 2 - 1) * o.randomness.value) * (o.speedMul.value / 100);
      if (o.lowHpBoost.value > 0 && p.health <= o.lowHpBelow.value) s *= 1 + o.lowHpBoost.value / 100;
      let idle = false;
      if (state.isMoving) {
        if (!wasMoving) burst = o.burstTicks.value;
        mv++;
        if (o.ramp.value > 0) s *= Math.min(1, mv / o.ramp.value);
        if (burst > 0) { burst--; s *= o.burstMul.value / 100; }
        const m0 = state.motion;
        state.strafe(Math.max(0.01, s), 1);
        const m1 = state.motion;
        let x = m1.x, z = m1.z;
        const k = o.momentum.value / 100;
        if (k > 0) { x = x * (1 - k) + m0.x * k; z = z * (1 - k) + m0.z * k; }
        if (o.capH.value > 0) { const h = Math.hypot(x, z); if (h > o.capH.value) { const c = o.capH.value / h; x *= c; z *= c; } }
        if (k > 0 || o.capH.value > 0) state.setMotion({ x, y: m1.y, z });
      } else {
        mv = 0; idle = true;
        const k = 1 - o.idleDamp.value / 100, m = state.motion;
        state.setMotion({ x: m.x * k, y: vy, z: m.z * k });
      }
      wasMoving = state.isMoving;
      const bobJ = 1 + (Math.random() * 2 - 1) * (o.bobRandom.value / 100);
      let target = o.rise.value + Math.sin(t * o.bobSpeed.value) * o.bobAmp.value * bobJ;
      if (o.glide.value > 0 && !state.isJumping) target = -o.glide.value;
      if (idle && o.downSpeed.value > 0 && !state.isJumping) target = -o.downSpeed.value;
      if (state.isJumping && o.upSpeed.value > 0) target = o.upSpeed.value;
      const y = p.position.y;
      if (o.minY.value > 0 && y < o.minY.value) target = Math.max(target, 0.1);
      if (o.maxY.value > 0 && y > o.maxY.value) target = Math.min(target, -0.1);
      state.addMotion({ x: 0, y: (target - vy) * (o.smoothY.value / 100), z: 0 });
    });
  },
);
