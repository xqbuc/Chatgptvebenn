// LagPulse (FakeLag) — hareket paketlerini periyodik olarak tutup bırakır.
import { defineModule } from "@protohax/userscript";

const N = (name, def, min, max, step) => ({ type: "number", name, def, min, max, step });
const B = (name, def) => ({ type: "boolean", name, def });
const say = (ctx, message) => {
  try {
    ctx.session.connection.sendIncomingPacket("text", {
      type: "raw", needs_translation: false, message,
      xuid: "", platform_chat_id: "", has_filtered_message: false,
    });
  } catch (e) { console.log(message); }
};

defineModule(
  { name: "LagPulse" },
  {
    hold: N("Hold (ticks)", 5, 1, 20, 1),
    gap: N("Gap (ticks)", 10, 1, 40, 1),
    holdRandom: N("Hold Randomness (+ticks)", 0, 0, 10, 1),
    gapRandom: N("Gap Randomness (+ticks)", 0, 0, 20, 1),
    releaseOnHurt: B("Release When Hurt", false),
    releaseBelow: N("Release Below Health (0 = off)", 0, 0, 20, 1),
    onlyMoving: B("Hold Only While Moving", false),
    onlyGround: B("Hold Only On Ground", false),
    onlyAir: B("Hold Only In Air", false),
    releaseOnLand: B("Release On Landing", false),
    maxPulses: N("Stop After Pulses (0 = off)", 0, 0, 500, 5),
    startInGap: B("Start With Gap", false),
    // --- yeni ayarlar ---
    hardCap: N("Hard Max Held Ticks (safety)", 30, 2, 100, 1),
    escalate: N("Hold Escalation Per Pulse (ticks)", 0, 0, 5, 1),
    escalateMax: N("Escalation Max Hold (ticks)", 12, 1, 40, 1),
    earlyChance: N("Early Release Chance (%)", 0, 0, 100, 5),
    releaseOnJump: B("Release On Jump", false),
    releaseOnStop: B("Release When Stopping", false),
    minMoveTicks: N("Min Moving Ticks Before Hold", 0, 0, 40, 1),
    hurtCooldown: N("No Hold After Hurt (ticks)", 0, 0, 100, 5),
    healthAbove: N("Hold Only Above Health (0 = off)", 0, 0, 20, 1),
    warmup: N("Warm-up Before First Hold (ticks)", 0, 0, 100, 5),
    autoStopSec: N("Auto Stop After (s, 0 = off)", 0, 0, 600, 5),
    holdTransactions: B("Also Hold Item Transactions", false),
    holdAnimate: B("Also Hold Swing Packets", false),
    chat: B("Chat Pulse Count", false),
  },
  (ctx) => {
    let holding = false, flushing = false, n = 0, holdLen = 1, gapLen = 1, pulses = 0, lastHp = null;
    let moving = false, ground = true, jumping = false, heldTicks = 0, moveTicks = 0, hurtLeft = 0, life = 0, extraHold = 0, stopped = false;
    const conn = () => ctx.session.connection;
    const checker = {
      shouldQueue: (name, body, isIncoming) => {
        if (!holding || isIncoming || stopped) return false;
        const o = ctx.options;
        if (name === "inventory_transaction") return o.holdTransactions.value;
        if (name === "animate") return o.holdAnimate.value;
        if (name !== "player_auth_input") return false;
        if (o.onlyMoving.value && !moving) return false;
        if (o.onlyGround.value && !ground) return false;
        if (o.onlyAir.value && ground) return false;
        return true;
      },
    };
    const roll = () => {
      const o = ctx.options;
      holdLen = o.hold.value + extraHold + Math.floor(Math.random() * (o.holdRandom.value + 1));
      holdLen = Math.min(holdLen, o.hardCap.value);
      gapLen = o.gap.value + Math.floor(Math.random() * (o.gapRandom.value + 1));
    };
    const release = () => { flushing = true; conn().flushHeld(false); flushing = false; heldTicks = 0; };

    ctx.onEnable(() => {
      n = 0; pulses = 0; lastHp = null; life = 0; extraHold = 0; hurtLeft = 0; moveTicks = 0; stopped = false; heldTicks = 0;
      roll();
      holding = !ctx.options.startInGap.value;
      conn().addPacketQueueChecker(checker);
    });
    ctx.onDisable(() => { holding = false; conn().removePacketQueueChecker(checker); release(); });
    ctx.on("movement_tick", (state) => {
      const o = ctx.options;
      const wasMoving = moving;
      moving = state.isMoving;
      moveTicks = moving ? moveTicks + 1 : 0;
      const was = ground; ground = state.onGround;
      const j = !!state.isJumping;
      const jumpStart = j && !jumping; jumping = j;
      if (!was && ground && o.releaseOnLand.value && holding) { holding = false; n = 0; release(); }
      if (jumpStart && o.releaseOnJump.value && holding) { holding = false; n = 0; release(); }
      if (wasMoving && !moving && o.releaseOnStop.value && holding) { holding = false; n = 0; release(); }
    });
    ctx.on("tick", () => {
      if (flushing) return;
      const o = ctx.options;
      const hp = ctx.session.entityState.localPlayer.health;
      const hurt = lastHp !== null && hp < lastHp;
      lastHp = hp;
      life++;
      if (hurt) hurtLeft = o.hurtCooldown.value; else if (hurtLeft > 0) hurtLeft--;
      if (o.autoStopSec.value > 0 && life > o.autoStopSec.value * 20) { stopped = true; if (holding) { holding = false; release(); } return; }
      if (o.maxPulses.value > 0 && pulses >= o.maxPulses.value) { if (holding) { holding = false; release(); } return; }
      if (holding) {
        heldTicks++;
        if (heldTicks >= o.hardCap.value) { holding = false; n = 0; release(); return; }
      }
      if (life < o.warmup.value) { if (holding) { holding = false; release(); } return; }
      n++;
      const low = o.releaseBelow.value > 0 && hp <= o.releaseBelow.value;
      const blocked = hurtLeft > 0 || (o.healthAbove.value > 0 && hp <= o.healthAbove.value) ||
        (o.minMoveTicks.value > 0 && moveTicks < o.minMoveTicks.value);
      if (holding && ((o.releaseOnHurt.value && hurt) || low || blocked)) { holding = false; n = 0; release(); return; }
      const early = holding && o.earlyChance.value > 0 && n > 1 && Math.random() * 100 < o.earlyChance.value / Math.max(1, holdLen);
      if (holding && (n >= holdLen || early)) {
        holding = false; n = 0; pulses++;
        release();
        if (o.escalate.value > 0) extraHold = Math.min(extraHold + o.escalate.value, Math.max(0, o.escalateMax.value - o.hold.value));
        roll();
        if (o.chat.value) say(ctx, `§e[LagPulse]§r pulse #${pulses}`);
      } else if (!holding && n >= gapLen && !blocked) { holding = true; n = 0; }
    });
  },
);
