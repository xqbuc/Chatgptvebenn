// LowHealthAlert — canın eşiğin altına düşünce uyarı yazar.
import { defineModule } from "@protohax/userscript";

const N = (name, def, min, max, step) => ({ type: "number", name, def, min, max, step });
const B = (name, def) => ({ type: "boolean", name, def });
const say = (ctx, message) => {
  try {
    ctx.session.connection.sendIncomingPacket("text", {
      type: "raw", needs_translation: false, message,
      xuid: "", platform_chat_id: "", has_filtered_message: false,
    });
  } catch (e) { console.log(message); }
};

defineModule(
  { name: "LowHealthAlert" },
  {
    threshold: N("Health Threshold", 6, 1, 19, 1),
    critical: N("Critical Threshold (0 = off)", 3, 0, 19, 1),
    repeat: N("Repeat Every (s, 0 = once)", 0, 0, 60, 1),
    hysteresis: N("Reset Margin", 2, 0, 10, 1),
    damageAlert: B("Alert On Big Hit", false),
    bigHit: N("Big Hit Size", 6, 1, 19, 1),
    showBar: B("Show Health Bar", true),
    showPercent: B("Show Percent", false),
    healAlert: B("Alert When Recovered", false),
    deathAlert: B("Alert On Death", false),
    prefixColor: N("Prefix Color (0-15)", 12, 0, 15, 1),
    // --- yeni ayarlar ---
    mid: N("Medium Threshold (0 = off)", 0, 0, 19, 1),
    maxHp: N("Max Health (bar / percent)", 20, 1, 40, 1),
    barLen: N("Bar Length", 10, 3, 30, 1),
    barFull: N("Bar Full Color (0-15)", 12, 0, 15, 1),
    barEmpty: N("Bar Empty Color (0-15)", 7, 0, 15, 1),
    showHearts: B("Show Hearts (HP / 2)", false),
    showDelta: B("Show Change Since Last Alert", false),
    showLowest: B("Show Lowest This Life", false),
    cooldown: N("Min Gap Between Alerts (s)", 0, 0, 60, 1),
    maxAlerts: N("Max Alerts Per Life (0 = off)", 0, 0, 50, 1),
    burstAlert: B("Alert On Burst Damage", false),
    burstWindow: N("Burst Window (ticks)", 20, 2, 200, 2),
    burstSize: N("Burst Damage Size", 8, 1, 40, 1),
    startDelay: N("Ignore First (s)", 0, 0, 30, 1),
    printStats: { type: "trigger", name: "Print Stats" },
  },
  (ctx) => {
    let warned = false, warnedMid = false, crit = false, since = 0, lastHp = null, dead = false;
    let lastAlertHp = null, lowest = null, alerts = 0, gap = 0, elapsed = 0, hp = 20, deaths = 0;
    let hist = [];
    const hex = "0123456789abcdef";
    const col = (n) => hex[Math.max(0, Math.min(15, n))];
    const o = () => ctx.options;
    const bar = (v, max) => {
      const len = o().barLen.value;
      const f = Math.max(0, Math.min(len, Math.round((v / max) * len)));
      return `§${col(o().barFull.value)}${"|".repeat(f)}§${col(o().barEmpty.value)}${"|".repeat(len - f)}§r`;
    };
    const pre = () => `§${col(o().prefixColor.value)}[Alert]§r`;
    const fmt = (txt) => {
      const mx = o().maxHp.value;
      let s = `${pre()} ${txt}: ${Math.round(hp)}`;
      if (o().showHearts.value) s += ` (${(hp / 2).toFixed(1)}♥)`;
      if (o().showPercent.value) s += ` (${Math.round((hp / mx) * 100)}%)`;
      if (o().showDelta.value && lastAlertHp !== null) { const d = Math.round(hp - lastAlertHp); s += ` [${d >= 0 ? "+" : ""}${d}]`; }
      if (o().showLowest.value && lowest !== null) s += ` §7min ${Math.round(lowest)}§r`;
      if (o().showBar.value) s += ` ${bar(hp, mx)}`;
      return s;
    };
    const alert = (txt, force) => {
      if (!force) {
        if (gap > 0) return false;
        if (o().maxAlerts.value > 0 && alerts >= o().maxAlerts.value) return false;
      }
      say(ctx, fmt(txt));
      lastAlertHp = hp; alerts++; gap = o().cooldown.value * 20;
      return true;
    };

    ctx.onEnable(() => { warned = false; warnedMid = false; crit = false; since = 0; lastHp = null; dead = false; lastAlertHp = null; lowest = null; alerts = 0; gap = 0; elapsed = 0; hist = []; deaths = 0; });
    ctx.options.printStats.subscribe(() => {
      say(ctx, `${pre()} Can: ${Math.round(hp)} | En düşük: ${lowest === null ? "-" : Math.round(lowest)} | Uyarı: ${alerts} | Ölüm: ${deaths}`);
    });
    ctx.on("tick", () => {
      hp = ctx.session.entityState.localPlayer.health;
      elapsed++;
      if (gap > 0) gap--;
      if (hp > 0 && (lowest === null || hp < lowest)) lowest = hp;
      if (elapsed < o().startDelay.value * 20) { lastHp = hp; return; }

      if (o().burstAlert.value) {
        hist.push(hp);
        if (hist.length > o().burstWindow.value) hist.shift();
        const drop = Math.max(...hist) - hp;
        if (hp > 0 && drop >= o().burstSize.value) { alert(`Ani hasar -${Math.round(drop)}`); hist = [hp]; }
      }
      if (lastHp !== null && o().damageAlert.value && lastHp - hp >= o().bigHit.value && hp > 0) alert(`Büyük vuruş -${Math.round(lastHp - hp)}`);
      if (hp <= 0 && !dead) {
        dead = true; deaths++;
        if (o().deathAlert.value) say(ctx, `${pre()} Öldün (#${deaths})`);
      }
      if (hp > 0 && dead) { dead = false; alerts = 0; lowest = hp; hist = []; warned = false; warnedMid = false; crit = false; }
      if (o().healAlert.value && lastHp !== null && lastHp <= o().threshold.value && hp > o().threshold.value + o().hysteresis.value) alert("Can toparlandı");
      lastHp = hp;
      since++;

      if (hp > 0 && o().critical.value > 0 && hp <= o().critical.value) {
        if (!crit) { crit = true; since = 0; alert("§4KRİTİK§r Can", true); }
      } else if (hp > o().critical.value + o().hysteresis.value) crit = false;

      if (hp > 0 && o().mid.value > 0 && hp <= o().mid.value && hp > o().threshold.value) {
        if (!warnedMid) { warnedMid = true; alert("Can azalıyor"); }
      } else if (hp > o().mid.value + o().hysteresis.value) warnedMid = false;

      if (hp > 0 && hp <= o().threshold.value) {
        if (!warned) { warned = true; since = 0; alert("Can düşük"); }
        else if (o().repeat.value > 0 && since >= o().repeat.value * 20) { since = 0; alert("Can düşük"); }
      } else if (hp > o().threshold.value + o().hysteresis.value) warned = false;
    });
  },
);
