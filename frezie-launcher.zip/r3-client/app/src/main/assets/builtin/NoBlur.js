import { defineModule } from "@protohax/userscript";

// r3-client NoBlur: ekrani bulaniklastiran efektleri (mide bulantisi, korluk, karanlik...) temizler.
const REMOVE = 3;

defineModule(
  { name: "NoBlur", togglable: true, defaultState: false, description: "Ekran bulaniklastirmayi kaldir" },
  {
    removeNausea: { type: "boolean", name: "Mide Bulantisi (Nausea)", def: true },
    removeBlindness: { type: "boolean", name: "Korluk (Blindness)", def: true },
    removeDarkness: { type: "boolean", name: "Karanlik (Darkness)", def: true },
    removeSlowness: { type: "boolean", name: "Yavaslik (Slowness)", def: false },
    removeMiningFatigue: { type: "boolean", name: "Madencilik Yorgunlugu", def: false },
    refreshTicks: { type: "number", name: "Kontrol Araligi (tick)", def: 10, min: 1, max: 100, step: 1 },
    onlyWhenPresent: { type: "boolean", name: "Sadece Efekt Varsa Gonder", def: true },
    burstOnHurt: { type: "boolean", name: "Hasar Alinca Hemen Temizle", def: true },
    clearOnEnable: { type: "boolean", name: "Acilinca Hemen Temizle", def: true },
  },
  (ctx) => {
    let counter = 0;
    let lastHp = null;

    function has(player, id) {
      try {
        if (player.effects && typeof player.effects.has === "function") return !!player.effects.has(id);
      } catch (_) {}
      return true;
    }

    function remove(player, id) {
      const session = ctx.session;
      if (ctx.options.onlyWhenPresent.value && !has(player, id)) return;
      try {
        session.connection.sendIncomingPacket("mob_effect", {
          runtime_entity_id: player.runtimeId,
          event_id: REMOVE,
          effect_id: id,
          amplifier: 0,
          particles: false,
          duration: 0,
          tick: 0,
          ambient: false,
        });
      } catch (_) {
        try {
          session.connection.sendIncomingPacket("mob_effect", {
            runtime_entity_id: player.runtimeId,
            operation: REMOVE,
            effect_type: id,
            amplifier: 0,
            particles: false,
            duration: 0,
            tick: BigInt(0),
            ambient: false,
          });
        } catch (__) {}
      }
    }

    function sweep() {
      const player = ctx.session?.entityState?.localPlayer;
      if (!player) return;
      if (ctx.options.removeNausea.value) remove(player, 9);
      if (ctx.options.removeBlindness.value) remove(player, 15);
      if (ctx.options.removeDarkness.value) remove(player, 30);
      if (ctx.options.removeSlowness.value) remove(player, 2);
      if (ctx.options.removeMiningFatigue.value) remove(player, 4);
    }

    ctx.onEnable(() => { counter = 0; lastHp = null; if (ctx.options.clearOnEnable.value) sweep(); });

    ctx.on("tick", () => {
      const player = ctx.session?.entityState?.localPlayer;
      if (!player) return;
      if (ctx.options.burstOnHurt.value && typeof player.health === "number") {
        if (lastHp !== null && player.health < lastHp) { sweep(); }
        lastHp = player.health;
      }
      counter++;
      if (counter >= ctx.options.refreshTicks.value) { counter = 0; sweep(); }
    });
  }
);
