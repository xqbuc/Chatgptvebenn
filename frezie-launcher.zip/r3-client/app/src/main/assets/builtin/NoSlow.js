import { defineModule } from "@protohax/userscript";

// r3-client NoSlow: esya kullanirken ve yavaslatan bloklarda hiz kaybini azaltir.
defineModule(
  { name: "NoSlow", togglable: true, defaultState: false, description: "Yavaslamayi engelle" },
  {
    mode: { type: "enum", name: "Mod", def: "Restore", values: ["Restore", "Set", "Jitter"] },
    itemStrength: { type: "number", name: "Esya Yavaslamasi Engelleme (%)", def: 100, min: 0, max: 100, step: 5 },
    setSpeed: { type: "number", name: "Set Hizi (blok/tick)", def: 0.1, min: 0.02, max: 0.4, step: 0.005 },
    jitterAmount: { type: "number", name: "Jitter Miktari", def: 0.02, min: 0.0, max: 0.1, step: 0.005 },
    onlyWhenMoving: { type: "boolean", name: "Sadece Hareketteyken", def: true },
    invertStrafe: { type: "boolean", name: "Strafe Yonunu Ters Cevir", def: false },
    sprintWhileUsing: { type: "boolean", name: "Kullanirken Sprint", def: false },
    keepSneakSlow: { type: "boolean", name: "Cokunce Normal Yavasla", def: true },
    cobweb: { type: "boolean", name: "Orumcek Agi", def: true },
    cobwebStrength: { type: "number", name: "Ag Hiz Carpani", def: 3.0, min: 1.0, max: 8.0, step: 0.1 },
    soulSand: { type: "boolean", name: "Ruh Kumu", def: true },
    soulSandStrength: { type: "number", name: "Ruh Kumu Carpani", def: 1.6, min: 1.0, max: 4.0, step: 0.1 },
    honey: { type: "boolean", name: "Bal Blogu", def: true },
    honeyStrength: { type: "number", name: "Bal Carpani", def: 1.8, min: 1.0, max: 4.0, step: 0.1 },
    maxSpeedCap: { type: "number", name: "Hiz Ustu Siniri", def: 0.45, min: 0.15, max: 2.0, step: 0.01 },
    bows: { type: "boolean", name: "Yay/Arbalet", def: true },
    food: { type: "boolean", name: "Yiyecek/Icecek", def: true },
    shield: { type: "boolean", name: "Kalkan", def: true },
  },
  (ctx) => {
    let tick = 0;

    function using(p) {
      try {
        if (typeof p.isUsingItem === "boolean") return p.isUsingItem;
        return !!(p.hasInputData?.("start_using_item") || p.hasInputData?.("continue_using_item"));
      } catch (_) { return false; }
    }
    function itemAllowed(p) {
      let n = "";
      try { n = String(p.inventory?.hand?.name ?? p.inventory?.hand?.identifier ?? ""); } catch (_) {}
      if (n === "") return true;
      if (n.includes("bow") || n.includes("trident")) return ctx.options.bows.value;
      if (n.includes("shield")) return ctx.options.shield.value;
      return ctx.options.food.value;
    }
    function blockName(session, x, y, z) {
      try {
        const b = session.levelState.getBlock(Math.floor(x), Math.floor(y), Math.floor(z));
        return b && b.name ? b.name : "";
      } catch (_) { return ""; }
    }

    ctx.onEnable(() => { tick = 0; });

    ctx.on("movement_tick", (state) => {
      const session = ctx.session;
      if (!session) return;
      const player = session.entityState?.localPlayer;
      if (!player) return;
      tick++;

      const mi = state.moveInput;
      const moving = !!(mi && (mi.x || mi.y));
      if (ctx.options.onlyWhenMoving.value && !moving) return;
      if (ctx.options.keepSneakSlow.value && player.isSneaking) return;

      const m = state.motion;
      const pos = state.position;
      let mult = 1;

      if (using(player) && itemAllowed(player)) {
        const pct = ctx.options.itemStrength.value / 100;
        mult *= 1 + 4 * pct;
        if (ctx.options.sprintWhileUsing.value) { try { player.sprinting = true; } catch (_) {} }
      }

      const feet = blockName(session, pos.x, pos.y, pos.z);
      const below = blockName(session, pos.x, pos.y - 0.2, pos.z);
      const both = feet + "|" + below;
      if (ctx.options.cobweb.value && both.includes("web")) mult *= ctx.options.cobwebStrength.value;
      if (ctx.options.soulSand.value && both.includes("soul_sand")) mult *= ctx.options.soulSandStrength.value;
      if (ctx.options.honey.value && both.includes("honey")) mult *= ctx.options.honeyStrength.value;

      if (mult === 1) return;

      const mode = ctx.options.mode.value;
      let nx = m.x;
      let nz = m.z;
      if (mode === "Set" && moving) {
        const f = mi.y;
        const s = ctx.options.invertStrafe.value ? -mi.x : mi.x;
        const yaw = (player.rotation.y * Math.PI) / 180;
        let x = -Math.sin(yaw) * f + Math.cos(yaw) * s;
        let z = Math.cos(yaw) * f + Math.sin(yaw) * s;
        const len = Math.sqrt(x * x + z * z) || 1;
        nx = (x / len) * ctx.options.setSpeed.value;
        nz = (z / len) * ctx.options.setSpeed.value;
      } else {
        let k = mult;
        if (mode === "Jitter") k = mult * (1 - Math.random() * ctx.options.jitterAmount.value * 4);
        nx = m.x * k;
        nz = m.z * k;
      }

      const sp = Math.sqrt(nx * nx + nz * nz);
      const cap = ctx.options.maxSpeedCap.value;
      if (sp > cap) { nx = (nx / sp) * cap; nz = (nz / sp) * cap; }
      state.setMotion({ x: nx, y: m.y, z: nz });
    });
  }
);
