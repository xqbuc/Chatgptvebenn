import { defineModule, utils } from "@protohax/userscript";

// r3-client Noclip: bloklarin icinden gecis. Konumu her tick elle ilerletir.
defineModule(
  { name: "Noclip", togglable: true, defaultState: false, description: "Bloklarin icinden gec" },
  {
    mode: { type: "enum", name: "Mod", def: "Phase", values: ["Phase", "Freeze", "Smooth"] },
    horizontalSpeed: { type: "number", name: "Yatay Hiz", def: 0.25, min: 0.05, max: 2.0, step: 0.05 },
    verticalSpeed: { type: "number", name: "Dikey Hiz", def: 0.25, min: 0.05, max: 2.0, step: 0.05 },
    onlyInsideBlocks: { type: "boolean", name: "Sadece Blok Icindeyken", def: false },
    jumpUp: { type: "boolean", name: "Ziplayinca Yuksel", def: true },
    sneakDown: { type: "boolean", name: "Cokunce Alcal", def: true },
    holdPosition: { type: "boolean", name: "Tus Birakinca Sabit Kal", def: true },
    invertStrafe: { type: "boolean", name: "Strafe Yonunu Ters Cevir", def: false },
    smoothing: { type: "number", name: "Yumusatma (Smooth modu)", def: 0.5, min: 0.1, max: 1.0, step: 0.05 },
    groundSpoof: { type: "boolean", name: "Ground Spoof", def: true },
    noFall: { type: "boolean", name: "Dusme Hasarini Engelle", def: true },
    stepDelay: { type: "number", name: "Adim Gecikmesi (tick)", def: 1, min: 1, max: 5, step: 1 },
    maxDistance: { type: "number", name: "Baslangictan Max Mesafe (0=sinirsiz)", def: 0, min: 0, max: 200, step: 5 },
    safeExit: { type: "boolean", name: "Kapatinca Bos Yere Cik", def: true },
  },
  (ctx) => {
    let tick = 0;
    let origin = null;

    function solid(session, x, y, z) {
      try {
        const b = session.levelState.getBlock(Math.floor(x), Math.floor(y), Math.floor(z));
        const n = b && b.name ? b.name : "";
        return n !== "" && !n.includes("air") && !n.includes("water") && !n.includes("lava");
      } catch (_) { return false; }
    }

    ctx.onEnable(() => { tick = 0; origin = null; });
    ctx.onDisable(() => { origin = null; });
    ctx.onPacket("transfer", () => { origin = null; });

    ctx.on("movement_tick", (state) => {
      const session = ctx.session;
      if (!session) return;
      const player = session.entityState?.localPlayer;
      if (!player) return;
      tick++;

      const pos = state.position;
      if (!origin) origin = new utils.Vector3(pos.x, pos.y, pos.z);

      if (ctx.options.onlyInsideBlocks.value) {
        const inside = solid(session, pos.x, pos.y, pos.z) || solid(session, pos.x, pos.y + 1, pos.z);
        if (!inside) return;
      }
      if (tick % ctx.options.stepDelay.value !== 0) return;

      const mi = state.moveInput;
      let dx = 0;
      let dz = 0;
      if (mi && (mi.x || mi.y)) {
        const f = mi.y;
        const s = ctx.options.invertStrafe.value ? -mi.x : mi.x;
        const yaw = (player.rotation.y * Math.PI) / 180;
        let x = -Math.sin(yaw) * f + Math.cos(yaw) * s;
        let z = Math.cos(yaw) * f + Math.sin(yaw) * s;
        const len = Math.sqrt(x * x + z * z) || 1;
        dx = (x / len) * ctx.options.horizontalSpeed.value;
        dz = (z / len) * ctx.options.horizontalSpeed.value;
      }
      let dy = 0;
      if (ctx.options.jumpUp.value && player.isJumping) dy = ctx.options.verticalSpeed.value;
      if (ctx.options.sneakDown.value && player.isSneaking) dy = -ctx.options.verticalSpeed.value;

      if (dx === 0 && dz === 0 && dy === 0 && ctx.options.holdPosition.value) {
        state.setMotion({ x: 0, y: 0, z: 0 });
        return;
      }

      let nx = pos.x + dx;
      let ny = pos.y + dy;
      let nz = pos.z + dz;
      if (ctx.options.mode.value === "Smooth") {
        const k = ctx.options.smoothing.value;
        nx = pos.x + dx * k; ny = pos.y + dy * k; nz = pos.z + dz * k;
      }

      const md = ctx.options.maxDistance.value;
      if (md > 0) {
        const ox = nx - origin.x;
        const oz = nz - origin.z;
        if (Math.sqrt(ox * ox + oz * oz) > md) return;
      }

      state.setPosition(new utils.Vector3(nx, ny, nz));
      state.setMotion({ x: 0, y: 0, z: 0 });
      if (ctx.options.groundSpoof.value || ctx.options.noFall.value) player.onGround = true;
    });
  }
);
