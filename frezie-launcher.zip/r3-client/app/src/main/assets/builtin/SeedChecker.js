import { defineModule } from "@protohax/userscript";

// r3-client SeedChecker: sunucunun gonderdigi dunya seed'ini sohbete yazar. Mesaj sadece sana gorunur (sunucuya gitmez).
const say = (ctx, message) => {
  try {
    ctx.session.connection.sendIncomingPacket("text", {
      type: "raw", needs_translation: false, message,
      xuid: "", platform_chat_id: "", has_filtered_message: false,
    });
  } catch (e) { console.log(message); }
};

function findSeed(a, b) {
  const cand = [a, b, a && a.params, b && b.params, a && a.body, b && b.body];
  for (const c of cand) {
    if (c && typeof c === "object" && c.seed !== undefined && c.seed !== null) return c;
  }
  return null;
}

defineModule(
  { name: "SeedChecker", defaultState: false, description: "Seed'i sohbette (sadece sana) gosterir" },
  {
    autoPrint: { type: "boolean", name: "Sunucuya Girince Otomatik Yaz", def: true },
    showWorld: { type: "boolean", name: "Dunya Adini da Yaz", def: true },
    printNow: { type: "trigger", name: "Seed'i Simdi Yaz" },
  },
  (ctx) => {
    let last = null;
    const show = () => {
      if (!last) { say(ctx, "§c[Seed]§r seed henuz alinmadi (sunucuya yeniden girmen gerekebilir)"); return; }
      let msg = "§b[Seed]§r " + last.seed;
      if (ctx.options.showWorld.value && last.world) msg += " §7(" + last.world + ")";
      say(ctx, msg);
    };

    ctx.onEnable(() => { if (last) show(); });
    ctx.options.printNow.subscribe(show);
    ctx.onPacket("start_game", (a, b) => {
      const pk = findSeed(a, b);
      if (!pk) return;
      last = { seed: String(pk.seed), world: pk.world_name ?? pk.level_name ?? null };
      if (ctx.options.autoPrint.value) show();
    });
  }
);
