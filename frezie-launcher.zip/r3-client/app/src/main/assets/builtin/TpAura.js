import { defineModule, utils, targets, EntityNetworkPlayer, EntityCreature } from "@protohax/userscript";

// r3-client TPAura (Mega): hedefe adim adim isinlanir, vurur, istenirse geri doner.
// Fazlar: idle -> approaching -> attacking -> returning
defineModule(
  { name: "TPAura Mega", defaultState: false, description: "Isinlanarak vuran aura" },
  {
    searchRange: { type: "number", name: "Arama Menzili", def: 20, min: 3, max: 120, step: 1 },
    tpSpeed: { type: "number", name: "TP Hizi (blok/tick)", def: 2.5, min: 0.2, max: 25, step: 0.1 },
    returnSpeed: { type: "number", name: "Geri Donus Hizi (blok/tick)", def: 3.0, min: 0.2, max: 25, step: 0.1 },
    cooldown: { type: "number", name: "TP Bekleme (ms)", def: 400, min: 0, max: 5000, step: 50 },
    position: { type: "enum", name: "Konum", def: "Behind", values: ["Behind", "Front", "Above", "Side", "Random"] },
    offset: { type: "number", name: "Hedefe Uzaklik", def: 2.2, min: 0.0, max: 5.0, step: 0.1 },
    heightOffset: { type: "number", name: "Yukseklik Farki", def: 0.0, min: -3.0, max: 4.0, step: 0.1 },
    attacksPerTp: { type: "number", name: "TP Basina Vurus", def: 3, min: 1, max: 12, step: 1 },
    attackIntervalTicks: { type: "number", name: "Vurus Araligi (tick)", def: 4, min: 1, max: 20, step: 1 },
    targetPlayers: { type: "boolean", name: "Oyuncular", def: true },
    targetMobs: { type: "boolean", name: "Mob'lar", def: false },
    sortBy: { type: "enum", name: "Hedef Sirasi", def: "Distance", values: ["Distance", "Health", "Random"] },
    multiTarget: { type: "boolean", name: "Coklu Hedef Zinciri", def: false },
    maxTargets: { type: "number", name: "Max Hedef", def: 3, min: 1, max: 8, step: 1 },
    predict: { type: "boolean", name: "Hareket Tahmini", def: true },
    predictTicks: { type: "number", name: "Tahmin (tick)", def: 3, min: 0, max: 15, step: 1 },
    returnBack: { type: "boolean", name: "Vurunca Geri Don", def: true },
    returnDelay: { type: "number", name: "Geri Donus Gecikmesi (ms)", def: 300, min: 0, max: 5000, step: 50 },
    avoidVoid: { type: "boolean", name: "Bosluk Korumasi", def: true },
    voidDepth: { type: "number", name: "Bosluk Derinligi (blok)", def: 8, min: 2, max: 40, step: 1 },
    stopOnLowHealth: { type: "boolean", name: "Can Dusukse Dur", def: false },
    minHealth: { type: "number", name: "Min Can", def: 6, min: 1, max: 20, step: 1 },
    pauseOnContainer: { type: "boolean", name: "Envanter Acikken Dur", def: true },
    critHop: { type: "boolean", name: "Crit Ziplamasi", def: false },
    critForce: { type: "number", name: "Crit Ziplama Gucu", def: 0.42, min: 0.1, max: 0.8, step: 0.02 },
    swing: { type: "boolean", name: "Kol Salla", def: true },
  },
  (ctx) => {
    let phase = "idle";
    let dest = null;
    let home = null;
    let chain = [];
    let chainIdx = 0;
    let current = null;
    let lastTp = 0;
    let arriveAt = 0;
    let attackLeft = 0;
    let attackTick = 0;
    let containerOpen = false;
    let wantHop = false;

    function reset() {
      phase = "idle"; dest = null; home = null; chain = []; chainIdx = 0;
      current = null; arriveAt = 0; attackLeft = 0; attackTick = 0; wantHop = false;
    }

    ctx.onEnable(() => { reset(); lastTp = 0; });
    ctx.onDisable(() => { reset(); });
    ctx.onPacket("transfer", () => { reset(); });
    ctx.on("container_open", () => { containerOpen = true; });
    ctx.on("container_close", () => { containerOpen = false; });

    function candidates(session, player) {
      const list = [];
      const rSq = ctx.options.searchRange.value ** 2;
      for (const e of session.entityState.entities.values()) {
        if (e === player) continue;
        const isP = e instanceof EntityNetworkPlayer;
        const isM = e instanceof EntityCreature;
        if (!isP && !isM) continue;
        if (isP && !ctx.options.targetPlayers.value) continue;
        if (isM && !ctx.options.targetMobs.value) continue;
        if (!targets().isTarget(e, true)) continue;
        const dx = e.position.x - player.position.x;
        const dy = e.position.y - player.position.y;
        const dz = e.position.z - player.position.z;
        const d = dx * dx + dy * dy + dz * dz;
        if (d <= rSq) list.push({ e, d });
      }
      const sort = ctx.options.sortBy.value;
      if (sort === "Distance") list.sort((a, b) => a.d - b.d);
      else if (sort === "Health") list.sort((a, b) => (a.e.health ?? 20) - (b.e.health ?? 20));
      else list.sort(() => Math.random() - 0.5);
      return list.map((x) => x.e);
    }

    function aimPos(entity) {
      let x = entity.position.x;
      let y = entity.position.y;
      let z = entity.position.z;
      if (ctx.options.predict.value && entity.motion) {
        const t = ctx.options.predictTicks.value;
        x += entity.motion.x * t; y += entity.motion.y * t; z += entity.motion.z * t;
      }
      return { x, y, z };
    }

    function destFor(entity, from) {
      const t = aimPos(entity);
      const off = ctx.options.offset.value;
      const h = ctx.options.heightOffset.value;
      const kind = ctx.options.position.value;
      let ang;
      const dx = t.x - from.x;
      const dz = t.z - from.z;
      const base = Math.atan2(dz, dx);
      if (kind === "Behind") ang = base + Math.PI;
      else if (kind === "Front") ang = base;
      else if (kind === "Side") ang = base + Math.PI / 2;
      else if (kind === "Random") ang = Math.random() * Math.PI * 2;
      else ang = base;
      const o = kind === "Above" ? 0 : off;
      const y = kind === "Above" ? t.y + Math.max(2.5, h) : t.y + h;
      return new utils.Vector3(t.x + Math.cos(ang) * o, y, t.z + Math.sin(ang) * o);
    }

    function voidSafe(session, p) {
      if (!ctx.options.avoidVoid.value) return true;
      try {
        const depth = ctx.options.voidDepth.value;
        for (let i = 0; i <= depth; i++) {
          const b = session.levelState.getBlock(Math.floor(p.x), Math.floor(p.y - i), Math.floor(p.z));
          const n = b && b.name ? b.name : "";
          if (n !== "" && !n.includes("air") && !n.includes("lava")) return true;
        }
        return false;
      } catch (_) { return true; }
    }

    function hit(player, e) {
      player.interactEntity(e, true, player.serverSideRotation, "attack");
      if (ctx.options.swing.value) player.swingItem();
    }

    ctx.on("movement_tick", (state) => {
      const player = ctx.session?.entityState?.localPlayer;
      if (!player) return;

      if (wantHop && ctx.options.critHop.value) {
        wantHop = false;
        const m = state.motion;
        state.setMotion({ x: m.x, y: ctx.options.critForce.value, z: m.z });
        try { player.sendJumpFlagNextPacket(); } catch (_) {}
      }

      if ((phase !== "approaching" && phase !== "returning") || !dest) return;
      const cur = state.position;
      const dx = dest.x - cur.x;
      const dy = dest.y - cur.y;
      const dz = dest.z - cur.z;
      const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
      if (dist <= 0.5) {
        state.setPosition(dest);
        state.setMotion({ x: 0, y: 0, z: 0 });
        if (phase === "approaching") {
          phase = "attacking";
          attackLeft = ctx.options.attacksPerTp.value;
          attackTick = 0;
          arriveAt = Date.now();
        } else {
          reset();
          lastTp = Date.now();
        }
        dest = null;
        return;
      }
      const sp = phase === "returning" ? ctx.options.returnSpeed.value : ctx.options.tpSpeed.value;
      const step = Math.min(sp, dist);
      state.setPosition(new utils.Vector3(cur.x + (dx / dist) * step, cur.y + (dy / dist) * step, cur.z + (dz / dist) * step));
      state.setMotion({ x: 0, y: 0, z: 0 });
    });

    ctx.on("tick", () => {
      const session = ctx.session;
      if (!session) return;
      const player = session.entityState?.localPlayer;
      if (!player) return;

      if (ctx.options.pauseOnContainer.value && containerOpen) return;
      if (ctx.options.stopOnLowHealth.value && typeof player.health === "number" && player.health <= ctx.options.minHealth.value) {
        if (phase === "approaching" || phase === "attacking") {
          if (home) { phase = "returning"; dest = home; }
          else reset();
        }
        return;
      }

      if (phase === "attacking") {
        if (!current || !current.position) { reset(); lastTp = Date.now(); return; }
        attackTick++;
        if (attackTick % ctx.options.attackIntervalTicks.value === 0 && attackLeft > 0 && current) {
          if (ctx.options.critHop.value && player.onGround) wantHop = true;
          hit(player, current);
          attackLeft--;
        }
        if (attackLeft <= 0) {
          if (ctx.options.multiTarget.value && chainIdx + 1 < chain.length) {
            chainIdx++;
            current = chain[chainIdx];
            dest = destFor(current, player.position);
            if (voidSafe(session, dest)) { phase = "approaching"; }
            else { chainIdx = chain.length; }
          }
          if (phase === "attacking") {
            if (ctx.options.returnBack.value && home) {
              if (Date.now() - arriveAt >= ctx.options.returnDelay.value) { phase = "returning"; dest = home; }
            } else { reset(); lastTp = Date.now(); }
          }
        }
        return;
      }

      if (phase !== "idle") return;
      if (Date.now() - lastTp < ctx.options.cooldown.value) return;

      const found = candidates(session, player);
      if (found.length === 0) return;
      const n = ctx.options.multiTarget.value ? ctx.options.maxTargets.value : 1;
      chain = found.slice(0, n);
      chainIdx = 0;
      current = chain[0];
      const d = destFor(current, player.position);
      if (!voidSafe(session, d)) return;
      home = new utils.Vector3(player.position.x, player.position.y, player.position.z);
      dest = d;
      phase = "approaching";
    });
  }
);
