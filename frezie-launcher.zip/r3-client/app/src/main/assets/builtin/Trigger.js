import { defineModule, targets, EntityNetworkPlayer, EntityCreature } from "@protohax/userscript";

// r3-client Trigger: sadece crosshair altindaki hedefe vurur. Hitbox genisletme, crit, CPS ve dogal gecikme ayarlari var.
function rayAABB(origin, dir, aabb, maxDist, expand) {
  let tMin = 0;
  let tMax = maxDist;
  const axes = ["x", "y", "z"];
  for (const a of axes) {
    const o = origin[a];
    const d = dir[a];
    const lo = aabb.min[a] - expand;
    const hi = aabb.max[a] + expand;
    if (Math.abs(d) < 1e-8) {
      if (o < lo || o > hi) return null;
      continue;
    }
    let t1 = (lo - o) / d;
    let t2 = (hi - o) / d;
    if (t1 > t2) { const t = t1; t1 = t2; t2 = t; }
    tMin = Math.max(tMin, t1);
    tMax = Math.min(tMax, t2);
    if (tMin > tMax) return null;
  }
  return tMin;
}

defineModule(
  { name: "Trigger", defaultState: false, description: "Crosshair altindakine vurur" },
  {
    range: { type: "number", name: "Menzil", def: 3.5, min: 1.0, max: 6.0, step: 0.1 },
    hitboxExpand: { type: "number", name: "Hitbox Genisletme", def: 0.0, min: 0.0, max: 0.6, step: 0.02 },
    delay: { type: "number", name: "Saldiri Gecikmesi (ms)", def: 300, min: 0, max: 1000, step: 10 },
    delayVariance: { type: "number", name: "Gecikme Sapmasi (+-ms)", def: 50, min: 0, max: 300, step: 5 },
    maxCps: { type: "number", name: "Max CPS (0=sinirsiz)", def: 0, min: 0, max: 20, step: 1 },
    hitChance: { type: "number", name: "Vurus Sansi (%)", def: 100, min: 10, max: 100, step: 5 },
    targetPlayers: { type: "boolean", name: "Oyuncular", def: true },
    targetMobs: { type: "boolean", name: "Mob'lar", def: false },
    checkWalls: { type: "boolean", name: "Duvar Kontrolu", def: true },
    critical: { type: "boolean", name: "Sadece Crit (dususte vur)", def: false },
    critMinFall: { type: "number", name: "Crit Min Dusus", def: 0.06, min: 0.0, max: 1.0, step: 0.01 },
    onlyWeapon: { type: "boolean", name: "Sadece Silah/Balta Elde", def: false },
    pauseOnContainer: { type: "boolean", name: "Envanter Acikken Dur", def: true },
    pauseOnUse: { type: "boolean", name: "Esya Kullanirken Dur", def: true },
    pauseOnHurt: { type: "boolean", name: "Hasar Alinca Kisa Dur", def: false },
    swing: { type: "boolean", name: "Kol Salla", def: true },
    debug: { type: "boolean", name: "Debug Mesajlari", def: false },
  },
  (ctx) => {
    let lastAttack = 0;
    let nextDelay = 0;
    let containerOpen = false;
    let lastHp = null;
    let lastHurt = 0;
    let lastDebug = 0;
    const hits = [];

    function rollDelay() {
      const v = ctx.options.delayVariance.value;
      nextDelay = Math.max(0, ctx.options.delay.value + (Math.random() * 2 - 1) * v);
    }
    function usingItem(p) {
      try {
        if (typeof p.isUsingItem === "boolean") return p.isUsingItem;
        return !!(p.hasInputData?.("start_using_item") || p.hasInputData?.("continue_using_item"));
      } catch (_) { return false; }
    }
    function holdingWeapon(p) {
      try {
        const n = String(p.inventory?.hand?.name ?? p.inventory?.hand?.identifier ?? "");
        if (n === "") return true;
        return n.includes("sword") || n.includes("axe") || n.includes("mace") || n.includes("trident");
      } catch (_) { return true; }
    }

    ctx.onEnable(() => { lastAttack = 0; rollDelay(); hits.length = 0; });
    ctx.on("container_open", () => { containerOpen = true; });
    ctx.on("container_close", () => { containerOpen = false; });

    ctx.on("tick", () => {
      try {
        const session = ctx.session;
        if (!session) return;
        const player = session.entityState.localPlayer;
        if (!player) return;
        const now = Date.now();

        if (typeof player.health === "number") {
          if (lastHp !== null && player.health < lastHp) lastHurt = now;
          lastHp = player.health;
        }
        if (now - lastAttack < nextDelay) return;
        if (ctx.options.pauseOnContainer.value && containerOpen) return;
        if (ctx.options.pauseOnUse.value && usingItem(player)) return;
        if (ctx.options.pauseOnHurt.value && now - lastHurt < 250) return;
        if (ctx.options.onlyWeapon.value && !holdingWeapon(player)) return;
        if (ctx.options.critical.value) {
          const fall = player.fallDistance ?? 0;
          if (player.onGround || fall < ctx.options.critMinFall.value) return;
        }

        const cps = ctx.options.maxCps.value;
        if (cps > 0) {
          while (hits.length && now - hits[0] > 1000) hits.shift();
          if (hits.length >= cps) return;
        }

        const eye = player.eyePosition;
        const rot = player.serverSideRotation;
        const pr = (rot.x * Math.PI) / 180;
        const yr = (rot.y * Math.PI) / 180;
        const dir = { x: -Math.sin(yr) * Math.cos(pr), y: -Math.sin(pr), z: Math.cos(yr) * Math.cos(pr) };
        const maxR = ctx.options.range.value;
        const exp = ctx.options.hitboxExpand.value;

        let best = null;
        let bestD = Infinity;
        for (const e of session.entityState.entities.values()) {
          if (e === player) continue;
          const isP = e instanceof EntityNetworkPlayer;
          const isM = e instanceof EntityCreature;
          if (!isP && !isM) continue;
          if (isP && !ctx.options.targetPlayers.value) continue;
          if (isM && !ctx.options.targetMobs.value) continue;
          if (!e.canBeAttacked) continue;
          if (!targets().isTarget(e, true)) continue;
          const d = rayAABB(eye, dir, e.aabb, maxR, exp);
          if (d !== null && d < bestD) { best = e; bestD = d; }
        }
        if (!best) return;

        if (ctx.options.checkWalls.value && typeof session.levelState.rayTrace === "function") {
          try {
            if (session.levelState.rayTrace(eye, dir, bestD)) return;
          } catch (_) {}
        }

        if (Math.random() * 100 > ctx.options.hitChance.value) { rollDelay(); lastAttack = now; return; }

        player.interactEntity(best, true, player.serverSideRotation, "attack");
        if (ctx.options.swing.value) player.swingItem();
        lastAttack = now;
        hits.push(now);
        rollDelay();

        if (ctx.options.debug.value && now - lastDebug > 400) {
          session.sendChatMessage("[Trigger] vurdu: " + (best.username ?? best.name ?? "entity"));
          lastDebug = now;
        }
      } catch (e) {
        if (ctx.options.debug.value) ctx.session?.sendChatMessage("[Trigger] hata: " + (e?.message ?? e));
      }
    });
  }
);
