// rlauncher JS calisma katmani: @protohax/userscript uyumlulugu (ProtoHax olmadan).
// Kotlin tarafi her J's'i "(function(){ ... })();" icine sarip yukler, import satirlarini siler.
// Kotlin <-> JS arasi sadece JSON metinleri gider (QuickJS koprusu basit kalsin diye).
var __mods = [];
var __cur = null;
var __out = null;

var SprintIntent = { Sprint: "Sprint", Walk: "Walk", Stop: "Stop" };
var utils = {};
var targets = {};
function EntityNetworkPlayer() {}
function EntityCreature() {}

function __ser(v) {
  return JSON.stringify(v, function (k, x) { return typeof x === "bigint" ? Number(x) : x; });
}

var __player = {
  runtimeId: 0, health: 20, position: { x: 0, y: 0, z: 0 }, rotation: { x: 0, y: 0, z: 0 },
  isJumping: false, isSneaking: false, isSprinting: false, onGround: false,
};

function __emit(dir, name, data) {
  if (!__out) return;
  var d = null;
  try { d = JSON.parse(__ser(data === undefined ? {} : data)); } catch (e) { d = null; }
  __out.packets.push({ dir: dir, name: name, data: d });
}

var __session = {
  entityState: { localPlayer: __player },
  levelState: { getBlock: function () { return null; }, placeBlock: function () {} },
  connection: {
    sendIncomingPacket: function (name, data) { __emit("in", name, data); },
    sendOutgoingPacket: function (name, data) { __emit("out", name, data); },
  },
};

function defineModule(meta, opts, setup) {
  var m = { file: __cur, meta: meta || {}, opts: opts || {}, setup: setup, handlers: {}, packets: {},
            onEnable: [], onDisable: [], enabled: false, ready: false };
  __mods.push(m);
  var options = {};
  for (var k in m.opts) {
    var o = m.opts[k];
    var c = {};
    for (var p in o) c[p] = o[p];
    c.value = o.def;
    options[k] = c;
  }
  var ctx = {
    options: options,
    get session() { return __session; },
    on: function (evt, fn) { (m.handlers[evt] = m.handlers[evt] || []).push(fn); },
    onPacket: function (name, fn) { (m.packets[name] = m.packets[name] || []).push(fn); },
    onEnable: function (fn) { m.onEnable.push(fn); },
    onDisable: function (fn) { m.onDisable.push(fn); },
    log: function () {},
    chat: function (t) { __out && __out.chat.push(String(t)); },
    toast: function (t) { __out && __out.chat.push(String(t)); },
  };
  try { setup(ctx); m.ready = true; } catch (e) { m.error = String(e); }
}

function __fresh() { return { motion: null, position: null, onGround: null, sprint: null, cancel: false, packets: [], chat: [] }; }

function __run(list, arg) {
  for (var i = 0; i < list.length; i++) {
    try { list[i](arg); } catch (e) { /* tek modul hatasi digerlerini durdurmasin */ }
  }
}

function __state(d) {
  if (d.player) for (var k in d.player) __player[k] = d.player[k];
  return {
    position: d.position, motion: d.motion, moveInput: d.moveInput, rotation: d.rotation, onGround: d.onGround,
    setMotion: function (v) { __out.motion = { x: +v.x || 0, y: +v.y || 0, z: +v.z || 0 }; },
    setPosition: function (v) { __out.position = { x: +v.x || 0, y: +v.y || 0, z: +v.z || 0 }; },
    requestSprint: function (i) { __out.sprint = String(i); },
    cancel: function () { __out.cancel = true; },
  };
}

function __find(file) {
  for (var i = 0; i < __mods.length; i++) if (__mods[i].file === file) return __mods[i];
  return null;
}

var api = {
  /** Yuklenen modullerin ozeti: [{file,name,ready,error}] */
  info: function () {
    return __ser(__mods.map(function (m) { return { file: m.file, name: m.meta.name || m.file, ready: m.ready, error: m.error || null }; }));
  },
  setEnabled: function (file, on) {
    var m = __find(file);
    if (!m) return "yok";
    var was = m.enabled;
    m.enabled = !!on;
    if (m.enabled && !was) __run(m.onEnable, undefined);
    if (!m.enabled && was) __run(m.onDisable, undefined);
    return "ok";
  },
  /** Olay: tick / movement_tick / input_tick / container_open / container_close. Doner: __out JSON */
  event: function (name, json) {
    __out = __fresh();
    var d = json ? JSON.parse(json) : {};
    var before = __player.onGround;
    var st = __state(d);
    var cleanOnGround = __player.onGround;
    for (var i = 0; i < __mods.length; i++) {
      var m = __mods[i];
      if (!m.enabled || !m.handlers[name]) continue;
      __run(m.handlers[name], name === "container_open" || name === "container_close" ? d : st);
    }
    if (__player.onGround !== cleanOnGround) __out.onGround = !!__player.onGround;
    var r = __ser(__out);
    __out = null;
    return r;
  },
  /** Paket olayi: transfer / start_game ... */
  packet: function (name, json) {
    __out = __fresh();
    var d = json ? JSON.parse(json) : {};
    if (d.player) for (var k in d.player) __player[k] = d.player[k];
    for (var i = 0; i < __mods.length; i++) {
      var m = __mods[i];
      if (!m.enabled || !m.packets[name]) continue;
      __run(m.packets[name], d);
    }
    var r = __ser(__out);
    __out = null;
    return r;
  },
};
