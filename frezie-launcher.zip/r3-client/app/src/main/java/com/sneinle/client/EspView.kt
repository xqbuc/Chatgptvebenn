package com.sneinle.client

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import org.json.JSONObject
import java.io.BufferedInputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.tan

class EspBox(val min: DoubleArray, val max: DoubleArray, val color: Int)

class EspFrame(
    val eye: DoubleArray, val pitch: Double, val yaw: Double, val fov: Double,
    val box: Boolean, val tracer: Boolean, val boxes: List<EspBox>, val time: Long
)

/** ProtoHax ESP J's'inin 127.0.0.1:19133'e yolladığı verileri alır. */
object EspBus {
    const val PORT = 19133
    @Volatile var frame: EspFrame? = null
    @Volatile var onFrame: (() -> Unit)? = null
    @Volatile private var server: ServerSocket? = null

    fun start() {
        if (server != null) return
        Thread {
            try {
                val ss = ServerSocket(PORT, 8, InetAddress.getByName("127.0.0.1"))
                server = ss
                while (!ss.isClosed) {
                    val s = try { ss.accept() } catch (e: Exception) { break }
                    try { handle(s) } catch (_: Exception) {} finally { runCatching { s.close() } }
                }
            } catch (_: Exception) {
            } finally { server = null }
        }.apply { isDaemon = true; name = "esp-bus" }.start()
    }

    fun stop() { runCatching { server?.close() }; server = null; frame = null }

    private fun readLine(i: BufferedInputStream): String? {
        val sb = StringBuilder()
        while (true) {
            val b = i.read()
            if (b < 0) return if (sb.isEmpty()) null else sb.toString()
            if (b == '\n'.code) return sb.toString().trimEnd('\r')
            sb.append(b.toChar())
        }
    }

    private fun handle(s: Socket) {
        s.soTimeout = 1000
        val inp = BufferedInputStream(s.getInputStream())
        var len = 0
        while (true) {
            val line = readLine(inp) ?: return
            if (line.isEmpty()) break
            if (line.lowercase().startsWith("content-length:")) len = line.substring(15).trim().toIntOrNull() ?: 0
        }
        val buf = ByteArray(len.coerceIn(0, 1 shl 20)); var off = 0
        while (off < buf.size) { val n = inp.read(buf, off, buf.size - off); if (n < 0) break; off += n }
        parse(String(buf, 0, off, Charsets.UTF_8))
        s.getOutputStream().apply {
            write("HTTP/1.1 200 OK\r\nContent-Length: 0\r\nConnection: close\r\n\r\n".toByteArray()); flush()
        }
    }

    private fun parse(t: String) {
        val o = JSONObject(t)
        val p = o.getJSONArray("p"); val r = o.getJSONArray("r"); val e = o.getJSONArray("e")
        val boxes = ArrayList<EspBox>(e.length())
        for (i in 0 until e.length()) {
            val a = e.getJSONArray(i)
            val c = when (a.getInt(6)) { 2 -> 0xFFFF2020.toInt(); 1 -> 0xFFFF9800.toInt(); else -> 0xFF00FF00.toInt() }
            boxes.add(EspBox(
                doubleArrayOf(a.getDouble(0), a.getDouble(1), a.getDouble(2)),
                doubleArrayOf(a.getDouble(3), a.getDouble(4), a.getDouble(5)), c))
        }
        frame = EspFrame(
            doubleArrayOf(p.getDouble(0), p.getDouble(1), p.getDouble(2)),
            r.getDouble(0), r.getDouble(1), o.optDouble("f", 70.0),
            o.optInt("b", 1) == 1, o.optInt("t", 1) == 1, boxes, System.currentTimeMillis())
        onFrame?.invoke()
    }
}

/** Tüm ekranı kaplayan, dokunmayı geçiren ESP çizim katmanı (kutu + tracer). */
class EspView(c: Context) : View(c) {
    private val dens = resources.displayMetrics.density
    private val boxP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2.2f * dens }
    private val lineP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.6f * dens }
    private val rect = RectF()
    private val pt = DoubleArray(2)

    /** Dünya noktasını ekrana çevirir. Kameranın arkasındaysa false. */
    private fun project(f: EspFrame, x: Double, y: Double, z: Double, w: Float, h: Float, out: DoubleArray): Boolean {
        val yw = Math.toRadians(f.yaw); val pi = Math.toRadians(f.pitch)
        val fx = -sin(yw) * cos(pi); val fy = -sin(pi); val fz = cos(yw) * cos(pi)   // ileri
        val rx = -cos(yw); val rz = -sin(yw)                                          // sağ (ry = 0)
        val ux = -rz * fy; val uy = rz * fx - rx * fz; val uz = rx * fy                // yukarı = sağ x ileri
        val dx = x - f.eye[0]; val dy = y - f.eye[1]; val dz = z - f.eye[2]
        val zc = dx * fx + dy * fy + dz * fz
        if (zc < 0.05) return false
        val xc = dx * rx + dz * rz
        val yc = dx * ux + dy * uy + dz * uz
        val k = 1.0 / tan(Math.toRadians(f.fov) / 2.0)
        out[0] = w / 2.0 + (xc / zc) * k * (h / 2.0)
        out[1] = h / 2.0 - (yc / zc) * k * (h / 2.0)
        return true
    }
    override fun onDraw(cv: Canvas) {
        val f = EspBus.frame ?: return
        if (System.currentTimeMillis() - f.time > 600) return
        val w = width.toFloat(); val h = height.toFloat()
        for (b in f.boxes) {
            var l = Float.MAX_VALUE; var t = Float.MAX_VALUE; var r = -Float.MAX_VALUE; var bt = -Float.MAX_VALUE
            var ok = 0
            for (ix in 0..1) for (iy in 0..1) for (iz in 0..1) {
                val x = if (ix == 0) b.min[0] else b.max[0]
                val y = if (iy == 0) b.min[1] else b.max[1]
                val z = if (iz == 0) b.min[2] else b.max[2]
                if (project(f, x, y, z, w, h, pt)) {
                    ok++
                    l = minOf(l, pt[0].toFloat()); r = maxOf(r, pt[0].toFloat())
                    t = minOf(t, pt[1].toFloat()); bt = maxOf(bt, pt[1].toFloat())
                }
            }
            if (ok < 8) continue   // kısmen arkada kalan kutuyu atla (bozuk çizimi önler)
            rect.set(l, t, r, bt)
            if (f.box) { boxP.color = b.color; cv.drawRect(rect, boxP) }
            if (f.tracer) { lineP.color = b.color; cv.drawLine(w / 2f, h, rect.centerX(), rect.bottom, lineP) }
        }
        postInvalidateDelayed(120)   // bayat veriyi temizlemek için
    }
}
