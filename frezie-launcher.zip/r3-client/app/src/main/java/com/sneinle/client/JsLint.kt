package com.sneinle.client

/** J's dosyalarında bariz hataları (kapanmamış parantez/metin/yorum, ProtoHax import'u yok) yakalar. Sadece uyarı verir, engellemez. */
object JsLint {
    private const val REGEX_PREV = "(,=:[!&|?{};+-*%<>~^"
    private val KW = setOf("return", "typeof", "case", "in", "of", "else", "do", "void", "delete", "throw", "new", "yield", "await")

    /** '/' işaretinden hemen önceki kelime return/typeof gibi bir anahtar sözcük mü? (öyleyse regex başlar) */
    private fun kwBefore(t: String, at: Int): Boolean {
        var e = at - 1
        while (e >= 0 && (t[e] == ' ' || t[e] == '\t' || t[e] == '\r' || t[e] == '\n')) e--
        if (e < 0) return false
        var s = e
        while (s >= 0 && (t[s].isLetterOrDigit() || t[s] == '_' || t[s] == '$')) s--
        return t.substring(s + 1, e + 1) in KW
    }

    fun check(t: String): String? {
        if (!t.contains("defineModule")) return "defineModule yok (ProtoHax J's'i değil)"
        if (!t.contains("@protohax/userscript")) return "@protohax/userscript import'u yok"
        val stack = ArrayList<Char>()
        val lines = ArrayList<Int>()
        val n = t.length
        var i = 0
        var line = 1
        var prev = '\u0000'
        while (i < n) {
            val c = t[i]
            if (c == '\n') { line++; i++; continue }
            if (c == ' ' || c == '\t' || c == '\r') { i++; continue }
            if (c == '/' && i + 1 < n && t[i + 1] == '/') {
                while (i < n && t[i] != '\n') i++
                continue
            }
            if (c == '/' && i + 1 < n && t[i + 1] == '*') {
                val e = t.indexOf("*/", i + 2)
                if (e < 0) return "satır $line: yorum kapanmamış"
                for (k in i until e) if (t[k] == '\n') line++
                i = e + 2
                continue
            }
            if (c == '"' || c == '\'') {
                i++
                while (i < n && t[i] != c) {
                    if (t[i] == '\\') i++
                    else if (t[i] == '\n') return "satır $line: metin kapanmamış"
                    i++
                }
                if (i >= n) return "satır $line: metin kapanmamış"
                i++
                prev = 'a'
                continue
            }
            if (c == '`') {
                val startLine = line
                i++
                var depth = 0
                while (i < n) {
                    val d = t[i]
                    if (d == '\\') { i += 2; continue }
                    if (d == '\n') line++
                    if (depth == 0 && d == '`') break
                    if (d == '$' && i + 1 < n && t[i + 1] == '{') { depth++; i += 2; continue }
                    if (depth > 0 && d == '{') depth++
                    if (depth > 0 && d == '}') depth--
                    i++
                }
                if (i >= n) return "satır $startLine: şablon metni kapanmamış"
                i++
                prev = 'a'
                continue
            }
            if (c == '/') {
                val isRegex = prev == '\u0000' || REGEX_PREV.indexOf(prev) >= 0 ||
                    ((prev.isLetter() || prev == '_' || prev == '$') && kwBefore(t, i))
                if (isRegex) {
                    i++
                    var inClass = false
                    while (i < n && t[i] != '\n') {
                        val d = t[i]
                        if (d == '\\') { i += 2; continue }
                        if (d == '[') inClass = true
                        else if (d == ']') inClass = false
                        else if (d == '/' && !inClass) break
                        i++
                    }
                    if (i < n && t[i] == '/') i++
                    while (i < n && t[i].isLetter()) i++
                    prev = 'a'
                    continue
                }
                prev = '/'
                i++
                continue
            }
            if (c == '(' || c == '[' || c == '{') {
                stack.add(c); lines.add(line)
            } else if (c == ')' || c == ']' || c == '}') {
                val want = if (c == ')') '(' else if (c == ']') '[' else '{'
                if (stack.isEmpty() || stack[stack.size - 1] != want) return "satır $line: '$c' eşleşmiyor"
                stack.removeAt(stack.size - 1); lines.removeAt(lines.size - 1)
            }
            prev = c
            i++
        }
        if (stack.isNotEmpty()) return "satır ${lines[lines.size - 1]}: '${stack[stack.size - 1]}' kapanmamış"
        return null
    }
}
