package com.sneinle.client

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.content.ContextCompat
import com.sneinle.client.Store.sstyle
import com.sneinle.client.Store.stext
import com.sneinle.client.Store.stsize
import java.io.File

class MainActivity : Activity() {
    private val REQ_JS = 1
    private val REQ_DIR = 2
    private val REQ_CFG_IN = 3
    private val REQ_CFG_OUT = 4
    private val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
    private val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        when (intent.getStringExtra("pick")) {
            "js" -> { pickJs(); return }
            "dir" -> { pickDir(); return }
            "cfgin" -> { pickCfg(); return }
            "cfgout" -> { saveCfg(); return }
        }
        if (Build.VERSION.SDK_INT >= 33)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 0)
        runCatching { Store.installNewBuiltins(this) }
        showMain()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun showMain() {
        val root = FrameLayout(this).apply { background = UI.bg(this@MainActivity) }
        root.addView(BlocksView(this), FrameLayout.LayoutParams(MATCH, MATCH))

        val scroll = ScrollView(this).apply { isFillViewport = true; overScrollMode = View.OVER_SCROLL_NEVER }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(22), dp(44), dp(22), dp(28))
        }

        // Logo + isim
        val glow = FrameLayout(this).apply {
            setPadding(dp(6), dp(6), dp(6), dp(6))
            background = UI.rect(this@MainActivity, 0x334DB8FF, 40)
        }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.frezie_logo); scaleType = ImageView.ScaleType.CENTER_CROP
        }
        UI.clip(logo, 34)
        glow.addView(logo, FrameLayout.LayoutParams(dp(140), dp(140)))
        col.addView(glow, LinearLayout.LayoutParams(WRAP, WRAP))
        col.addView(TextView(this).apply {
            val sp = SpannableString("Frezie Launcher")
            sp.setSpan(ForegroundColorSpan(Theme.BLUE), 0, 6, 0)
            sp.setSpan(ForegroundColorSpan(Color.WHITE), 6, 15, 0)
            text = sp; textSize = 30f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(16) })
        col.addView(UI.label(this, "Modu aç, oyuna gir.", 15f, 0xFFCFE9FF.toInt()),
            LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(4) })

        // BASLAT
        val fail = Store.failWhy(this)
        val launchGlow = FrameLayout(this).apply {
            setPadding(dp(5), dp(5), dp(5), dp(5))
            background = UI.rect(this@MainActivity, 0x334DB8FF, 40)
        }
        val launch = TextView(this).apply {
            text = if (fail != null) "\u25B6  MC AÇ" else "\u25B6  BAŞLAT"; textSize = 26f; typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.1f; gravity = Gravity.CENTER; setTextColor(Theme.NAVY0)
            setPadding(0, dp(18), 0, dp(18))
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Theme.BLUE, Theme.BLUE2)).apply {
                cornerRadius = dp(40).toFloat(); setStroke(dp(2), 0xAAFFFFFF.toInt())
            }
            setOnClickListener { if (fail != null) openMc() else launchGame() }
        }
        launchGlow.addView(launch, FrameLayout.LayoutParams(MATCH, WRAP))
        col.addView(launchGlow, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(26) })
        if (fail != null) {
            col.addView(UI.label(this, "Modlar hazırlanamadı: $fail", 14f, 0xFFFF9B9B.toInt()).apply {
                gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(4))
            }, LinearLayout.LayoutParams(MATCH, WRAP))
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
            row.addView(UI.label(this, "\u21BB Tekrar dene", 16f, Theme.BLUE).apply {
                setPadding(dp(14), dp(8), dp(14), dp(8)); setOnClickListener { retryJs() }
            })
            row.addView(UI.label(this, "Klasör seç", 16f, Theme.BLUE).apply {
                setPadding(dp(14), dp(8), dp(14), dp(8)); setOnClickListener { pickDir() }
            })
            col.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
        }

        // 3 buyuk kutu: Modlar / Sunucu / Ayarlar
        fun tile(icon: String, label: String, onClick: () -> Unit) = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(6), dp(18), dp(6), dp(16))
            background = UI.rect(this@MainActivity, 0x3310305F, 22, Theme.BLUE, 1)
            addView(TextView(this@MainActivity).apply { text = icon; textSize = 32f; gravity = Gravity.CENTER })
            addView(UI.label(this@MainActivity, label, 16f).apply { typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER })
            setOnClickListener { onClick() }
        }
        val tiles = LinearLayout(this)
        fun lp(first: Boolean = false) = LinearLayout.LayoutParams(0, WRAP, 1f).apply { if (!first) leftMargin = dp(10) }
        tiles.addView(tile("\uD83E\uDDE9", "Modlar") {
            startActivity(Intent(this, PageActivity::class.java).putExtra("page", "mods"))
        }, lp(true))
        tiles.addView(tile("\uD83C\uDF10", "Sunucu") {
            startActivity(Intent(this, ProxyActivity::class.java))
        }, lp())
        tiles.addView(tile("\u2699\uFE0F", "Ayarlar") {
            startActivity(Intent(this, PageActivity::class.java).putExtra("page", "settings"))
        }, lp())
        col.addView(tiles, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(28) })

        val none = Store.scripts(this).none { Store.enabled(this, it) }
        col.addView(UI.label(this, if (none) "İpucu: Modlar'a gir, bir modun anahtarını aç." else "Açık mod: " +
            Store.scripts(this).count { Store.enabled(this, it) }, 13f, 0xFFAFCDEE.toInt()).apply { gravity = Gravity.CENTER },
            LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(22) })

        scroll.addView(col)
        root.addView(scroll, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(root)
    }

    private fun needOverlay(): Boolean {
        if (Settings.canDrawOverlays(this)) return false
        toast("Önce üstte gösterme iznini ver")
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        return true
    }

    private fun launchGame() {
        if (needOverlay()) return
        val game = packageManager.getLaunchIntentForPackage("com.mojang.minecraftpe")
        if (game == null) { toast("Minecraft bulunamadı"); return }
        val why: String? = runCatching { Store.preflight(this) }.getOrElse { "J's hazırlığı çöktü" }
        Store.setFailWhy(this, why)
        val svc = if (why == null) Intent(this, OverlayService::class.java).setAction("LOADING")
        else Intent(this, OverlayService::class.java).setAction("BANNER")
            .putExtra("text", "Modlar hazırlanamadı\n$why").putExtra("err", true)
        ContextCompat.startForegroundService(this, svc)
        startActivity(game)
        showMain()
    }

    /** J's hazır değilse: modsuz giriş. GUI, müzik ve yazı yine oyunun üstünde açılır. */
    private fun openMc() {
        if (needOverlay()) return
        val game = packageManager.getLaunchIntentForPackage("com.mojang.minecraftpe")
        if (game == null) { toast("Minecraft bulunamadı"); return }
        val svc = Intent(this, OverlayService::class.java).setAction("BANNER")
            .putExtra("text", "Modlar hazırlanamadı\nFrezie Launcher").putExtra("err", true)
        ContextCompat.startForegroundService(this, svc)
        startActivity(game)
    }

    private fun retryJs() {
        val why: String? = runCatching { Store.preflight(this) }.getOrElse { "J's hazırlığı çöktü" }
        Store.setFailWhy(this, why)
        toast(if (why == null) "J's hazır" else "Hâlâ hata: $why")
        showMain()
    }

    private fun pickJs() = startActivityForResult(
        Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
            .setType("*/*").putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true), REQ_JS)

    private fun pickCfg() = startActivityForResult(
        Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), REQ_CFG_IN)

    private fun saveCfg() = startActivityForResult(
        Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
            .setType("application/octet-stream").putExtra(Intent.EXTRA_TITLE, "r3.cfg"), REQ_CFG_OUT)

    private fun pickDir() = startActivityForResult(
        Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION), REQ_DIR)

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (res == RESULT_OK && data != null) {
            when (req) {
                REQ_JS -> {
                    val uris = mutableListOf<Uri>()
                    data.data?.let { uris.add(it) }
                    data.clipData?.let { for (i in 0 until it.itemCount) uris.add(it.getItemAt(i).uri) }
                    val added = mutableListOf<String>()
                    for (u in uris) {
                        val name = contentResolver.query(u, null, null, null, null)?.use {
                            if (it.moveToFirst()) it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
                        } ?: u.lastPathSegment ?: continue
                        val bytes = runCatching { contentResolver.openInputStream(u)?.use { i -> i.readBytes() } }.getOrNull() ?: continue
                        added += Store.importFile(this, name, bytes)
                    }
                    val n = added.size
                    val warns = added.mapNotNull { f -> JsLint.check(Store.scriptText(this, f))?.let { "$f: $it" } }
                    if (warns.isNotEmpty()) Toast.makeText(this, "Uyarı:\n" + warns.joinToString("\n"), Toast.LENGTH_LONG).show()
                    toast("$n J's eklendi")
                }
                REQ_DIR -> {
                    val u = data.data!!
                    contentResolver.takePersistableUriPermission(u,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                    Store.setFolder(this, u.toString())
                    toast("Klasör seçildi")
                }
                REQ_CFG_IN -> {
                    val text = contentResolver.openInputStream(data.data!!)?.use { it.readBytes().toString(Charsets.UTF_8) }
                    toast(if (text != null && Store.importCfg(this, text)) "Cfg yüklendi. Baloncuğu durdurup tekrar başlat" else "Cfg okunamadı")
                }
                REQ_CFG_OUT -> {
                    contentResolver.openOutputStream(data.data!!)?.use { it.write(Store.exportCfg(this).toByteArray()) }
                    toast("Cfg kaydedildi")
                }
            }
        }
        if (intent.hasExtra("pick")) finish() else if (req == REQ_DIR) showMain()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
