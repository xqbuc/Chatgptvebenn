package com.sneinle.client

import android.content.Context
import android.media.MediaPlayer

/** Uygulama içi müzik çalar. Parçalar res/raw içinde, ikonlar res/drawable içinde. */
object MusicPlayer {
    class Track(val title: String, val raw: Int, val icon: Int)

    val tracks = listOf(
        Track("Basayım", R.raw.music_basayim, R.drawable.music_apo),
        Track("Beta - Aldattın Değil Mi", R.raw.music_aldattin, R.drawable.music_beta),
        Track("Beta - Platonik (Kulak)", R.raw.music_platonik, R.drawable.music_beta),
        Track("Değirmenci Dayı", R.raw.music_degirmenci, R.drawable.music_default),
        Track("emriboi - kandırdım", R.raw.music_kandirdim, R.drawable.music_emriboi),
        Track("Joopito - Bar Bar", R.raw.music_barbar, R.drawable.music_default),
    )

    private var mp: MediaPlayer? = null
    var index = 0; private set
    var playing = false; private set
    var autoNext = true
    var volume = 0.8f
    /** Parça/durum değişince çağrılır (ekrandaki ikon ve isim güncellensin diye). */
    var onChange: (() -> Unit)? = null

    val current get() = tracks[index]

    fun play(c: Context, i: Int = index) {
        stop()
        index = ((i % tracks.size) + tracks.size) % tracks.size
        val p = MediaPlayer.create(c.applicationContext, current.raw) ?: return
        p.setVolume(volume, volume)
        p.setOnCompletionListener {
            if (autoNext) next(c) else { playing = false; onChange?.invoke() }
        }
        p.start(); mp = p; playing = true
        onChange?.invoke()
    }

    fun toggle(c: Context) {
        val p = mp
        if (p == null) { play(c); return }
        if (playing) { p.pause(); playing = false } else { p.start(); playing = true }
        onChange?.invoke()
    }

    fun next(c: Context) = play(c, index + 1)
    fun prev(c: Context) = play(c, index - 1)

    fun setVol(v: Float) { volume = v; mp?.setVolume(v, v) }

    fun stop() {
        runCatching { mp?.stop() }; runCatching { mp?.release() }
        mp = null; playing = false
    }
}
