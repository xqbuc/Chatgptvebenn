package com.sneinle.client

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.text.TextUtils
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.*
import com.sneinle.client.Store.alpha
import com.sneinle.client.Store.musicAuto
import com.sneinle.client.Store.musicIconOn
import com.sneinle.client.Store.musicIconSize
import com.sneinle.client.Store.musicNameOn
import com.sneinle.client.Store.musicNameSize
import com.sneinle.client.Store.musicOn
import com.sneinle.client.Store.musicTrack
import com.sneinle.client.Store.musicVol
import com.sneinle.client.Store.size
import com.sneinle.client.Store.ssize
import com.sneinle.client.Store.stext
import com.sneinle.client.Store.stextOn
import com.sneinle.client.Store.sstyle
import com.sneinle.client.Store.stsize

class OverlayService : Service() {
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var wm: WindowManager
    private var bubble: ImageView? = null
    private var panel: View? = null
    private var backdrop: View? = null
    private val shortcuts = mutableMapOf<String, View>()
    private val dots = mutableMapOf<String, TextView>()
    private var editMode = false
    private var tab = 0
    private var cur: String? = null
    private var textView: RainbowTextView? = null
    private var editor: View? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var hidden = false
    private val HIDDEN_ALPHA = 0.01f
    private var musicIcon: ImageView? = null
    private var musicName: TextView? = null
    private var espView: EspView? = null
    private var banner: View? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rect(color: Int, r: Int, stroke: Int = 0, sw: Int = 0) = UI.rect(this, color, r, stroke, sw)
    private fun lp(w: Int, h: Int, x: Int, y: Int, touch: Boolean = true) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            (if (touch) WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL else 0),
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        hidden = Store.isHidden(this)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("sn", "Frezie Launcher", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, notif())
        MusicPlayer.autoNext = musicAuto
        MusicPlayer.setVol(musicVol / 100f)
        MusicPlayer.onChange = { musicTrack = MusicPlayer.index; updateMusicViews() }
        showEsp()
        showBubble()
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        when (i?.action) {
            "SHOW" -> showAll()
            "HIDE" -> hideAll()
            "STOP" -> quit()
            "LOADING" -> showLoading(i?.getLongExtra("ms", 6000L) ?: 6000L)
            "BANNER" -> showBanner(i?.getStringExtra("text") ?: "", i?.getBooleanExtra("err", false) ?: false)
        }
        startForeground(1, notif())
        return START_STICKY
    }

    /** Uygulama son uygulamalardan kaydırılsa da servis ve baloncuk yerinde kalır (gizliyse görünmez halde). */
    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        if (bubble == null) showBubble()
        refreshNotif()
    }

    private fun notif(): Notification {
        fun pi(a: String) = PendingIntent.getService(this, a.hashCode(),
            Intent(this, OverlayService::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val b = Notification.Builder(this, "sn").setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentTitle("Frezie Launcher çalışıyor")
        if (hidden) b.addAction(Notification.Action.Builder(null, "Göster", pi("SHOW")).build())
        else b.addAction(Notification.Action.Builder(null, "Gizle", pi("HIDE")).build())
        b.addAction(Notification.Action.Builder(null, "Kapat", pi("STOP")).build())
        return b.build()
    }

    // ---------- Yukleniyor simgesi (LAUNCH sonrasi): donen simge, sonra baloncuk ----------
    private var loading: View? = null

    private fun showLoading(ms: Long) {
        runCatching { loading?.let { wm.removeView(it) } }; loading = null
        removeBubble()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(28), dp(22), dp(28), dp(20))
            background = UI.neon(this@OverlayService, 0xEE060E24.toInt(), 20, Theme.G, Theme.PINK, 4)
            addView(ProgressBar(this@OverlayService).apply {
                isIndeterminate = true; indeterminateTintList = ColorStateList.valueOf(Theme.G)
            }, LinearLayout.LayoutParams(dp(56), dp(56)))
            addView(tv("Frezie yükleniyor...", 16f, Theme.TEXT, true).apply {
                gravity = Gravity.CENTER; setPadding(0, dp(12), 0, 0)
            })
        }
        val p = WindowManager.LayoutParams(
            WRAP, WRAP, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }
        runCatching {
            wm.addView(box, p); loading = box
            box.postDelayed({
                runCatching { wm.removeView(box) }
                if (loading === box) loading = null
                showBubble()
            }, ms)
        }.onFailure { showBubble() }
    }

    // ---------- Açılış yazısı ----------
    private fun showBanner(msg: String, err: Boolean) {
        runCatching { banner?.let { wm.removeView(it) } }
        val col = if (err) 0xFFFF3B5C.toInt() else Theme.G
        val tv = TextView(this).apply {
            text = msg; textSize = 20f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(if (err) 0xFFFF6B6B.toInt() else Theme.TEXT)
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(10), dp(18), dp(10))
            setShadowLayer(14f, 0f, 0f, col)
            background = UI.neon(this@OverlayService, 0xEE070514.toInt(), 16, col, if (err) 0xFFFF3B5C.toInt() else Theme.PINK)
        }
        val p = WindowManager.LayoutParams(
            WRAP, WRAP, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = dp(60) }
        runCatching {
            wm.addView(tv, p); banner = tv
            tv.postDelayed({
                runCatching { wm.removeView(tv) }
                if (banner === tv) banner = null
            }, if (err) 8000L else 6000L)
        }
    }

    // ---------- ESP katmanı (tam ekran, dokunmaz) ----------
    private fun showEsp() {
        if (espView != null) return
        val v = EspView(this)
        val p = WindowManager.LayoutParams(
            MATCH, MATCH, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        wm.addView(v, p); espView = v
        EspBus.onFrame = { v.postInvalidate() }
        EspBus.start()
    }

    private fun removeEsp() {
        EspBus.onFrame = null; EspBus.stop()
        espView?.let { runCatching { wm.removeView(it) } }; espView = null
    }

    // ---------- Baloncuk ----------
    private fun round(bmp: Bitmap, px: Int): Bitmap {
        val out = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val c = Canvas(out); val p = Paint(Paint.ANTI_ALIAS_FLAG)
        c.drawCircle(px / 2f, px / 2f, px / 2f - 3, p)
        p.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        c.drawBitmap(Bitmap.createScaledBitmap(bmp, px, px, true), 0f, 0f, p)
        p.xfermode = null; p.style = Paint.Style.STROKE; p.strokeWidth = 5f; p.color = Theme.G
        c.drawCircle(px / 2f, px / 2f, px / 2f - 3, p)
        return out
    }

    private fun showBubble() {
        removeBubble()
        val px = dp(size)
        val iv = ImageView(this).apply {
            setImageBitmap(round(BitmapFactory.decodeResource(resources, R.drawable.bubble), px))
            this.alpha = if (hidden) HIDDEN_ALPHA else this@OverlayService.alpha / 100f
        }
        val savedPos = Store.bubblePos(this)
        val params = bubbleLp ?: lp(px, px, savedPos?.first ?: dp(8), savedPos?.second ?: dp(200), false)
        params.width = px; params.height = px
        bubbleLp = params
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        iv.setOnTouchListener { _, e ->
            if (hidden) {
                // Gizliyken baloncuk görünmez ama yerinde durur; dokununca her şey geri gelir.
                if (e.action == MotionEvent.ACTION_UP) showAll()
                return@setOnTouchListener true
            }
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = params.x; sy = params.y; tx = e.rawX; ty = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) moved = true
                    if (moved) { params.x = sx + dx; params.y = sy + dy; wm.updateViewLayout(iv, params); closePanel() }
                }
                MotionEvent.ACTION_UP -> if (moved) Store.setBubblePos(this, params.x, params.y) else {
                    if (editMode) { editMode = false; refreshBar(); toast("Shortcut düzenleme bitti") } else togglePanel()
                }
            }
            true
        }
        wm.addView(iv, params); bubble = iv
        refreshBar()
        showText()
        showMusic()
    }

    /** Paneli kapatmadan baloncuğun boyut/şeffaflığını günceller. */
    private fun restyleBubble() {
        val b = bubble ?: return
        val p = bubbleLp ?: return
        val px = dp(size)
        p.width = px; p.height = px
        (b as ImageView).setImageBitmap(round(BitmapFactory.decodeResource(resources, R.drawable.bubble), px))
        b.alpha = if (hidden) HIDDEN_ALPHA else this@OverlayService.alpha / 100f
        wm.updateViewLayout(b, p)
    }

    private fun removeBubble() {
        closePanel(); removeText(); removeMusic(); closeEditor()
        bubble?.let { runCatching { wm.removeView(it) } }; bubble = null
        clearShortcuts()
    }

    /** Her şeyi gizler ama baloncuk aynı yerde görünmez halde kalır; ona dokununca her şey geri gelir. */
    private fun hideAll() {
        hidden = true; Store.setHidden(this, true); editMode = false
        closePanel(); removeText(); removeMusic(); closeEditor(); clearShortcuts()
        val b = bubble
        if (b == null) showBubble() else b.alpha = HIDDEN_ALPHA
        refreshNotif()
    }

    private fun showAll() {
        hidden = false; Store.setHidden(this, false)
        val b = bubble
        if (b == null) showBubble() else b.alpha = this@OverlayService.alpha / 100f
        refreshBar(); showText(); showMusic()
        refreshNotif()
    }

    /** Bilerek kapatılınca gizli durumu sıfırlanır; yoksa sonraki açılışta baloncuk görünmez başlardı. */
    private fun quit() { Store.setHidden(this, false); stopSelf() }

    private fun refreshNotif() {
        runCatching { getSystemService(NotificationManager::class.java).notify(1, notif()) }
    }

    // ---------- Shortcut'lar (sabitlenen J's'ler) ----------
    private fun clearShortcuts() { shortcuts.values.forEach { runCatching { wm.removeView(it) } }; shortcuts.clear() }

    private fun refreshBar() {
        clearShortcuts()
        if (hidden) return
        val s = dp(ssize)
        Store.pinnedList(this).forEachIndexed { i, n ->
            val pos = Store.shortcutPos(this, n) ?: Pair(dp(8), dp(280) + i * (s + dp(6)))
            val params = lp(s, s, pos.first, pos.second, false)
            val tv = TextView(this).apply {
                text = Store.alias(this@OverlayService, n).take(2).uppercase()
                gravity = Gravity.CENTER; textSize = (ssize * 0.28f).coerceIn(9f, 26f); typeface = Typeface.DEFAULT_BOLD
            }
            fun paint() {
                val on = Store.enabled(this, n)
                tv.setTextColor(if (on) Theme.BG_DARK else Theme.G)
                tv.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(if (on) Theme.G else Theme.CARD)
                    setStroke(dp(if (editMode) 3 else 2), if (editMode) 0xFFFFA000.toInt() else Theme.EDGE)
                }
            }
            paint()
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
            tv.setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = params.x; sy = params.y; tx = e.rawX; ty = e.rawY; moved = false }
                    MotionEvent.ACTION_MOVE -> if (editMode) {
                        val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                        if (Math.abs(dx) > 6 || Math.abs(dy) > 6) moved = true
                        if (moved) { params.x = sx + dx; params.y = sy + dy; wm.updateViewLayout(tv, params) }
                    }
                    MotionEvent.ACTION_UP -> {
                        if (editMode) { if (moved) Store.setShortcutPos(this, n, params.x, params.y) }
                        else {
                            val on = !Store.enabled(this, n)
                            Store.setEnabled(this, n, on)
                            if (!Store.sync(this, n, on)) toast("Önce klasör seç (J's sekmesi)")
                            paint()
                        }
                    }
                }
                true
            }
            wm.addView(tv, params); shortcuts[n] = tv
        }
    }

    // ---------- Küçük UI yardımcıları ----------
    private fun tv(t: String, sp: Float = 14f, color: Int = Theme.TEXT, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = sp; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD
        if (color == Theme.G || (bold && sp >= 18f)) setShadowLayer(12f, 0f, 0f, Theme.G)
    }

    private fun chip(t: String, active: Boolean = false, onClick: () -> Unit) =
        tv(t, 13f, if (active) Theme.BG_DARK else Theme.G, true).apply {
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = UI.neon(this@OverlayService, if (active) Theme.G else Theme.CARD, 14,
                if (active) Theme.G else Theme.EDGE, if (active) Theme.G else Theme.EDGE, 3)
            setOnClickListener { onClick() }
        }

    private fun sw(checked: Boolean, onChange: (Boolean) -> Unit) = Switch(this).apply {
        isChecked = checked; UI.tintSwitch(this)
        setOnCheckedChangeListener { _, on -> onChange(on) }
    }

    private fun seek(mx: Int, pr: Int, live: ((Int) -> Unit)?, done: (Int) -> Unit) = SeekBar(this).apply {
        this.max = mx; this.progress = pr
        progressTintList = ColorStateList.valueOf(Theme.G)
        thumbTintList = ColorStateList.valueOf(Theme.PINK)
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) { live?.invoke(p) }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) { done(s.progress) }
        })
    }

    private fun LinearLayout.add(v: View, top: Int = 8) =
        addView(v, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(top) })

    private fun rowSwitch(title: String, checked: Boolean, onChange: (Boolean) -> Unit): View =
        LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8)); background = rect(Theme.CARD, 12, 0x66B026FF, 1)
            addView(tv(title, 14f), LinearLayout.LayoutParams(0, WRAP, 1f))
            addView(sw(checked, onChange))
        }

    private fun sliderCard(title: String, mx: Int, pr: Int, done: (Int) -> Unit): View =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(8)); background = rect(Theme.CARD, 12, 0x66B026FF, 1)
            addView(tv(title, 14f))
            addView(seek(mx, pr, null, done))
        }

    private fun saveOpt(n: String, o: ScriptOpts.Opt, v: String) {
        Store.setVal(this, n, o.key, v)
        if (Store.enabled(this, n)) Store.sync(this, n, true)
    }

    // ---------- Panel ----------
    private fun closePanel() {
        panel?.let { runCatching { wm.removeView(it) } }; panel = null
        backdrop?.let { runCatching { wm.removeView(it) } }; backdrop = null
    }

    /** Fırça (Tema) sekmesi açıkken tüm ekranı kaplayan fotoğraf . */
    private fun showBackdrop() {
        val fl = FrameLayout(this)
        fl.addView(ImageView(this).apply {
            setImageResource(R.drawable.gui_photo); scaleType = ImageView.ScaleType.CENTER_CROP
        }, FrameLayout.LayoutParams(MATCH, MATCH))
        fl.addView(View(this).apply { setBackgroundColor(0x44140428) }, FrameLayout.LayoutParams(MATCH, MATCH))
        val p = WindowManager.LayoutParams(
            MATCH, MATCH, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        wm.addView(fl, p); backdrop = fl
    }
    private fun togglePanel() { if (panel != null) closePanel() else showPanel(tab) }

    private fun showPanel(t: Int = tab) {
        closePanel(); tab = t
        val dm = resources.displayMetrics
        if (t == 2) showBackdrop()
        val w = minOf(dp(760), (dm.widthPixels * 0.94).toInt())
        val h = minOf(dp(420), (dm.heightPixels * 0.94).toInt())
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = UI.neon(this@OverlayService, Theme.PANEL, 18, Theme.G, Theme.PINK, 5)
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        UI.clip(root, 18)
        root.addView(rail(), LinearLayout.LayoutParams(dp(66), MATCH))
        val content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(0, MATCH, 1f))
        if (t == 0) content.addView(modsView())
        else content.addView(ScrollView(this).apply { addView(pageBody(t)) })
        val p = WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }
        wm.addView(root, p); panel = root
    }

    private fun rail(): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(3), dp(4), dp(3), dp(4)); background = rect(Theme.RAIL, 14)
        }
        val items = listOf(
            Triple("\uD83E\uDDE9", "Modlar", 0), Triple("\uD83C\uDF10", "Sunucu", 7),
            Triple("\u2699\uFE0E", "Ayar", 5), Triple("\u22EF", "Daha", 8))
        val extras = listOf(1, 2, 3, 4, 6)
        for ((g, n, i) in items) col.addView(railItem(g, n, i == tab || (i == 8 && tab in extras)) { showPanel(i) })
        col.addView(railItem("\u25CC", "Gizle", false) { hideAll() })
        return col
    }

    private fun railItem(g: String, n: String, sel: Boolean, onClick: () -> Unit): View {
        val c = if (sel) Theme.G else Theme.MUTED
        val item = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(1), dp(1), dp(1), dp(1))
            if (sel) background = UI.neon(this@OverlayService, Theme.SEL, 12, Theme.G, Theme.PINK, 3)
            addView(tv(g, 16f, c, true).apply { includeFontPadding = false })
            addView(tv(n, 9f, c).apply { includeFontPadding = false; setSingleLine(true) })
            setOnClickListener { onClick() }
        }
        // Eşit ağırlık: 8 buton paneli ne kadar büyükse o kadar paylaşır, kaydırma gerekmez.
        item.layoutParams = LinearLayout.LayoutParams(MATCH, 0, 1f).apply { topMargin = dp(2); bottomMargin = dp(2) }
        return item
    }

    // ---------- Mods sekmesi (J's modülleri + ayarları) ----------
    private fun modsView(): View {
        val list = Store.scripts(this)
        if (cur == null || cur !in list) cur = list.firstOrNull()
        dots.clear()
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8)) }
        for (n in list) left.addView(modRow(n))
        if (list.isEmpty()) left.addView(tv("J's yok", 13f, Theme.MUTED))
        row.addView(ScrollView(this).apply { background = ColorDrawable(Theme.LIST); addView(left) },
            LinearLayout.LayoutParams(dp(180), MATCH))
        row.addView(ScrollView(this).apply { addView(detail(cur)) }, LinearLayout.LayoutParams(0, MATCH, 1f))
        return row
    }

    private fun modRow(n: String): View {
        val sel = n == cur
        val on = Store.enabled(this, n)
        val dot = tv("\u25CF", 10f, if (on) Theme.G else Theme.MUTED).apply { setPadding(0, 0, dp(8), 0) }
        dots[n] = dot
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(10), dp(8), dp(10))
            if (sel) background = UI.neon(this@OverlayService, Theme.SEL, 12, Theme.G, Theme.PINK, 3)
            addView(dot)
            addView(tv(Store.alias(this@OverlayService, n), 14f, Theme.TEXT, sel).apply {
                setSingleLine(true); ellipsize = TextUtils.TruncateAt.END
            }, LinearLayout.LayoutParams(0, WRAP, 1f))
            if (sel) addView(tv("\u203A", 18f, Theme.G))
            setOnClickListener { cur = n; showPanel(0) }
        }
        row.layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(4) }
        return row
    }

    private fun detail(n: String?): View {
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        if (n == null) { body.addView(tv("Daha > Mod dosyaları'ndan bir mod ekle", 14f, Theme.MUTED)); return body }

        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(tv(Store.alias(this, n), 20f, Theme.TEXT, true).apply {
            setSingleLine(true); ellipsize = TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        head.addView(sw(Store.enabled(this, n)) { on ->
            Store.setEnabled(this, n, on)
            if (!Store.sync(this, n, on)) toast("Önce klasör seç (J's sekmesi)")
            dots[n]?.setTextColor(if (on) Theme.G else Theme.MUTED)
            refreshBar()
        })
        body.addView(head)

        val pinned = Store.pinned(this, n)
        val chips = LinearLayout(this)
        fun addChip(c: View) = chips.addView(c, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(8) })
        addChip(chip("\u270E Rename") {
            prompt("İsim", Store.alias(this, n), false) { s, _ -> Store.setAlias(this, n, s); refreshBar(); showPanel(0) }
        })
        addChip(chip(if (pinned) "\u2605 Shortcut" else "\u2606 Shortcut", pinned) {
            Store.setPinned(this, n, !pinned); refreshBar(); showPanel(0)
        })
        addChip(chip("\u21BA Sıfırla") {
            Store.clearVals(this, n)
            if (Store.enabled(this, n)) Store.sync(this, n, true)
            showPanel(0)
        })
        body.add(HorizontalScrollView(this).apply { addView(chips); isHorizontalScrollBarEnabled = false }, 10)

        val opts = ScriptOpts.options(this, n)
        if (opts.isEmpty()) body.add(tv("Bu J's'te düzenlenebilir ayar yok", 13f, Theme.MUTED), 12)
        for (o in opts) body.add(optCard(n, o), 8)
        return body
    }

    private fun optCard(n: String, o: ScriptOpts.Opt): View {
        val cv = ScriptOpts.current(this, n, o)
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10)); background = rect(Theme.CARD, 12, 0x66B026FF, 1)
        }
        when (o.type) {
            "boolean" -> card.addView(LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL
                addView(tv(o.name, 14f), LinearLayout.LayoutParams(0, WRAP, 1f))
                addView(sw(cv == "true") { saveOpt(n, o, it.toString()) })
            })
            "enum" -> {
                val pill = chip(cv, true) {}
                pill.setOnClickListener {
                    val now = ScriptOpts.current(this, n, o)
                    if (o.values.isNotEmpty()) {
                        val nx = o.values[(o.values.indexOf(now) + 1) % o.values.size]
                        saveOpt(n, o, nx); pill.text = nx
                    }
                }
                card.addView(LinearLayout(this).apply {
                    gravity = Gravity.CENTER_VERTICAL
                    addView(tv(o.name, 14f), LinearLayout.LayoutParams(0, WRAP, 1f))
                    addView(pill)
                })
            }
            else -> {
                val steps = Math.round((o.max - o.min) / o.step).toInt().coerceAtLeast(1)
                val pill = tv(cv, 13f, Theme.BG_DARK, true).apply {
                    setPadding(dp(10), dp(3), dp(10), dp(3)); background = rect(Theme.G, 8)
                }
                card.addView(LinearLayout(this).apply {
                    gravity = Gravity.CENTER_VERTICAL
                    addView(tv(o.name, 14f), LinearLayout.LayoutParams(0, WRAP, 1f))
                    addView(pill)
                })
                val start = Math.round(((cv.toDoubleOrNull() ?: o.min) - o.min) / o.step).toInt().coerceIn(0, steps)
                card.addView(seek(steps, start, { p -> pill.text = ScriptOpts.fmt(o.min + p * o.step, o.step) }) { p ->
                    saveOpt(n, o, ScriptOpts.fmt(o.min + p * o.step, o.step))
                })
            }
        }
        return card
    }

    // ---------- Diğer sekmeler ----------
    private fun pageBody(t: Int): View {
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(14))
        }
        when (t) {
            1 -> textPage(body)
            2 -> themePage(body)
            3 -> jsPage(body)
            4 -> cfgPage(body)
            6 -> musicPage(body)
            7 -> serverPage(body)
            8 -> morePage(body)
            else -> settingsPage(body)
        }
        return body
    }

    private fun textPage(b: LinearLayout) {
        b.addView(tv("Special yazı", 20f, Theme.TEXT, true))
        b.add(rowSwitch("Ekranda göster", stextOn) { stextOn = it; showText() })
        b.add(tv("Stil", 13f, Theme.MUTED), 10)
        Styles.names.forEachIndexed { i, n ->
            b.add(chip((if (i == sstyle) "\u2713 " else "") + n, i == sstyle) { sstyle = i; showText(); showPanel(1) }, 6)
        }
        b.add(sliderCard("Yazı boyutu", 40, stsize - 12) { stsize = it + 12; showText() }, 10)
        b.add(chip("Yazıyı düzenle") { openEditor() }, 10)
        b.add(chip("Konumu sıfırla") { Store.resetTextPos(this); showText() }, 6)
        b.add(tv("Ekrandaki yazıya dokun: düzenle. Sürükle: taşı.", 12f, Theme.MUTED), 8)
    }

    private fun themePage(b: LinearLayout) {
        b.addView(tv("Tema", 20f, Theme.TEXT, true))
        b.add(tv("Arka plan fotoğrafı sadece bu (fırça) sekmesi açıkken görünür.", 13f, Theme.MUTED), 10)
        val frame = FrameLayout(this).apply {
            setPadding(dp(5), dp(5), dp(5), dp(5))
            background = UI.neon(this@OverlayService, Theme.CARD, 16, Theme.G, Theme.PINK, 4)
        }
        val pic = ImageView(this).apply { setImageResource(R.drawable.gui_photo); scaleType = ImageView.ScaleType.CENTER_CROP }
        UI.clip(pic, 12)
        frame.addView(pic, FrameLayout.LayoutParams(MATCH, dp(170)))
        b.add(frame, 12)
    }

    private fun jsPage(b: LinearLayout) {
        b.addView(tv("J's dosyaları", 20f, Theme.TEXT, true))
        val chips = LinearLayout(this)
        chips.addView(chip("\uFF0B J's ekle") { pick("js") }, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(8) })
        chips.addView(chip("Klasör seç") { pick("dir") }, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(8) })
        chips.addView(chip("Hazır modüller") {
            val n = Store.installBuiltins(this, true)
            Store.scripts(this).filter { Store.enabled(this, it) }.forEach { Store.sync(this, it, true) }
            toast(if (n > 0) "$n hazır modül eklendi" else "Hazır modüller zaten ekli"); showPanel(3)
        })
        b.add(chips, 10)
        b.add(tv(if (Store.folder(this) == null) "ProtoHax klasörü: seçilmedi" else "ProtoHax klasörü: seçili", 12f, Theme.MUTED), 6)
        val list = Store.scripts(this)
        if (list.isEmpty()) b.add(tv("Henüz J's yok", 13f, Theme.MUTED), 10)
        for (n in list) {
            val row = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(8), dp(8), dp(8)); background = rect(Theme.CARD, 12)
                addView(tv(n, 14f), LinearLayout.LayoutParams(0, WRAP, 1f))
                addView(tv("\u2715", 16f, Theme.G, true).apply {
                    setPadding(dp(12), dp(6), dp(12), dp(6))
                    setOnClickListener {
                        Store.deleteScript(this@OverlayService, n)
                        refreshBar(); toast("Silindi: $n"); showPanel(3)
                    }
                })
            }
            b.add(row, 6)
        }
    }

    private fun cfgPage(b: LinearLayout) {
        b.addView(tv("Cfg", 20f, Theme.TEXT, true))
        b.add(chip("Cfg yükle") { pick("cfgin") }, 10)
        b.add(chip("Cfg kaydet") { pick("cfgout") }, 6)
        b.add(tv("Cfg: J's ayarları, açık J's'ler, shortcut konumları ve Special yazıyı içerir.", 12f, Theme.MUTED), 8)
    }

    private fun settingsPage(b: LinearLayout) {
        b.addView(tv("Ayarlar", 20f, Theme.TEXT, true))
        b.add(sliderCard("Baloncuk boyutu", 60, size - 40) { size = it + 40; restyleBubble() }, 10)
        b.add(sliderCard("Şeffaflık", 70, this@OverlayService.alpha - 30) {
            this@OverlayService.alpha = it + 30; restyleBubble()
        }, 8)
        b.add(sliderCard("Shortcut boyutu", 80, ssize - 24) { ssize = it + 24; refreshBar() }, 8)
        b.add(chip("Shortcut'ları düzenle (sürükle)") {
            if (Store.pinnedList(this).isEmpty()) toast("Önce Modlar'da bir modun \u2606 kısayolunu aç")
            else { editMode = true; closePanel(); refreshBar(); toast("Sürükle. Bitirmek için baloncuğa dokun") }
        }, 10)
        b.add(chip("Shortcut konumlarını sıfırla") { Store.resetShortcutPos(this); refreshBar() }, 6)
        b.add(chip("Kapat") { quit() }, 10)
    }

    // ---------- Daha (nadir kullanilan sekmeler) ----------
    private fun morePage(b: LinearLayout) {
        b.addView(tv("Daha", 20f, Theme.TEXT, true))
        b.add(chip("Yazı (isim)") { showPanel(1) }, 12)
        b.add(chip("Tema") { showPanel(2) }, 8)
        b.add(chip("Müzik") { showPanel(6) }, 8)
        b.add(chip("Mod dosyaları (.js)") { showPanel(3) }, 8)
        b.add(chip("Yedek (cfg)") { showPanel(4) }, 8)
    }

    // ---------- Sunucu / Realms (proxy hedefi) ----------
    private var realmsList: List<com.sneinle.client.proxy.RealmsApi.Realm>? = null
    private var realmsMsg = ""
    private val mainH = android.os.Handler(android.os.Looper.getMainLooper())

    private fun serverPage(b: LinearLayout) {
        val cur = com.sneinle.client.proxy.Targets.current(this)
        b.addView(tv("Sunucu", 20f, Theme.TEXT, true))
        b.add(tv("Seçili: " + (if (cur.isEmpty()) "yok" else com.sneinle.client.proxy.Targets.label(this, cur)), 13f, Theme.G), 6)
        b.add(tv("Proxy: " + com.sneinle.client.proxy.ProxyState.status, 12f, Theme.MUTED), 4)
        b.add(tv("Seçince Minecraft'ta 'Frezie' sunucusuna (127.0.0.1) tekrar gir.", 12f, Theme.MUTED), 4)
        for (t in com.sneinle.client.proxy.Targets.list(this)) {
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            row.addView(chip(t.name, t.addr == cur) {
                com.sneinle.client.proxy.Targets.select(this, t.addr); showPanel(7)
            }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(8) })
            row.addView(chip("Sil") { com.sneinle.client.proxy.Targets.remove(this, t.addr); showPanel(7) })
            b.add(row, 6)
        }
        b.add(chip("+ Sunucu ekle (adres:port)") {
            prompt("Sunucu adresi (ornek: play.sunucu.com:19132)", "", false) { t, _ ->
                val a = t.trim()
                if (a.isNotEmpty()) {
                    com.sneinle.client.proxy.Targets.add(this, a, a)
                    com.sneinle.client.proxy.Targets.select(this, a)
                }
                showPanel(7)
            }
        }, 10)
        b.add(chip("Realms yükle") { loadRealms() }, 6)
        if (realmsMsg.isNotEmpty()) b.add(tv(realmsMsg, 12f, Theme.MUTED), 6)
        realmsList?.forEach { r ->
            val label = "\u2601 " + r.name + (if (r.owner.isNotEmpty()) " (" + r.owner + ")" else "") + (if (r.expired) " [süresi dolmuş]" else "")
            b.add(chip(label, cur == "realm:" + r.id) {
                val addr = "realm:" + r.id
                com.sneinle.client.proxy.Targets.add(this, "Realm: " + r.name, addr)
                com.sneinle.client.proxy.Targets.select(this, addr); showPanel(7)
            }, 6)
        }
    }

    private fun loadRealms() {
        realmsMsg = "Realms yükleniyor..."; showPanel(7)
        Thread {
            var msg = ""
            var l: List<com.sneinle.client.proxy.RealmsApi.Realm>? = null
            try {
                if (com.sneinle.client.proxy.XboxAuth.session == null && !com.sneinle.client.proxy.XboxAuth.restore(this))
                    msg = "Önce Xbox girişi yap (Proxy ekranı)"
                else {
                    l = com.sneinle.client.proxy.RealmsApi.list(com.sneinle.client.proxy.BedrockProxy.findCodec().minecraftVersion)
                    msg = if (l.isEmpty()) "Realm bulunamadı" else ""
                }
            } catch (e: Throwable) { msg = "Realms hatası: " + (e.message ?: e.javaClass.simpleName) }
            mainH.post { realmsList = l; realmsMsg = msg; showPanel(7) }
        }.also { it.isDaemon = true }.start()
    }

    // ---------- Müzik ----------
    private fun musicPage(b: LinearLayout) {
        b.addView(tv("Müzik", 20f, Theme.TEXT, true))
        val now = tv(MusicPlayer.current.title, 13f, Theme.G, true)
        b.add(now, 6)
        val ctl = LinearLayout(this)
        val playBtn = chip(if (MusicPlayer.playing) "\u23F8" else "\u25B6") {}
        playBtn.setOnClickListener { MusicPlayer.toggle(this); playBtn.text = if (MusicPlayer.playing) "\u23F8" else "\u25B6"; now.text = MusicPlayer.current.title }
        ctl.addView(chip("\u23EE") { MusicPlayer.prev(this); showPanel(6) }, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(8) })
        ctl.addView(playBtn, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(8) })
        ctl.addView(chip("\u23ED") { MusicPlayer.next(this); showPanel(6) })
        b.add(ctl, 8)
        b.add(tv("Parçalar (dokun: çal)", 13f, Theme.MUTED), 10)
        MusicPlayer.tracks.forEachIndexed { i, t ->
            val sel = i == MusicPlayer.index
            val row = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8), dp(6), dp(8), dp(6)); background = rect(if (sel) Theme.SEL else Theme.CARD, 12, if (sel) Theme.G else 0, if (sel) 1 else 0)
                addView(circleIcon(t.icon, dp(36)))
                addView(tv(t.title, 14f, Theme.TEXT, sel).apply { setPadding(dp(10), 0, 0, 0) }, LinearLayout.LayoutParams(0, WRAP, 1f))
                addView(tv(if (sel && MusicPlayer.playing) "\u266B" else "", 16f, Theme.G, true))
                setOnClickListener { MusicPlayer.play(this@OverlayService, i); showPanel(6) }
            }
            b.add(row, 6)
        }
        b.add(rowSwitch("Ekranda göster", musicOn) { musicOn = it; showMusic() }, 12)
        b.add(rowSwitch("İkon göster", musicIconOn) { musicIconOn = it; showMusic() }, 6)
        b.add(rowSwitch("İsim göster", musicNameOn) { musicNameOn = it; showMusic() }, 6)
        b.add(rowSwitch("Sıradaki parçaya otomatik geç", musicAuto) { musicAuto = it; MusicPlayer.autoNext = it }, 6)
        b.add(sliderCard("Ses", 100, musicVol) { musicVol = it; MusicPlayer.setVol(it / 100f) }, 6)
        b.add(sliderCard("İkon boyutu", 60, musicIconSize - 20) { musicIconSize = it + 20; showMusic() }, 6)
        b.add(sliderCard("İsim boyutu", 18, musicNameSize - 8) { musicNameSize = it + 8; showMusic() }, 6)
        b.add(chip("Konumları sıfırla") { Store.resetMusicPos(this); showMusic() }, 10)
        b.add(tv("Ekranda: ikona dokun = çal/duraklat, isme dokun = sonraki parça. Sürükle: taşı (ikon ve isim ayrı taşınır).", 12f, Theme.MUTED), 8)
    }

    private fun circleIcon(res: Int, px: Int) = ImageView(this).apply {
        setImageBitmap(roundIcon(BitmapFactory.decodeResource(resources, res), px))
        layoutParams = LinearLayout.LayoutParams(px, px)
    }

    private fun roundIcon(bmp: Bitmap, px: Int): Bitmap {
        val out = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val c = Canvas(out); val p = Paint(Paint.ANTI_ALIAS_FLAG)
        c.drawCircle(px / 2f, px / 2f, px / 2f - 2, p)
        p.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        c.drawBitmap(Bitmap.createScaledBitmap(bmp, px, px, true), 0f, 0f, p)
        p.xfermode = null; p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = Theme.G
        c.drawCircle(px / 2f, px / 2f, px / 2f - 2, p)
        return out
    }

    /** Ekrana sürüklenebilir müzik ikonu ve isim yazısı koyar. */
    private fun draggable(v: View, which: String, defX: Int, defY: Int, onTap: () -> Unit) {
        val pos = Store.musicPos(this, which) ?: Pair(defX, defY)
        val p = lp(WRAP, WRAP, pos.first, pos.second, false)
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = p.x; sy = p.y; tx = e.rawX; ty = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) moved = true
                    if (moved) { p.x = sx + dx; p.y = sy + dy; wm.updateViewLayout(v, p) }
                }
                MotionEvent.ACTION_UP -> if (moved) Store.setMusicPos(this, which, p.x, p.y) else onTap()
            }
            true
        }
        wm.addView(v, p)
    }

    private fun showMusic() {
        removeMusic()
        if (!musicOn || hidden) return
        if (musicIconOn) {
            val iv = ImageView(this).apply { setImageBitmap(roundIcon(BitmapFactory.decodeResource(resources, MusicPlayer.current.icon), dp(musicIconSize))) }
            musicIcon = iv
            draggable(iv, "icon", dp(8), dp(120)) { MusicPlayer.toggle(this) }
        }
        if (musicNameOn) {
            val t = TextView(this).apply {
                text = MusicPlayer.current.title; textSize = musicNameSize.toFloat(); typeface = Typeface.DEFAULT_BOLD
                setTextColor(Theme.TEXT); setShadowLayer(6f, 0f, 0f, 0xFF000000.toInt()); setPadding(dp(8), dp(4), dp(8), dp(4))
                background = rect(0x99000000.toInt(), 10)
            }
            musicName = t
            draggable(t, "name", dp(8) + dp(musicIconSize) + dp(8), dp(120)) { MusicPlayer.next(this) }
        }
        updateMusicViews()
    }

    private fun updateMusicViews() {
        musicIcon?.let { it.setImageBitmap(roundIcon(BitmapFactory.decodeResource(resources, MusicPlayer.current.icon), dp(musicIconSize))); it.alpha = if (MusicPlayer.playing) 1f else 0.6f }
        musicName?.text = (if (MusicPlayer.playing) "\u266A " else "\u23F8 ") + MusicPlayer.current.title
    }

    private fun removeMusic() {
        musicIcon?.let { runCatching { wm.removeView(it) } }; musicIcon = null
        musicName?.let { runCatching { wm.removeView(it) } }; musicName = null
    }

    private fun pick(what: String) {
        closePanel()
        startActivity(Intent(this, MainActivity::class.java).putExtra("pick", what).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    // ---------- Special: ekrandaki rainbow yazı ----------
    private fun showText() {
        removeText()
        if (!stextOn || hidden) return
        val v = RainbowTextView(this).apply { text = stext; styleIdx = sstyle; textSp = stsize.toFloat() }
        val pos = Store.textPos(this) ?: Pair(dp(80), dp(120))
        val p = lp(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, pos.first, pos.second, false)
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = p.x; sy = p.y; tx = e.rawX; ty = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) moved = true
                    if (moved) { p.x = sx + dx; p.y = sy + dy; wm.updateViewLayout(v, p) }
                }
                MotionEvent.ACTION_UP -> if (moved) Store.setTextPos(this, p.x, p.y) else openEditor()
            }
            true
        }
        wm.addView(v, p); textView = v
    }

    private fun removeText() { textView?.let { runCatching { wm.removeView(it) } }; textView = null }
    private fun closeEditor() { editor?.let { runCatching { wm.removeView(it) } }; editor = null }

    private fun openEditor() {
        prompt("Yazı", stext, true) { t, st ->
            stext = if (t.isBlank()) Store.defaultText else t
            sstyle = st; stextOn = true; showText()
        }
    }

    /** Klavyeli küçük yazı kutusu (oyunun üstünde). */
    private fun prompt(title: String, initial: String, withStyle: Boolean, onOk: (String, Int) -> Unit) {
        if (editor != null) return
        closePanel()
        var st = sstyle
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14))
            background = rect(Theme.PANEL_SOLID, 16, Theme.G, 1)
        }
        box.addView(tv(title, 16f, Theme.G, true))
        val et = EditText(this).apply {
            setText(initial); setTextColor(Theme.TEXT); setHintTextColor(Theme.MUTED); setSelection(text.length)
        }
        box.addView(et)
        if (withStyle) {
            val styleBtn = chip("Stil: " + Styles.names[st]) {}
            styleBtn.setOnClickListener {
                st = (st + 1) % Styles.names.size
                styleBtn.text = "Stil: " + Styles.names[st]
            }
            box.add(styleBtn, 8)
        }
        val row = LinearLayout(this)
        row.addView(chip("İptal") { closeEditor() }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(8) })
        row.addView(chip("Tamam", true) {
            val t = et.text.toString()
            closeEditor(); onOk(t, st)
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        box.add(row, 10)
        val p = WindowManager.LayoutParams(
            dp(320), WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = dp(50)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE or
                WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        }
        wm.addView(box, p); editor = box
        et.requestFocus()
        et.postDelayed({
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(et, 0)
        }, 200)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onDestroy() { runCatching { banner?.let { wm.removeView(it) } }; runCatching { loading?.let { wm.removeView(it) } }; removeEsp(); removeBubble(); MusicPlayer.onChange = null; MusicPlayer.stop(); super.onDestroy() }
}
