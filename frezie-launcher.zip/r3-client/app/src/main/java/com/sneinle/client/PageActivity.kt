package com.sneinle.client

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import com.sneinle.client.Store.alpha
import com.sneinle.client.Store.size
import com.sneinle.client.Store.ssize
import com.sneinle.client.Store.stext
import com.sneinle.client.Store.stextOn

/** Frezie Launcher: sade "Modlar" ve "Ayarlar" sayfalari (buyuk dugmeler, az yazi). */
class PageActivity : Activity() {
    private val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
    private val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT
    private val open = mutableSetOf<String>()

    override fun onResume() { super.onResume(); build() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun LinearLayout.add(v: View, top: Int = 12) =
        addView(v, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(top) })

    private fun pick(what: String) =
        startActivity(Intent(this, MainActivity::class.java).putExtra("pick", what))

    private fun title(t: String, sp: Float = 22f) = TextView(this).apply {
        text = t; textSize = sp; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE)
    }
    private fun note(t: String) = UI.label(this, t, 13f, 0xFFAFCDEE.toInt())

    /** Buyuk, kolay basilan dugme. */
    private fun big(t: String, primary: Boolean = true, onClick: () -> Unit) = TextView(this).apply {
        text = t; textSize = 17f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        setTextColor(if (primary) Theme.NAVY0 else Color.WHITE)
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = if (primary) UI.rect(this@PageActivity, Theme.BLUE, 18)
        else UI.rect(this@PageActivity, 0x33FFFFFF, 18, Theme.BLUE, 1)
        setOnClickListener { onClick() }
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
        background = UI.rect(this@PageActivity, 0x4410305F, 20, Theme.BLUE, 1)
    }

    private fun build() {
        val page = intent.getStringExtra("page") ?: "settings"
        val mods = page == "js" || page == "mods"
        val scroll = ScrollView(this).apply { background = UI.bg(this@PageActivity) }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(30), dp(18), dp(28))
        }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(this).apply {
            text = "←"; textSize = 30f; setTextColor(Theme.BLUE); setPadding(0, 0, dp(16), 0)
            setOnClickListener { finish() }
        })
        head.addView(title(if (mods) "Modlar" else "Ayarlar", 28f))
        col.addView(head)
        if (mods) modsPage(col) else settingsPage(col)
        scroll.addView(col)
        setContentView(scroll)
    }

    // ---------------- Modlar ----------------
    private fun modsPage(col: LinearLayout) {
        col.add(note("Bir mod ekle, anahtarı aç, oyuna gir. ⭐ ile oyunda kısayol olur."), 6)
        col.add(big("＋  Mod ekle (.js dosyası)") { pick("js") }, 14)
        col.add(big("Hazır modülleri ekle", false) {
            val n = Store.installBuiltins(this)
            toast(if (n > 0) "$n hazır mod eklendi" else "Hazır modlar zaten ekli"); build()
        }, 8)
        val list = Store.scripts(this)
        if (list.isEmpty()) col.add(note("Henüz mod yok. Yukarıdan ekle."), 18)
        for (n in list) col.add(modCard(n), 14)
    }

    private fun modCard(n: String): View {
        val c = card()
        val on = Store.enabled(this, n)
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val state = UI.label(this, if (on) "AÇIK" else "KAPALI", 12f, if (on) 0xFF6DFFB0.toInt() else 0xFF8FA6C4.toInt())
        val names = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        names.addView(title(Store.alias(this, n), 19f))
        names.addView(state)
        top.addView(names, LinearLayout.LayoutParams(0, WRAP, 1f))
        top.addView(Switch(this).apply {
            isChecked = on; scaleX = 1.35f; scaleY = 1.35f; setPadding(dp(8), 0, dp(10), 0)
            val st = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
            thumbTintList = ColorStateList(st, intArrayOf(Theme.BLUE, 0xFF9FB3CC.toInt()))
            trackTintList = ColorStateList(st, intArrayOf(Theme.BLUE2, 0xFF2A3B57.toInt()))
            setOnCheckedChangeListener { _, v ->
                Store.setEnabled(this@PageActivity, n, v)
                runCatching { Store.sync(this@PageActivity, n, v) }
                state.text = if (v) "AÇIK" else "KAPALI"
                state.setTextColor(if (v) 0xFF6DFFB0.toInt() else 0xFF8FA6C4.toInt())
            }
        })
        c.addView(top)

        val row = LinearLayout(this)
        fun pill(t: String, active: Boolean = false, onClick: () -> Unit) = TextView(this).apply {
            text = t; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setTextColor(if (active) Theme.NAVY0 else Color.WHITE)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = if (active) UI.rect(this@PageActivity, Theme.BLUE, 14)
            else UI.rect(this@PageActivity, 0x33FFFFFF, 14, Theme.BLUE, 1)
            setOnClickListener { onClick() }
        }
        val pinned = Store.pinned(this, n)
        row.addView(pill(if (pinned) "⭐ Kısayol açık" else "☆ Kısayol", pinned) {
            Store.setPinned(this, n, !pinned); build()
        }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(8) })
        val opts = ScriptOpts.options(this, n)
        val isOpen = n in open
        if (opts.isNotEmpty()) row.addView(pill(if (isOpen) "⚙ Gizle" else "⚙ Ayarlar", isOpen) {
            if (isOpen) open.remove(n) else open.add(n); build()
        }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(8) })
        row.addView(pill("🗑") {
            AlertDialog.Builder(this).setTitle("Silinsin mi?").setMessage(Store.alias(this, n))
                .setPositiveButton("Sil") { _, _ -> Store.deleteScript(this, n); open.remove(n); build() }
                .setNegativeButton("Vazgeç", null).show()
        })
        c.add(row, 12)
        if (isOpen) for (o in opts) c.add(optRow(n, o), 10)
        return c
    }

    private fun save(n: String, o: ScriptOpts.Opt, v: String) {
        Store.setVal(this, n, o.key, v)
        if (Store.enabled(this, n)) runCatching { Store.sync(this, n, true) }
    }

    private fun optRow(n: String, o: ScriptOpts.Opt): View {
        val cv = ScriptOpts.current(this, n, o)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = UI.rect(this@PageActivity, 0x22000000, 14)
        }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(UI.label(this, o.name, 15f), LinearLayout.LayoutParams(0, WRAP, 1f))
        when (o.type) {
            "boolean" -> {
                head.addView(Switch(this).apply {
                    isChecked = cv == "true"
                    val st = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
                    thumbTintList = ColorStateList(st, intArrayOf(Theme.BLUE, 0xFF9FB3CC.toInt()))
                    trackTintList = ColorStateList(st, intArrayOf(Theme.BLUE2, 0xFF2A3B57.toInt()))
                    setOnCheckedChangeListener { _, v -> save(n, o, v.toString()) }
                })
                box.addView(head)
            }
            "enum" -> {
                val pill = TextView(this).apply {
                    text = cv; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Theme.NAVY0)
                    setPadding(dp(14), dp(8), dp(14), dp(8)); background = UI.rect(this@PageActivity, Theme.BLUE, 12)
                }
                pill.setOnClickListener {
                    val now = ScriptOpts.current(this, n, o)
                    if (o.values.isNotEmpty()) {
                        val nx = o.values[(o.values.indexOf(now) + 1) % o.values.size]
                        save(n, o, nx); pill.text = nx
                    }
                }
                head.addView(pill); box.addView(head)
            }
            else -> {
                val steps = Math.round((o.max - o.min) / o.step).toInt().coerceAtLeast(1)
                val val_ = UI.label(this, cv, 14f, Theme.BLUE)
                head.addView(val_); box.addView(head)
                val start = Math.round(((cv.toDoubleOrNull() ?: o.min) - o.min) / o.step).toInt().coerceIn(0, steps)
                box.addView(SeekBar(this).apply {
                    max = steps; progress = start
                    progressTintList = ColorStateList.valueOf(Theme.BLUE); thumbTintList = ColorStateList.valueOf(Theme.BLUE)
                    setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                        override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) {
                            val v = ScriptOpts.fmt(o.min + p * o.step, o.step); val_.text = v
                        }
                        override fun onStartTrackingTouch(s: SeekBar) {}
                        override fun onStopTrackingTouch(s: SeekBar) {
                            save(n, o, ScriptOpts.fmt(o.min + s.progress * o.step, o.step))
                        }
                    })
                }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(6) })
            }
        }
        return box
    }

    // ---------------- Ayarlar ----------------
    private fun settingsPage(col: LinearLayout) {
        // 1) Izin
        val perm = card()
        perm.addView(title("Oyunun üstünde göster", 18f))
        if (Settings.canDrawOverlays(this)) {
            perm.add(UI.label(this, "✓  İzin verildi", 15f, 0xFF6DFFB0.toInt()), 6)
        } else {
            perm.add(note("Baloncuk için bu izin gerekli."), 4)
            perm.add(big("İzin ver") {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }, 10)
        }
        col.add(perm, 16)

        // 2) Baloncuk
        val bub = card()
        bub.addView(title("Baloncuk", 18f))
        bub.add(UI.label(this, "Boyut", 14f), 10)
        bub.add(UI.blueSeek(this, 60, size - 40) { size = it + 40 }, 2)
        bub.add(UI.label(this, "Şeffaflık", 14f), 10)
        bub.add(UI.blueSeek(this, 70, this@PageActivity.alpha - 30) { this@PageActivity.alpha = it + 30 }, 2)
        bub.add(UI.label(this, "Kısayol boyutu", 14f), 10)
        bub.add(UI.blueSeek(this, 80, ssize - 24) { ssize = it + 24 }, 2)
        bub.add(note("Değişiklik, baloncuk yeniden açılınca geçerli olur."), 8)
        col.add(bub, 14)

        // 3) Oyunda isim
        val nm = card()
        nm.addView(title("Oyunda görünen isim", 18f))
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        row.addView(UI.label(this, "Göster", 15f), LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(Switch(this).apply {
            isChecked = this@PageActivity.stextOn
            val st = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
            thumbTintList = ColorStateList(st, intArrayOf(Theme.BLUE, 0xFF9FB3CC.toInt()))
            trackTintList = ColorStateList(st, intArrayOf(Theme.BLUE2, 0xFF2A3B57.toInt()))
            setOnCheckedChangeListener { _, v -> this@PageActivity.stextOn = v }
        })
        nm.add(row, 8)
        val cur = this@PageActivity.stext
        nm.add(UI.label(this, "Şu an: " + (if (cur.length > 24) cur.take(24) + "…" else cur), 14f, Theme.BLUE), 8)
        nm.add(big("İsmi değiştir", false) {
            val et = EditText(this).apply { setText(this@PageActivity.stext) }
            AlertDialog.Builder(this).setTitle("İsim").setView(et)
                .setPositiveButton("Tamam") { _, _ ->
                    val t = et.text.toString()
                    this@PageActivity.stext = if (t.isBlank()) Store.defaultText else t
                    build()
                }.setNegativeButton("Vazgeç", null).show()
        }, 10)
        col.add(nm, 14)

        // 4) ProtoHax klasoru (istege bagli)
        val fo = card()
        fo.addView(title("ProtoHax klasörü", 18f))
        fo.add(UI.label(this, if (Store.folder(this) == null) "Seçilmedi" else "✓  Seçili", 15f,
            if (Store.folder(this) == null) 0xFFFFB86B.toInt() else 0xFF6DFFB0.toInt()), 6)
        fo.add(note("Sadece ProtoHax ile kullanacaksan gerekli. Proxy modunda gerekmez."), 4)
        fo.add(big("Klasör seç", false) { pick("dir") }, 10)
        col.add(fo, 14)

        // 5) Yedek
        val bk = card()
        bk.addView(title("Yedek", 18f))
        bk.add(big("Ayarları yükle", false) { pick("cfgin") }, 10)
        bk.add(big("Ayarları kaydet", false) { pick("cfgout") }, 8)
        col.add(bk, 14)
    }
}
