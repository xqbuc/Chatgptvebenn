package com.sneinle.client

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.core.content.ContextCompat
import com.sneinle.client.proxy.ProxyService
import com.sneinle.client.proxy.ProxyState
import com.sneinle.client.proxy.XboxAuth

/** Proxy modu: Xbox girisi, hedef sunucu, baslat. (ProtoHax'siz JS calistirma) */
class ProxyActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private lateinit var logv: TextView
    private lateinit var account: TextView
    private val prefs get() = Store.sp(this)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun btn(t: String, onClick: () -> Unit) = UI.button(this, t, onClick).apply {
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(28), dp(18), dp(18))
            background = UI.bg(this@ProxyActivity)
        }
        fun tv(t: String, sz: Float = 14f, c: Int = Color.WHITE) = TextView(this).apply { text = t; textSize = sz; setTextColor(c) }
        col.addView(tv("Sunucu", 28f, 0xFF4DB8FF.toInt()))
        account = tv("")
        status = tv("")
        col.addView(account); col.addView(status)

        col.addView(btn("Xbox ile giriş yap") { startLogin() })
        col.addView(btn("Xbox çıkış") { XboxAuth.logout(this); refresh() })

        col.addView(tv("Hedef sunucu (adres:port)", 13f, 0xFFCFE9FF.toInt()))
        val et = EditText(this).apply {
            setText(com.sneinle.client.proxy.Targets.current(this).takeUnless { it.startsWith("realm:") } ?: ""); hint = "ornek: play.sunucu.com:19132"
            setTextColor(Color.WHITE); setHintTextColor(0x88FFFFFF.toInt()); setSingleLine()
        }
        col.addView(et)
        col.addView(btn("Başlat ve Minecraft'ı aç") {
            val t = et.text.toString().trim()
            val cur = com.sneinle.client.proxy.Targets.current(this)
            if (t.isEmpty() && cur.isEmpty()) { toast("Hedef sunucu yaz (ya da oyun ici baloncuktan sec)"); return@btn }
            if (t.isNotEmpty()) {
                com.sneinle.client.proxy.Targets.add(this, t, t)
                com.sneinle.client.proxy.Targets.select(this, t)
            }
            start(if (t.isNotEmpty()) t else cur)
        })
        col.addView(btn("Durdur") { ProxyService.stop(this) })

        logv = tv("", 11f, 0xFF9FB6CF.toInt()).apply { setTextIsSelectable(true) }
        col.addView(logv)
        setContentView(ScrollView(this).apply { addView(col, ViewGroup.LayoutParams(-1, -2)) })
        tick()
    }

    private fun tick() {
        refresh()
        ui.postDelayed({ tick() }, 1000)
    }

    private fun refresh() {
        account.text = "Hesap: " + (ProxyState.account ?: if (XboxAuth.hasSaved(this)) "kayitli (yenilenecek)" else "giris yapilmadi")
        val code = ProxyState.loginCode
        status.text = "Durum: " + ProxyState.status + (if (code != null) "\nKod: $code  (microsoft.com/link)" else "")
        logv.text = ProxyState.logText()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun startLogin() {
        ProxyState.status = "Xbox girisi baslatiliyor"
        XboxAuth.login(this, { url, code ->
            ui.post {
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                    .setPrimaryClip(ClipData.newPlainText("kod", code))
                toast("Kod kopyalandi: $code")
                runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
            }
        }, { err ->
            ui.post {
                ProxyState.status = if (err == null) "Xbox girisi tamam" else "Giris hatasi: $err"
                refresh()
            }
        })
    }

    private fun start(target: String) {
        if (!Settings.canDrawOverlays(this)) {
            toast("Once ustte gosterme iznini ver")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val host = if (target.startsWith("realm:")) "" else target.substringBeforeLast(':', target)
        val port = if (target.contains(':')) target.substringAfterLast(':').toIntOrNull() ?: 19132 else 19132
        ProxyService.start(this, host, port)
        ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java).setAction("LOADING"))
        // Minecraft'a sunucuyu eklet; olmazsa oyunu normal ac.
        val add = Intent(Intent.ACTION_VIEW, Uri.parse("minecraft://?addExternalServer=Frezie|127.0.0.1:${ProxyService.LOCAL_PORT}"))
            .setPackage("com.mojang.minecraftpe")
        val ok = runCatching { startActivity(add) }.isSuccess
        if (!ok) packageManager.getLaunchIntentForPackage("com.mojang.minecraftpe")?.let { startActivity(it) }
    }
}
