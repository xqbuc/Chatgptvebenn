package com.sneinle.client

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.util.TypedValue
import android.view.View
import android.view.animation.LinearInterpolator

object Styles {
    val names = listOf("Rainbow", "Rainbow black-gold", "Rainbow black-white", "Rainbow white-red")
    fun colors(i: Int): IntArray = when (i) {
        1 -> intArrayOf(0xFF000000.toInt(), 0xFFFFD700.toInt(), 0xFF000000.toInt())
        2 -> intArrayOf(0xFF000000.toInt(), 0xFFFFFFFF.toInt(), 0xFF000000.toInt())
        3 -> intArrayOf(0xFFFFFFFF.toInt(), 0xFFFF1744.toInt(), 0xFFFFFFFF.toInt())
        else -> IntArray(7) { Color.HSVToColor(floatArrayOf(it * 60f, 1f, 1f)) }
    }
    fun outline(i: Int): Int = when (i) {
        1, 2 -> 0xAAFFFFFF.toInt()
        else -> 0xAA000000.toInt()
    }
}

/** Renkleri kayan (rainbow) animasyonlu yazı. */
class RainbowTextView(ctx: Context) : View(ctx) {
    var text: String = "Frezie"
        set(v) { field = v; requestLayout(); invalidate() }
    var styleIdx: Int = 0
        set(v) { field = v; shader = null; invalidate() }
    var textSp: Float = 22f
        set(v) { field = v; requestLayout(); invalidate() }

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.DEFAULT_BOLD }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.DEFAULT_BOLD; style = Paint.Style.STROKE; strokeJoin = Paint.Join.ROUND
    }
    private var shader: LinearGradient? = null
    private var shaderW = 0f
    private var phase = 0f
    private val pad = 6 * resources.displayMetrics.density
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2500; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { phase = it.animatedValue as Float; invalidate() }
    }

    private fun applySize() {
        val px = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, textSp, resources.displayMetrics)
        fill.textSize = px; stroke.textSize = px
        stroke.strokeWidth = 2 * resources.displayMetrics.density
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        applySize()
        val lines = text.split("\n")
        val w = (lines.maxOf { fill.measureText(it) } + pad * 2).toInt()
        val lh = fill.fontMetrics.let { it.descent - it.ascent }
        setMeasuredDimension(w, (lh * lines.size + pad * 2).toInt())
    }

    override fun onDraw(c: Canvas) {
        applySize()
        val gw = maxOf(width.toFloat(), 1f)
        if (shader == null || shaderW != gw) {
            shader = LinearGradient(0f, 0f, gw, 0f, Styles.colors(styleIdx), null, Shader.TileMode.REPEAT)
            shaderW = gw
        }
        shader!!.setLocalMatrix(Matrix().apply { setTranslate(phase * gw, 0f) })
        fill.shader = shader
        stroke.color = Styles.outline(styleIdx)
        val fm = fill.fontMetrics
        val lh = fm.descent - fm.ascent
        text.split("\n").forEachIndexed { i, l ->
            val y = pad - fm.ascent + i * lh
            c.drawText(l, pad, y, stroke)
            c.drawText(l, pad, y, fill)
        }
    }
}
