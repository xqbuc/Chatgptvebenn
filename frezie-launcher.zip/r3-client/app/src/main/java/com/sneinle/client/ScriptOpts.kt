package com.sneinle.client

import android.content.Context
import java.math.BigDecimal
import java.math.RoundingMode

/** J's dosyasındaki ayar tanımlarını (tek satırlık ve çok satırlı) okur, seçilen değerleri def: alanına yazar. */
object ScriptOpts {
    class Opt(
        val key: String, val type: String, val name: String, val def: String,
        val min: Double, val max: Double, val step: Double, val values: List<String>,
        val start: Int, val end: Int   // dosya metnindeki { ... } bloğunun aralığı
    )

    private val keyBlock = Regex("""([A-Za-z_]\w*)\s*:\s*\{""")
    private val defRe = Regex("""(\bdef:\s*)(-?[\d.]+|true|false|"(?:[^"\\]|\\.)*")""")

    private fun str(body: String, k: String) =
        Regex("""\b$k:\s*"((?:[^"\\]|\\.)*)"""").find(body)?.groupValues?.get(1)
    private fun num(body: String, k: String) =
        Regex("""\b$k:\s*(-?[\d.]+)""").find(body)?.groupValues?.get(1)?.toDoubleOrNull()

    /** open, '{' karakterinin indeksi. Eşleşen '}' indeksini döner (yoksa -1). Metinleri atlar. */
    private fun matchBrace(t: String, open: Int): Int {
        var depth = 0; var i = open
        while (i < t.length) {
            val c = t[i]
            if (c == '"' || c == '\'' || c == '`') {
                val q = c; i++
                while (i < t.length && t[i] != q) { if (t[i] == '\\') i++; i++ }
            } else if (c == '/' && i + 1 < t.length && t[i + 1] == '/') {
                while (i < t.length && t[i] != '\n') i++
            } else if (c == '{') depth++
            else if (c == '}') { depth--; if (depth == 0) return i }
            i++
        }
        return -1
    }

    fun parse(text: String): List<Opt> {
        val out = mutableListOf<Opt>()
        var pos = 0
        while (true) {
            val m = keyBlock.find(text, pos) ?: break
            val open = m.range.last
            val close = matchBrace(text, open)
            if (close < 0) { pos = m.range.last + 1; continue }
            val body = text.substring(open, close + 1)
            val type = str(body, "type")
            val d = defRe.find(body)?.groupValues?.get(2)
            if (type != null && (type == "number" || type == "boolean" || type == "enum") && d != null) {
                val values = Regex("""values:\s*\[(.*?)]""", RegexOption.DOT_MATCHES_ALL).find(body)?.groupValues?.get(1)
                    ?.let { v -> Regex(""""((?:[^"\\]|\\.)*)"""").findAll(v).map { it.groupValues[1] }.toList() }
                    ?: emptyList()
                out.add(Opt(
                    m.groupValues[1], type, str(body, "name") ?: m.groupValues[1], d.trim('"'),
                    num(body, "min") ?: 0.0, num(body, "max") ?: 1.0, num(body, "step") ?: 1.0, values,
                    open, close + 1))
                pos = close + 1
            } else pos = m.range.last + 1
        }
        return out
    }

    fun options(c: Context, script: String) = parse(Store.scriptText(c, script))
    fun current(c: Context, script: String, o: Opt) = Store.getVal(c, script, o.key) ?: o.def

    fun fmt(d: Double, step: Double): String {
        val s = BigDecimal(step.toString()).stripTrailingZeros()
        val scale = maxOf(0, s.scale())
        return BigDecimal(d).setScale(scale, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString()
    }

    /** Kaydedilen değerleri dosya metnine uygular (sondan başa, indeksler kaymasın). */
    fun apply(c: Context, script: String, text: String): String {
        var out = text
        for (o in parse(text).sortedByDescending { it.start }) {
            val v = Store.getVal(c, script, o.key) ?: continue
            val rep = if (o.type == "enum") "\"" + v.replace("\\", "\\\\").replace("\"", "\\\"") + "\"" else v
            val block = out.substring(o.start, o.end)
            val nb = defRe.replace(block) { r -> r.groupValues[1] + rep }
            out = out.substring(0, o.start) + nb + out.substring(o.end)
        }
        return out
    }
}
