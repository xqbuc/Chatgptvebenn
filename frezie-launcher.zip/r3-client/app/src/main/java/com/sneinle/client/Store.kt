package com.sneinle.client

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import org.json.JSONObject
import java.io.File

object Store {
    fun sp(c: Context) = c.getSharedPreferences("sneinle", Context.MODE_PRIVATE)


    private val skip = setOf("folder", "builtinDone", "builtinSeen", "hidden", "failWhy", "warn")

    /** Ayarları (J's değerleri, açık J's'ler, shortcut, Special yazı...) .cfg metnine çevirir. */
    fun exportCfg(c: Context): String {
        val o = JSONObject()
        for ((k, v) in sp(c).all) {
            if (k in skip) continue
            val e = JSONObject()
            when (v) {
                is String -> { e.put("t", "s"); e.put("v", v) }
                is Int -> { e.put("t", "i"); e.put("v", v) }
                is Boolean -> { e.put("t", "b"); e.put("v", v) }
                is Set<*> -> { e.put("t", "ss"); e.put("v", org.json.JSONArray(v.map { it.toString() })) }
                else -> continue
            }
            o.put(k, e)
        }
        return o.toString(1)
    }

    fun importCfg(c: Context, text: String): Boolean = try {
        val o = JSONObject(text)
        val ed = sp(c).edit()
        for (k in o.keys()) {
            if (k in skip) continue
            val e = o.getJSONObject(k)
            when (e.getString("t")) {
                "s" -> ed.putString(k, e.getString("v"))
                "i" -> ed.putInt(k, e.getInt("v"))
                "b" -> ed.putBoolean(k, e.getBoolean("v"))
                "ss" -> {
                    val a = e.getJSONArray("v")
                    ed.putStringSet(k, (0 until a.length()).map { a.getString(it) }.toSet())
                }
            }
        }
        ed.apply()
        // Açık olan J's'leri yeni ayarlarla ProtoHax klasörüne tekrar yaz
        scripts(c).filter { enabled(c, it) }.forEach { sync(c, it, true) }
        true
    } catch (e: Exception) { false }

    /** assets/builtin içindeki hazır J's modüllerini J's klasörüne kopyalar. Var olanı ezmez (overwrite=true ise ezer). */
    fun installBuiltins(c: Context, overwrite: Boolean = false): Int {
        var n = 0
        val names = c.assets.list("builtin") ?: return 0
        for (name in names) {
            if (!name.endsWith(".js")) continue
            val f = File(jsDir(c), name)
            if (f.exists() && !overwrite) continue
            c.assets.open("builtin/$name").use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            n++
        }
        sp(c).edit().putBoolean("builtinDone", true).apply()
        return n
    }
    private val legacyBuiltins = setOf(
        "AntiAFK.js", "BoatFly.js", "CPSClicker.js", "DashKey.js", "DeathPoint.js", "ESP.js", "ElytraSpeed.js",
        "Fly.js", "Fullbright.js", "HealthTag.js", "HoldSneak.js", "HoverFly.js", "LagPulse.js", "LowHealthAlert.js",
        "NoBlur.js", "NoSlow.js", "Noclip.js", "TpAura.js", "Trigger.js")

    /** Daha once gorulmemis yeni hazir J's dosyalarini kurar (kullanicinin sildigi eskileri geri getirmez). */
    fun installNewBuiltins(c: Context): Int {
        val names = c.assets.list("builtin")?.filter { it.endsWith(".js") } ?: return 0
        val p = sp(c)
        val seen = p.getStringSet("builtinSeen", null)?.toMutableSet()
            ?: (if (builtinsDone(c)) legacyBuiltins.toMutableSet() else mutableSetOf())
        var n = 0
        for (name in names) {
            if (name in seen) continue
            val f = File(jsDir(c), name)
            if (!f.exists()) {
                c.assets.open("builtin/$name").use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                n++
            }
            seen.add(name)
        }
        p.edit().putStringSet("builtinSeen", seen).putBoolean("builtinDone", true).apply()
        return n
    }

    fun builtinsDone(c: Context) = sp(c).getBoolean("builtinDone", false)

    fun jsDir(c: Context) = File(c.filesDir, "js").apply { mkdirs() }
    fun scripts(c: Context): List<String> =
        jsDir(c).listFiles { f -> f.name.endsWith(".js") }?.map { it.name }?.sorted() ?: emptyList()
    fun scriptText(c: Context, n: String) = File(jsDir(c), n).readText()

    fun alias(c: Context, n: String): String = sp(c).getString("al:$n", null) ?: n.removeSuffix(".js")
    fun setAlias(c: Context, n: String, v: String) =
        sp(c).edit().putString("al:$n", v.trim().ifEmpty { n.removeSuffix(".js") }).apply()
    fun deleteScript(c: Context, n: String) {
        sync(c, n, false)
        File(jsDir(c), n).delete()
        setEnabled(c, n, false); setPinned(c, n, false); clearVals(c, n)
    }

    fun folder(c: Context): String? = sp(c).getString("folder", null)
    fun setFolder(c: Context, uri: String) = sp(c).edit().putString("folder", uri).apply()

    var Context.size: Int
        get() = sp(this).getInt("size", 56)
        set(v) = sp(this).edit().putInt("size", v).apply()
    var Context.alpha: Int
        get() = sp(this).getInt("alpha", 100)
        set(v) = sp(this).edit().putInt("alpha", v).apply()
    var Context.ssize: Int
        get() = sp(this).getInt("ssize", 44)
        set(v) = sp(this).edit().putInt("ssize", v).apply()

    var Context.stextOn: Boolean
        get() = sp(this).getBoolean("stextOn", true)
        set(v) = sp(this).edit().putBoolean("stextOn", v).apply()
    val defaultText: String = "Frezie"
    var Context.stext: String
        get() = sp(this).getString("stext", defaultText)!!
        set(v) = sp(this).edit().putString("stext", v).apply()
    var Context.sstyle: Int
        get() = sp(this).getInt("sstyle", 0)
        set(v) = sp(this).edit().putInt("sstyle", v).apply()
    var Context.stsize: Int
        get() = sp(this).getInt("stsize", 22)
        set(v) = sp(this).edit().putInt("stsize", v).apply()
    fun textPos(c: Context): Pair<Int, Int>? {
        val s = sp(c)
        return if (s.contains("tx")) Pair(s.getInt("tx", 0), s.getInt("ty", 0)) else null
    }
    fun setTextPos(c: Context, x: Int, y: Int) = sp(c).edit().putInt("tx", x).putInt("ty", y).apply()
    fun resetTextPos(c: Context) = sp(c).edit().remove("tx").remove("ty").apply()

    // Müzik: ekrandaki ikon / isim ayarları ve konumları
    var Context.musicOn: Boolean
        get() = sp(this).getBoolean("musicOn", true)
        set(v) = sp(this).edit().putBoolean("musicOn", v).apply()
    var Context.musicIconOn: Boolean
        get() = sp(this).getBoolean("musicIconOn", true)
        set(v) = sp(this).edit().putBoolean("musicIconOn", v).apply()
    var Context.musicNameOn: Boolean
        get() = sp(this).getBoolean("musicNameOn", true)
        set(v) = sp(this).edit().putBoolean("musicNameOn", v).apply()
    var Context.musicIconSize: Int
        get() = sp(this).getInt("musicIconSize", 40)
        set(v) = sp(this).edit().putInt("musicIconSize", v).apply()
    var Context.musicNameSize: Int
        get() = sp(this).getInt("musicNameSize", 13)
        set(v) = sp(this).edit().putInt("musicNameSize", v).apply()
    var Context.musicVol: Int
        get() = sp(this).getInt("musicVol", 80)
        set(v) = sp(this).edit().putInt("musicVol", v).apply()
    var Context.musicAuto: Boolean
        get() = sp(this).getBoolean("musicAuto", true)
        set(v) = sp(this).edit().putBoolean("musicAuto", v).apply()
    var Context.musicTrack: Int
        get() = sp(this).getInt("musicTrack", 0)
        set(v) = sp(this).edit().putInt("musicTrack", v).apply()
    fun musicPos(c: Context, which: String): Pair<Int, Int>? {
        val s = sp(c)
        return if (s.contains("mx:$which")) Pair(s.getInt("mx:$which", 0), s.getInt("my:$which", 0)) else null
    }
    fun setMusicPos(c: Context, which: String, x: Int, y: Int) =
        sp(c).edit().putInt("mx:$which", x).putInt("my:$which", y).apply()
    fun resetMusicPos(c: Context) {
        val e = sp(c).edit()
        sp(c).all.keys.filter { it.startsWith("mx:") || it.startsWith("my:") }.forEach { e.remove(it) }
        e.apply()
    }

    // Shortcut konumları
    fun shortcutPos(c: Context, n: String): Pair<Int, Int>? {
        val s = sp(c)
        return if (s.contains("sx:$n")) Pair(s.getInt("sx:$n", 0), s.getInt("sy:$n", 0)) else null
    }
    fun setShortcutPos(c: Context, n: String, x: Int, y: Int) =
        sp(c).edit().putInt("sx:$n", x).putInt("sy:$n", y).apply()
    fun resetShortcutPos(c: Context) {
        val e = sp(c).edit()
        sp(c).all.keys.filter { it.startsWith("sx:") || it.startsWith("sy:") }.forEach { e.remove(it) }
        e.apply()
    }

    // J's ayar değerleri
    fun getVal(c: Context, script: String, key: String): String? = sp(c).getString("v:$script:$key", null)
    fun setVal(c: Context, script: String, key: String, v: String) =
        sp(c).edit().putString("v:$script:$key", v).apply()
    fun clearVals(c: Context, script: String) {
        val e = sp(c).edit()
        sp(c).all.keys.filter { it.startsWith("v:$script:") }.forEach { e.remove(it) }
        e.apply()
    }

    fun enabled(c: Context, n: String) = sp(c).getStringSet("on", emptySet())!!.contains(n)
    fun pinned(c: Context, n: String) = sp(c).getStringSet("pin", emptySet())!!.contains(n)
    fun pinnedList(c: Context) = scripts(c).filter { pinned(c, it) }

    private fun flip(c: Context, key: String, n: String, on: Boolean) {
        val s = sp(c).getStringSet(key, emptySet())!!.toMutableSet()
        if (on) s.add(n) else s.remove(n)
        sp(c).edit().putStringSet(key, s).apply()
    }
    fun setEnabled(c: Context, n: String, on: Boolean) = flip(c, "on", n, on)
    fun setPinned(c: Context, n: String, on: Boolean) = flip(c, "pin", n, on)

    // ---- Baloncuk: gizli durumu ve konumu (uygulama kapanıp açılsa da korunur) ----
    fun isHidden(c: Context) = sp(c).getBoolean("hidden", false)
    fun setHidden(c: Context, v: Boolean) = sp(c).edit().putBoolean("hidden", v).apply()
    fun bubblePos(c: Context): Pair<Int, Int>? {
        val s = sp(c)
        return if (s.contains("bx")) Pair(s.getInt("bx", 0), s.getInt("by", 0)) else null
    }
    fun setBubblePos(c: Context, x: Int, y: Int) = sp(c).edit().putInt("bx", x).putInt("by", y).apply()

    // ---- J's metni temizliği ve içe aktarma ----
    /** BOM'u atar, satır sonlarını \n yapar, sona satır sonu ekler. ProtoHax'in ayrıştırıcısı bunlara takılabilir. */
    fun clean(t: String): String {
        var s = t.removePrefix("\uFEFF").replace("\r\n", "\n").replace('\r', '\n')
        if (!s.endsWith("\n")) s += "\n"
        return s
    }

    private fun decode(b: ByteArray): String {
        return try {
            Charsets.UTF_8.newDecoder().onMalformedInput(java.nio.charset.CodingErrorAction.REPORT)
                .onUnmappableCharacter(java.nio.charset.CodingErrorAction.REPORT)
                .decode(java.nio.ByteBuffer.wrap(b)).toString()
        } catch (e: Exception) {
            String(b, java.nio.charset.Charset.forName("windows-1254"))
        }
    }

    /** Gelen dosya adını .js'e çevirir (.mjs/.cjs/.txt/.js.txt/.js.bin...). Kabul edilmezse null. */
    private fun jsName(raw: String, text: String): String? {
        var n = raw.trim().substringAfterLast('/').substringAfterLast('\\')
        var viaTxt = false
        while (true) {
            val l = n.lowercase()
            val cut = listOf(".bin", ".txt", ".tmp", ".download", ".part").firstOrNull { l.endsWith(it) } ?: break
            if (cut == ".txt") viaTxt = true
            n = n.dropLast(cut.length)
        }
        val l = n.lowercase()
        val base = when {
            l.endsWith(".js") || l.endsWith(".mjs") || l.endsWith(".cjs") -> n.substringBeforeLast('.')
            viaTxt && (text.contains("defineModule") || text.contains("@protohax")) -> n
            else -> return null
        }
        val safe = base.map { if (it.isLetterOrDigit() || it == '-' || it == '_' || it == ' ' || it == '.') it else '_' }
            .joinToString("").trim().trim('.')
        return (if (safe.isEmpty()) "script" else safe) + ".js"
    }

    /** Tek bir dosyayı J's klasörüne kaydeder; zip ise içindeki J's'leri çıkarır. Kaydedilen adları döner. */
    fun importFile(c: Context, rawName: String, bytes: ByteArray): List<String> {
        val out = mutableListOf<String>()
        if (rawName.lowercase().endsWith(".zip")) {
            runCatching {
                java.util.zip.ZipInputStream(bytes.inputStream()).use { z ->
                    while (true) {
                        val e = z.nextEntry ?: break
                        if (e.isDirectory || e.name.contains("__MACOSX")) continue
                        out += importFile(c, e.name, z.readBytes())
                    }
                }
            }
            return out
        }
        val text = clean(decode(bytes))
        val name = jsName(rawName, text) ?: return out
        var f = File(jsDir(c), name)
        val base = name.removeSuffix(".js"); var k = 2
        while (f.exists()) { f = File(jsDir(c), "$base-$k.js"); k++ }
        f.writeText(text)
        out += f.name
        return out
    }

    // ---- ProtoHax klasörüne yazma ----
    private fun mimeCandidates(name: String): List<String> {
        val ext = name.substringAfterLast('.', "")
        val fromExt = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
        return listOfNotNull(fromExt, "application/javascript", "text/javascript", "application/x-javascript", "application/octet-stream").distinct()
    }

    /** Klasördeki bu J's'e ait her kopya: Fly.js, Fly.js.bin, Fly.js.txt, "Fly (1).js" */
    private fun isStray(name: String, f: String): Boolean {
        if (f == name || f.startsWith("$name.")) return true
        val base = name.removeSuffix(".js")
        return Regex("^" + Regex.escape(base) + " ?\\(\\d+\\)\\.js$").matches(f)
    }

    /** Uygulanmış metin bozulduysa (parantez/metin kapanmamış) ayarsız özgün metni kullanır. */
    private fun finalText(c: Context, name: String): String {
        val base = clean(scriptText(c, name))
        val applied = clean(ScriptOpts.apply(c, name, base))
        return if (applied != base && JsLint.check(base) == null && JsLint.check(applied) != null) base else applied
    }

    /** Açık J's'i (ayarları uygulanmış halde) ProtoHax klasörüne yazar, kapatılınca siler.
     *  Sağlayıcı ".bin" gibi uzantı eklerse düzeltir, yazdıktan sonra dosyayı geri okuyup doğrular. */
    fun sync(c: Context, name: String, on: Boolean): Boolean {
        val uri = folder(c) ?: return false
        return try {
            val tree = DocumentFile.fromTreeUri(c, Uri.parse(uri)) ?: return false
            if (!tree.exists() || !tree.canWrite()) return false
            tree.listFiles().filter { f -> f.name?.let { isStray(name, it) } == true }
                .forEach { runCatching { it.delete() } }
            if (!on) return true
            val bytes = finalText(c, name).toByteArray(Charsets.UTF_8)
            for (mime in mimeCandidates(name)) {
                val made = tree.createFile(mime, name) ?: continue
                if (made.name != name) {
                    runCatching { made.renameTo(name) }
                }
                val target = tree.findFile(name)
                if (target == null) { runCatching { made.delete() }; continue }
                val wrote = runCatching {
                    c.contentResolver.openOutputStream(target.uri, "wt")!!.use { it.write(bytes); it.flush() }
                    c.contentResolver.openInputStream(target.uri)!!.use { it.readBytes() }.contentEquals(bytes)
                }.getOrDefault(false)
                if (wrote) {
                    tree.listFiles().filter { f -> f.name != name && f.name?.let { isStray(name, it) } == true }
                        .forEach { runCatching { it.delete() } }
                    return true
                }
                runCatching { target.delete() }
            }
            false
        } catch (e: Exception) { false }
    }

    // ---- Başlatma öncesi J's kontrolü ----
    fun warnText(c: Context): String? = sp(c).getString("warn", null)
    fun failWhy(c: Context): String? = sp(c).getString("failWhy", null)
    fun setFailWhy(c: Context, v: String?) {
        val e = sp(c).edit()
        if (v == null) e.remove("failWhy") else e.putString("failWhy", v)
        e.apply()
    }

    /** Sorun yoksa null, varsa nedenini döner. Eksik J's'leri kurar, klasöre yazmayı dener, dosyaları doğrular. */
    fun preflight(c: Context): String? {
        if (scripts(c).isEmpty()) runCatching { installBuiltins(c, false) }
        if (scripts(c).isEmpty()) return "J's dosyası yok"
        val uri = folder(c) ?: return "ProtoHax klasörü seçilmedi"
        val tree = try { DocumentFile.fromTreeUri(c, Uri.parse(uri)) } catch (e: Exception) { null }
        if (tree == null || !tree.exists()) return "ProtoHax klasörü bulunamadı"
        if (!tree.canWrite()) return "ProtoHax klasörüne yazma izni yok"
        var bad = 0
        val warns = mutableListOf<String>()
        for (n in scripts(c).filter { enabled(c, it) }) {
            JsLint.check(scriptText(c, n))?.let { warns += "$n: $it" }
            var ok = sync(c, n, true)
            if (!ok) ok = sync(c, n, true)
            if (!ok || tree.findFile(n) == null) bad++
        }
        sp(c).edit().apply { if (warns.isEmpty()) remove("warn") else putString("warn", warns.joinToString("\n")) }.apply()
        return if (bad == 0) null else "$bad J's klasöre yazılamadı"
    }
}
