package com.sneinle.client

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

object Theme {
    // Oyun ici panel (Frezie: koyu lacivert + elektrik mavisi)
    val G = 0xFF4DB8FF.toInt()
    val PINK = 0xFF1E6BFF.toInt()          // parlama rengi
    val PANEL = 0xF2060E24.toInt()
    val PANEL_SOLID = 0xFF060E24.toInt()
    val RAIL = 0xFF0A1630.toInt()
    val LIST = 0xFF081226.toInt()
    val CARD = 0xFF10234A.toInt()
    val SEL = 0xFF173A78.toInt()
    val EDGE = 0xFF2F8CFF.toInt()
    val TEXT = 0xFFF2F8FF.toInt()
    val MUTED = 0xFF8FB0D9.toInt()
    val BG_DARK = 0xFF040A1A.toInt()

    // Acilis ekrani
    val BLUE = 0xFF4DB8FF.toInt()
    val BLUE2 = 0xFF1E6BFF.toInt()
    val NAVY0 = 0xFF050B1E.toInt()
    val NAVY1 = 0xFF0B1F3F.toInt()
    val NAVY2 = 0xFF143E6B.toInt()
}

object UI {
    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun rect(c: Context, color: Int, rDp: Int, stroke: Int = 0, strokeDp: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color); cornerRadius = dp(c, rDp).toFloat()
            if (strokeDp > 0) setStroke(dp(c, strokeDp), stroke)
        }

    /** Neon çerçeve: dışta yumuşak parlama (glow), içte parlak ince çizgi. */
    fun neon(c: Context, fill: Int, rDp: Int, edge: Int = Theme.G, glow: Int = Theme.PINK, glowDp: Int = 4): LayerDrawable {
        fun a(col: Int, al: Int) = (col and 0x00FFFFFF) or (al shl 24)
        fun layer(color: Int, r: Float, stroke: Int, strokeCol: Int) = GradientDrawable().apply {
            setColor(color); cornerRadius = r; if (stroke > 0) setStroke(stroke, strokeCol)
        }
        val r = dp(c, rDp).toFloat(); val g = dp(c, glowDp)
        val ld = LayerDrawable(arrayOf(
            layer(0, r, g, a(glow, 0x2A)),
            layer(0, r - g / 3f, (g * 0.6f).toInt().coerceAtLeast(1), a(glow, 0x66)),
            layer(fill, r - g / 2f, dp(c, 1).coerceAtLeast(2), edge)))
        ld.setLayerInset(1, g / 3, g / 3, g / 3, g / 3)
        ld.setLayerInset(2, g / 2 + 1, g / 2 + 1, g / 2 + 1, g / 2 + 1)
        return ld
    }

    fun bg(c: Context) = GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Theme.NAVY0, Theme.NAVY1, Theme.NAVY2))

    fun clip(v: View, rDp: Int) {
        val r = rDp * v.resources.displayMetrics.density
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, r)
            }
        }
        v.clipToOutline = true
    }

    fun tintSwitch(s: Switch) {
        val st = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        s.thumbTintList = ColorStateList(st, intArrayOf(Theme.G, Theme.MUTED))
        s.trackTintList = ColorStateList(st, intArrayOf(Theme.EDGE, Theme.CARD))
    }

    /** Mavi sayfalar için düğme. */
    fun button(c: Context, text: String, onClick: () -> Unit): TextView = TextView(c).apply {
        this.text = text; textSize = 16f; typeface = Typeface.DEFAULT_BOLD
        setTextColor(Theme.NAVY0); gravity = Gravity.CENTER
        setPadding(dp(c, 14), dp(c, 13), dp(c, 14), dp(c, 13))
        background = rect(c, Theme.BLUE, 16)
        setOnClickListener { onClick() }
    }

    fun label(c: Context, text: String, sp: Float = 14f, color: Int = Color.WHITE): TextView = TextView(c).apply {
        this.text = text; textSize = sp; setTextColor(color)
    }

    fun blueSeek(c: Context, mx: Int, pr: Int, done: (Int) -> Unit): SeekBar = SeekBar(c).apply {
        this.max = mx; this.progress = pr
        progressTintList = ColorStateList.valueOf(Theme.BLUE)
        thumbTintList = ColorStateList.valueOf(Theme.BLUE)
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) {}
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) { done(s.progress) }
        })
    }
}

/** Arka plana açık mavi, Minecraft bloğu gibi kareler çizer. */
class BlocksView(c: Context) : View(c) {
    private val p = Paint()
    override fun onDraw(canvas: Canvas) {
        val rnd = java.util.Random(7)
        val d = resources.displayMetrics.density
        for (i in 0 until 80) {
            val s = (10 + rnd.nextInt(34)) * d
            val x = rnd.nextFloat() * width
            val y = (0.25f + rnd.nextFloat() * 0.75f) * height
            p.color = Color.argb(14 + rnd.nextInt(34), 127, 214, 255)
            canvas.drawRect(x, y, x + s, y + s, p)
        }
    }
}
