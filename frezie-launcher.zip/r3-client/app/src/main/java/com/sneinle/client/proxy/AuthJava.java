package com.sneinle.client.proxy;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.lenni0451.commons.httpclient.HttpClient;
import net.raphimc.minecraftauth.MinecraftAuth;
import net.raphimc.minecraftauth.bedrock.BedrockAuthManager;
import net.raphimc.minecraftauth.msa.model.MsaDeviceCode;
import net.raphimc.minecraftauth.msa.service.impl.DeviceCodeMsaAuthService;

import java.util.function.Consumer;

/**
 * MinecraftAuth 5.x cagrilari Java'da: README'deki "DeviceCodeMsaAuthService::new" metot referansinin
 * parametre sayisini bilmeden yazabilmek icin (Java cikarim yapar). Import yollari README/javadoc'tan tahmin edildi;
 * derleme hatasi verirse yalnizca bu dosyadaki import'lari duzeltmek yeterli.
 */
public final class AuthJava {
    private static HttpClient http;

    public static synchronized HttpClient http() {
        if (http == null) http = MinecraftAuth.createHttpClient("rlauncher/1.0");
        return http;
    }

    public static BedrockAuthManager login(Consumer<MsaDeviceCode> onCode) throws Exception {
        return BedrockAuthManager.create(http()).login(DeviceCodeMsaAuthService::new, onCode);
    }

    public static BedrockAuthManager restore(String json) throws Exception {
        JsonObject o = JsonParser.parseString(json).getAsJsonObject();
        return BedrockAuthManager.fromJson(http(), o);
    }

    public static String save(BedrockAuthManager m) {
        return BedrockAuthManager.toJson(m).toString();
    }
}
