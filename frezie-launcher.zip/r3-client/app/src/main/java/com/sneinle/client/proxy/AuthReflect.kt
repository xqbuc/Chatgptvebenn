package com.sneinle.client.proxy

/**
 * MinecraftAuth 5.x'in Bedrock getter adlari dokumanda yok. Burada isimle arayip bulunanlari ProxyState'e yazariz,
 * boylece ilk calistirmada log kutusunda gercek API adlari gorunur.
 */
object AuthReflect {
    fun methods(o: Any): List<java.lang.reflect.Method> =
        o.javaClass.methods.filter { it.parameterCount == 0 && it.declaringClass != Any::class.java && it.name != "getClass" }

    fun dump(label: String, o: Any?) {
        if (o == null) { ProxyState.log("$label: null"); return }
        ProxyState.log("$label (${o.javaClass.simpleName}): " +
            methods(o).joinToString(", ") { it.name + ":" + it.returnType.simpleName })
    }

    fun call(o: Any, name: String): Any? =
        methods(o).firstOrNull { it.name == name }?.invoke(o)

    /** Holder<T> gibi nesnelerden degeri alir (getUpToDate varsa o, yoksa get). */
    fun unwrap(o: Any?): Any? {
        if (o == null) return null
        val m = methods(o).firstOrNull { it.name == "getUpToDate" } ?: methods(o).firstOrNull { it.name == "get" }
        return if (m != null) m.invoke(o) else o
    }

    fun findGetter(o: Any, vararg parts: String): java.lang.reflect.Method? =
        methods(o).firstOrNull { m -> m.name.startsWith("get") && parts.all { m.name.contains(it, ignoreCase = true) } }
}
