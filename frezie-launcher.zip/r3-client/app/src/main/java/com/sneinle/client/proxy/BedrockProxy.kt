package com.sneinle.client.proxy

import android.content.Context
import io.netty.bootstrap.Bootstrap
import io.netty.bootstrap.ServerBootstrap
import io.netty.channel.Channel
import io.netty.channel.nio.NioEventLoopGroup
import io.netty.channel.socket.nio.NioDatagramChannel
import io.netty.util.ReferenceCountUtil
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.netty.channel.raknet.RakChannelFactory
import org.cloudburstmc.netty.channel.raknet.config.RakChannelOption
import org.cloudburstmc.protocol.bedrock.BedrockClientSession
import org.cloudburstmc.protocol.bedrock.BedrockPong
import org.cloudburstmc.protocol.bedrock.BedrockServerSession
import org.cloudburstmc.protocol.bedrock.BedrockSession
import org.cloudburstmc.protocol.bedrock.codec.BedrockCodec
import org.cloudburstmc.protocol.bedrock.data.PacketCompressionAlgorithm
import org.cloudburstmc.protocol.bedrock.data.definitions.BlockDefinition
import org.cloudburstmc.protocol.bedrock.data.definitions.ItemDefinition
import org.cloudburstmc.protocol.bedrock.netty.initializer.BedrockClientInitializer
import org.cloudburstmc.protocol.bedrock.netty.initializer.BedrockServerInitializer
import org.cloudburstmc.protocol.bedrock.packet.*
import org.cloudburstmc.protocol.bedrock.util.EncryptionUtils
import org.cloudburstmc.protocol.common.DefinitionRegistry
import org.cloudburstmc.protocol.common.PacketSignal
import org.cloudburstmc.protocol.common.SimpleDefinitionRegistry
import org.json.JSONObject
import java.net.InetSocketAddress
import java.security.KeyPair
import java.security.PublicKey
import java.util.Base64

/**
 * Yerel Bedrock proxy: Minecraft 127.0.0.1:PORT'a baglanir, biz gercek sunucuya Xbox hesabiyla baglaniriz.
 * Aradaki PlayerAuthInput paketleri JS modullerinden (JsHost) gecer.
 * NOT: Bu dosya CloudburstMC Protocol 3.0.0.Beta API'sine gore yazildi, derleme/test ortamim yoktu.
 */
class BedrockProxy(private val c: Context, private val js: JsHost) {
    private val group = NioEventLoopGroup()
    private var server: Channel? = null
    private val codec: BedrockCodec = findCodec()
    @Volatile var host = ""
    @Volatile var port = 19132

    private class BlockReg : DefinitionRegistry<BlockDefinition> {
        override fun getDefinition(runtimeId: Int): BlockDefinition = BlockDefinition { runtimeId }
        override fun isRegistered(definition: BlockDefinition): Boolean = true
    }

    companion object {
        /** Kutuphanedeki en yeni Bedrock_vNNN codec'ini bulur. */
        fun findCodec(): BedrockCodec {
            for (n in 1400 downTo 700) {
                try {
                    val k = Class.forName("org.cloudburstmc.protocol.bedrock.codec.v$n.Bedrock_v$n")
                    return k.getField("CODEC").get(null) as BedrockCodec
                } catch (_: ClassNotFoundException) {
                } catch (_: NoSuchFieldException) {
                }
            }
            error("Bedrock codec bulunamadi")
        }
    }

    /** Giris icin gereken anahtar + token/zincir. MinecraftAuth 5.x getter adlari belgelenmedigi icin isimle aranir. */
    class LoginInfo(val priv: java.security.PrivateKey, val pub: PublicKey, val token: String?, val chain: List<String>?)

    private fun discoverLogin(): LoginInfo {
        val m = XboxAuth.manager ?: error("Xbox girisi yok")
        var priv: java.security.PrivateKey? = null
        var pub: PublicKey? = null
        var token: String? = null
        var chain: List<String>? = null
        val roots = mutableListOf<Any>(m)
        for (g in AuthReflect.methods(m).filter { it.name.startsWith("get") && it.name.contains("Minecraft", true) }) {
            try { AuthReflect.unwrap(g.invoke(m))?.let { roots += it; AuthReflect.dump("auth:" + g.name, it) } } catch (e: Throwable) {
                ProxyState.log("auth getter ${g.name}: ${e.message}")
            }
        }
        for (o in roots) for (g in AuthReflect.methods(o)) {
            val v = try { g.invoke(o) } catch (e: Throwable) { null } ?: continue
            val u = AuthReflect.unwrap(v) ?: continue
            when {
                u is java.security.PrivateKey && priv == null -> priv = u
                u is PublicKey && pub == null -> pub = u
                u is KeyPair -> { if (priv == null) priv = u.private; if (pub == null) pub = u.public }
                u is String && g.name.contains("Token", true) && token == null && u.count { it == '.' } >= 2 -> token = u
                u is List<*> && g.name.contains("Chain", true) && chain == null && u.all { it is String } ->
                    chain = u.map { it as String }
            }
        }
        if (chain == null) {
            val mj = roots.firstNotNullOfOrNull { o -> AuthReflect.methods(o).firstOrNull { it.name == "getMojangJwt" }?.invoke(o) as? String }
            val id = roots.firstNotNullOfOrNull { o -> AuthReflect.methods(o).firstOrNull { it.name == "getIdentityJwt" }?.invoke(o) as? String }
            if (mj != null && id != null) chain = listOf(mj, id)
        }
        ProxyState.log("login bilgisi: anahtar=${priv != null && pub != null} token=${token != null} zincir=${chain != null}")
        if (priv == null || pub == null || (token == null && chain == null))
            error("MinecraftAuth login verisi bulunamadi; log'daki 'auth:' satirlarindaki metot listesini gelistiriciye ver")
        return LoginInfo(priv!!, pub!!, token, chain)
    }

    fun start(localPort: Int) {
        ProxyState.log("Codec: ${codec.minecraftVersion} (protokol ${codec.protocolVersion})")
        val pong = BedrockPong()
            .edition("MCPE").motd("Frezie").subMotd("Frezie Launcher")
            .playerCount(0).maximumPlayerCount(20).gameType("Survival")
            .protocolVersion(codec.protocolVersion).version(codec.minecraftVersion)
            .ipv4Port(localPort).ipv6Port(localPort).nintendoLimited(false)
        server = ServerBootstrap()
            .channelFactory(RakChannelFactory.server(NioDatagramChannel::class.java))
            .option(RakChannelOption.RAK_ADVERTISEMENT, pong.toByteBuf())
            .group(group)
            .childHandler(object : BedrockServerInitializer() {
                override fun initSession(session: BedrockServerSession) {
                    session.codec = codec
                    val link = Link(session)
                    session.packetHandler = link.localHandler
                    session.addDisconnectHandler { link.close("istemci cikti") }
                }
            })
            .bind(InetSocketAddress("0.0.0.0", localPort)).syncUninterruptibly().channel()
        ProxyState.log("Proxy dinliyor: 127.0.0.1:$localPort")
    }

    fun stop() {
        runCatching { server?.close()?.syncUninterruptibly() }
        runCatching { group.shutdownGracefully() }
    }

    private fun jwtKey(jwt: String): PublicKey =
        EncryptionUtils.parseKey(Jwt.header(jwt).getString("x5u"))

    private fun setDefs(s: BedrockSession, items: DefinitionRegistry<ItemDefinition>) {
        val h = s.peer.codecHelper
        h.itemDefinitions = items
        h.blockDefinitions = BlockReg()
    }

    inner class Link(val local: BedrockServerSession) {
        @Volatile var up: BedrockClientSession? = null
        @Volatile var ready = false
        @Volatile var closed = false
        private val queue = ArrayDeque<BedrockPacket>()
        var runtimeId = 0L
        var health = 20f
        var tick = 0
        var clientJwt = ""
        var th = ""
        var tp = 19132
        var li: LoginInfo? = null
        // BoatFly: binilen arac ve son uygulanan hareket
        var vehicleId = 0L
        var lastMx = 0f; var lastMy = 0f; var lastMz = 0f
        var lastMoveTick = -100

        val localHandler = object : BedrockPacketHandler {
            override fun handlePacket(packet: BedrockPacket): PacketSignal {
                try {
                    when (packet) {
                        is RequestNetworkSettingsPacket -> onNetworkSettings(packet)
                        is LoginPacket -> onLogin(packet)
                        is ClientToServerHandshakePacket -> {}
                        is PlayerAuthInputPacket -> { onAuthInput(packet); forwardUp(packet) }
                        is MoveActorAbsolutePacket -> { onVehicleMove(packet); forwardUp(packet) }
                        else -> forwardUp(packet)
                    }
                } catch (e: Throwable) {
                    ProxyState.log("yerel paket hatasi: ${e.javaClass.simpleName}: ${e.message}")
                }
                return PacketSignal.HANDLED
            }
        }

        private fun onNetworkSettings(p: RequestNetworkSettingsPacket) {
            if (p.protocolVersion != codec.protocolVersion) {
                ProxyState.log("Protokol uyusmuyor: istemci ${p.protocolVersion}, proxy ${codec.protocolVersion}")
                ProxyState.status = "Minecraft surumu proxy kutuphanesiyle uyusmuyor"
                val ps = PlayStatusPacket()
                ps.status = if (p.protocolVersion > codec.protocolVersion) PlayStatusPacket.Status.LOGIN_FAILED_SERVER_OLD
                else PlayStatusPacket.Status.LOGIN_FAILED_CLIENT_OLD
                local.sendPacketImmediately(ps)
                local.disconnect()
                return
            }
            val ns = NetworkSettingsPacket()
            ns.compressionThreshold = 0
            ns.compressionAlgorithm = PacketCompressionAlgorithm.ZLIB
            local.sendPacketImmediately(ns)
            local.setCompression(PacketCompressionAlgorithm.ZLIB)
        }

        private fun onLogin(p: LoginPacket) {
            clientJwt = p.clientJwt
            val clientKey = jwtKey(clientJwt)
            val kp: KeyPair = EncryptionUtils.createKeyPair()
            val token = EncryptionUtils.generateRandomToken()
            val hs = ServerToClientHandshakePacket()
            hs.jwt = EncryptionUtils.createHandshakeJwt(kp, token)
            local.sendPacketImmediately(hs)
            local.enableEncryption(EncryptionUtils.getSecretKey(kp.private, clientKey, token))
            ProxyState.status = "baglaniyor"
            Thread { connectUp() }.also { it.isDaemon = true }.start()
        }

        private fun connectUp() {
            if (XboxAuth.manager == null) { close("Xbox girisi yok"); return }
            try {
                li = discoverLogin()
                // Hedef her baglantida secili olandan okunur (baloncuktan degistirilebilir); realm ise anlik adres alinir.
                val sel = Targets.current(c).ifEmpty { "$host:$port" }
                if (sel.startsWith("realm:")) {
                    ProxyState.status = "realm adresi aliniyor"
                    val r = RealmsApi.join(sel.removePrefix("realm:"), codec.minecraftVersion)
                    th = r.first; tp = r.second
                } else {
                    th = sel.substringBeforeLast(':', sel)
                    tp = if (sel.contains(':')) sel.substringAfterLast(':').toIntOrNull() ?: 19132 else 19132
                }
                ProxyState.status = "baglaniyor: $th:$tp"
                ProxyState.log("Hedef: $th:$tp")
                val addr = InetSocketAddress(th, tp)
                Bootstrap()
                    .channelFactory(RakChannelFactory.client(NioDatagramChannel::class.java))
                    .group(group)
                    .option(RakChannelOption.RAK_PROTOCOL_VERSION, codec.raknetProtocolVersion)
                    .handler(object : BedrockClientInitializer() {
                        override fun initSession(session: BedrockClientSession) {
                            session.codec = codec
                            up = session
                            session.packetHandler = upHandler
                            session.addDisconnectHandler { close("sunucu baglantisi koptu") }
                        }
                    })
                    .connect(addr).syncUninterruptibly()
                val s = up ?: throw IllegalStateException("oturum acilmadi")
                val rq = RequestNetworkSettingsPacket()
                rq.protocolVersion = codec.protocolVersion
                s.sendPacketImmediately(rq)
            } catch (e: Throwable) {
                ProxyState.log("Sunucuya baglanilamadi: ${e.javaClass.simpleName}: ${e.message}")
                close("sunucuya baglanilamadi: ${e.message}")
            }
        }

        private fun sendLogin() {
            val l = li ?: return
            val pubB64 = Base64.getEncoder().encodeToString(l.pub.encoded)
            val cd = Jwt.payload(clientJwt)
            cd.put("ServerAddress", "$th:$tp")
            val newClientJwt = Jwt.sign(l.priv, pubB64, cd.toString())

            val lp = LoginPacket()
            lp.protocolVersion = codec.protocolVersion
            // AuthPayload: token tabanli (yeni) ya da sertifika zinciri (eski). Reflection: surumler arasi isim farkina dayanikli.
            val typeCls = Class.forName("org.cloudburstmc.protocol.bedrock.data.auth.AuthType")
            val full = typeCls.enumConstants.first { (it as Enum<*>).name == "FULL" }
            val payload = if (l.token != null) {
                Class.forName("org.cloudburstmc.protocol.bedrock.data.auth.TokenPayload")
                    .getConstructor(String::class.java, typeCls).newInstance(l.token, full)
            } else {
                Class.forName("org.cloudburstmc.protocol.bedrock.data.auth.CertificateChainPayload")
                    .getConstructor(List::class.java, typeCls).newInstance(l.chain, full)
            }
            LoginPacket::class.java.methods.first { it.name == "setAuthPayload" }.invoke(lp, payload)
            lp.clientJwt = newClientJwt
            up!!.sendPacketImmediately(lp)
        }

        val upHandler = object : BedrockPacketHandler {
            override fun handlePacket(packet: BedrockPacket): PacketSignal {
                try {
                    when (packet) {
                        is NetworkSettingsPacket -> {
                            up!!.setCompression(packet.compressionAlgorithm)
                            sendLogin()
                        }
                        is ServerToClientHandshakePacket -> {
                            val serverKey = jwtKey(packet.jwt)
                            val salt = Base64.getDecoder().decode(Jwt.payload(packet.jwt).getString("salt"))
                            val secret = EncryptionUtils.getSecretKey(li!!.priv, serverKey, salt)
                            up!!.enableEncryption(secret)
                            up!!.sendPacketImmediately(ClientToServerHandshakePacket())
                            markReady()
                        }
                        is StartGamePacket -> {
                            val reg = SimpleDefinitionRegistry.builder<ItemDefinition>()
                                .addAll(packet.itemDefinitions).build()
                            up?.let { setDefs(it, reg) }
                            setDefs(local, reg)
                            runtimeId = packet.runtimeEntityId
                            ProxyState.status = "bagli: $th:$tp"
                            forwardLocal(packet)
                        }
                        is SetEntityLinkPacket -> {
                            // Binme/inme: bu oyuncu (to) bir araca (from) bindiyse arac kimligini tut.
                            val l = packet.entityLink
                            if (l.to == runtimeId) vehicleId = if (l.type.name == "REMOVE") 0L else l.from
                            forwardLocal(packet)
                        }
                        is UpdateAttributesPacket -> {
                            if (packet.runtimeEntityId == runtimeId) {
                                packet.attributes.firstOrNull { it.name == "minecraft:health" }?.let { health = it.value }
                            }
                            forwardLocal(packet)
                        }
                        else -> { markReady(); forwardLocal(packet) }
                    }
                } catch (e: Throwable) {
                    ProxyState.log("sunucu paket hatasi: ${e.javaClass.simpleName}: ${e.message}")
                }
                return PacketSignal.HANDLED
            }
        }

        @Synchronized private fun markReady() {
            if (ready) return
            ready = true
            while (queue.isNotEmpty()) up?.sendPacket(queue.removeFirst())
        }

        @Synchronized fun forwardUp(p: BedrockPacket) {
            ReferenceCountUtil.retain(p)
            val s = up
            if (!ready || s == null) { queue.addLast(p); return }
            s.sendPacket(p)
        }

        fun forwardLocal(p: BedrockPacket) {
            ReferenceCountUtil.retain(p)
            local.sendPacket(p)
        }

        /** Istemcinin her PlayerAuthInput paketi: JS movement_tick'ten gecer, gerekirse konum degistirilir. */
        private fun onAuthInput(p: PlayerAuthInputPacket) {
            tick++
            if (tick % 20 == 0) js.refreshIfChanged()
            val pos = p.position
            val rot = p.rotation
            val mv = p.motion
            val d = p.delta ?: Vector3f.ZERO
            val flags = p.inputData.map { it.name }.toSet()
            val predicted = "IN_CLIENT_PREDICTED_VEHICLE" in flags
            if (predicted && vehicleId == 0L) runCatching {
                val id = PlayerAuthInputPacket::class.java.getMethod("getClientPredictedVehicle").invoke(p) as Long
                if (id != 0L) vehicleId = id
            }
            val riding = vehicleId != 0L || predicted
            val jumping = "JUMP_DOWN" in flags || "JUMPING" in flags || "ASCEND" in flags
            val sneaking = "SNEAK_DOWN" in flags || "SNEAKING" in flags || "DESCEND" in flags
            val st = JSONObject()
                .put("position", vec(pos.x, pos.y, pos.z))
                .put("motion", vec(d.x, d.y, d.z))
                .put("moveInput", JSONObject().put("x", mv.x.toDouble()).put("y", mv.y.toDouble()))
                .put("rotation", vec(rot.x, rot.y, rot.z))
                .put("onGround", false)
                .put("player", JSONObject()
                    .put("runtimeId", runtimeId).put("health", health.toDouble())
                    .put("position", vec(pos.x, pos.y, pos.z))
                    .put("rotation", vec(rot.x, rot.y, rot.z))
                    .put("isJumping", jumping).put("isSneaking", sneaking)
                    .put("isRiding", riding).put("vehicleRuntimeId", vehicleId))
                .toString()
            js.event("tick", st)
            val res = js.event("movement_tick", st) ?: return
            val m = res.optJSONObject("motion") ?: return
            val mx = m.optDouble("x").toFloat(); val my = m.optDouble("y").toFloat(); val mz = m.optDouble("z").toFloat()
            // Istemci kendi fizigini (yercekimi dahil) zaten uyguladi: onu cikarip istenen hareketi ekle.
            lastMx = mx; lastMy = my; lastMz = mz; lastMoveTick = tick
            val np = Vector3f.from(pos.x - d.x + mx, pos.y - d.y + my, pos.z - d.z + mz)
            p.position = np
            p.delta = Vector3f.from(mx, my, mz)
            val mp = MovePlayerPacket()
            mp.runtimeEntityId = runtimeId
            mp.position = np
            mp.rotation = rot
            mp.mode = MovePlayerPacket.Mode.NORMAL
            mp.isOnGround = false
            mp.ridingRuntimeEntityId = 0
            mp.tick = p.tick
            local.sendPacket(mp)
        }

        /** Binilen aracin (tekne) konum paketi: son hesaplanan hareketi ekleyip istemciye de geri yollar. */
        private fun onVehicleMove(p: MoveActorAbsolutePacket) {
            if (vehicleId == 0L || p.runtimeEntityId != vehicleId || tick - lastMoveTick > 2) return
            val o = p.position
            val np = Vector3f.from(o.x + lastMx, o.y + lastMy, o.z + lastMz)
            p.position = np
            val back = MoveActorAbsolutePacket()
            back.runtimeEntityId = vehicleId
            back.position = np
            back.rotation = p.rotation
            try {
                back.flags.addAll(p.flags)
                back.flags.add(MoveActorAbsolutePacket.Flag.valueOf("FORCE_MOVE_LOCAL_ENTITY"))
            } catch (e: Throwable) { ProxyState.log("arac bayragi: ${e.message}") }
            local.sendPacket(back)
        }

        private fun vec(x: Float, y: Float, z: Float) =
            JSONObject().put("x", x.toDouble()).put("y", y.toDouble()).put("z", z.toDouble())

        @Synchronized fun close(why: String) {
            if (closed) return
            closed = true
            ProxyState.log("Baglanti kapandi: $why")
            ProxyState.status = "hazir (bagli degil)"
            runCatching { up?.disconnect() }
            runCatching { local.disconnect(why) }
        }
    }
}
