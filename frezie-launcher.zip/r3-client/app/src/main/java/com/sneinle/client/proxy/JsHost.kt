package com.sneinle.client.proxy

import android.content.Context
import app.cash.quickjs.QuickJs
import com.sneinle.client.ScriptOpts
import com.sneinle.client.Store
import org.json.JSONObject

/** QuickJS'e giden/gelen yuzey: sadece String (JSON). */
interface JsApi {
    fun info(): String
    fun setEnabled(file: String, on: String): String
    fun event(name: String, json: String): String
    fun packet(name: String, json: String): String
}

/** J's modullerini kendi icimizde (ProtoHax'siz) calistirir. Tek thread'ten erisim: @Synchronized. */
class JsHost(private val c: Context) {
    private var qjs: QuickJs? = null
    private var api: JsApi? = null
    private var sig = ""
    private var enabledNow = emptySet<String>()
    private val importRe = Regex("""^\s*import\s*\{[^}]*\}\s*from\s*["']@protohax/userscript["'];?""", RegexOption.MULTILINE)

    private fun signature(): String {
        val all = Store.sp(c).all
        return all.filterKeys { it == "on" || it.startsWith("v:") }.toSortedMap().toString()
    }

    @Synchronized fun load() {
        close()
        val q = QuickJs.create()
        qjs = q
        q.evaluate(c.assets.open("runtime/prelude.js").bufferedReader().use { it.readText() }, "prelude.js")
        for (name in Store.scripts(c)) {
            try {
                val raw = Store.clean(Store.scriptText(c, name))
                val applied = Store.clean(ScriptOpts.apply(c, name, raw))
                val body = importRe.replace(applied, "")
                q.evaluate("__cur = ${JSONObject.quote(name)};", "cur.js")
                q.evaluate("(function(){\n$body\n})();", name)
            } catch (e: Throwable) {
                ProxyState.log("JS yuklenemedi $name: ${e.message}")
            }
        }
        api = q.get("api", JsApi::class.java)
        enabledNow = emptySet()
        applyEnabled()
        sig = signature()
        runCatching { ProxyState.log("JS moduller: " + api!!.info().take(300)) }
    }

    private fun applyEnabled() {
        val a = api ?: return
        val want = Store.scripts(c).filter { Store.enabled(c, it) }.toSet()
        for (n in Store.scripts(c)) {
            val on = n in want
            if (on != (n in enabledNow)) a.setEnabled(n, if (on) "1" else "0")
        }
        enabledNow = want
    }

    /** Ayar/acik-kapali degistiyse motoru bastan kurar. Her saniye civari cagrilir. */
    @Synchronized fun refreshIfChanged() {
        if (api == null) return
        val s = signature()
        if (s != sig) { ProxyState.log("JS ayarlari degisti, yeniden yukleniyor"); load() }
    }

    @Synchronized fun event(name: String, json: String): JSONObject? {
        val a = api ?: return null
        return try { JSONObject(a.event(name, json)) } catch (e: Throwable) { null }
    }

    @Synchronized fun packet(name: String, json: String): JSONObject? {
        val a = api ?: return null
        return try { JSONObject(a.packet(name, json)) } catch (e: Throwable) { null }
    }

    @Synchronized fun close() {
        runCatching { qjs?.close() }
        qjs = null; api = null
    }
}
