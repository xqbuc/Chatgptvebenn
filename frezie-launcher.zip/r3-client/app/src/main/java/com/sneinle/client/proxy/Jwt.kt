package com.sneinle.client.proxy

import org.json.JSONObject
import java.security.PrivateKey
import java.security.Signature
import java.util.Base64

/** Minik ES384 JWT yardimcisi (Bedrock login icin). */
object Jwt {
    private val enc = Base64.getUrlEncoder().withoutPadding()
    private val dec = Base64.getUrlDecoder()

    fun b64(b: ByteArray): String = enc.encodeToString(b)

    private fun pad(s: String): String = s.trimEnd('=')

    fun payload(jwt: String): JSONObject = JSONObject(String(dec.decode(pad(jwt.split(".")[1]))))
    fun header(jwt: String): JSONObject = JSONObject(String(dec.decode(pad(jwt.split(".")[0]))))

    /** x5u = X.509 public key (standart base64). */
    fun sign(priv: PrivateKey, pubB64: String, payloadJson: String): String {
        val h = JSONObject().put("alg", "ES384").put("x5u", pubB64).toString()
        val input = b64(h.toByteArray()) + "." + b64(payloadJson.toByteArray())
        val sig = Signature.getInstance("SHA384withECDSA")
        sig.initSign(priv)
        sig.update(input.toByteArray())
        return input + "." + b64(derToRaw(sig.sign(), 48))
    }

    private fun derToRaw(der: ByteArray, size: Int): ByteArray {
        var off = 2
        if ((der[1].toInt() and 0x80) != 0) off = 2 + (der[1].toInt() and 0x7f)
        fun readInt(): ByteArray {
            require(der[off] == 0x02.toByte()) { "bozuk imza" }
            val l = der[off + 1].toInt() and 0xff
            val v = der.copyOfRange(off + 2, off + 2 + l)
            off += 2 + l
            return v
        }
        val r = readInt(); val s = readInt()
        val out = ByteArray(size * 2)
        fun put(src: ByteArray, at: Int) {
            var st = 0
            while (st < src.size - 1 && src[st] == 0.toByte()) st++
            val len = src.size - st
            System.arraycopy(src, st, out, at + size - len, len)
        }
        put(r, 0); put(s, size)
        return out
    }
}
