package com.sneinle.client.proxy

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder

/** Proxy'yi arka planda calistirir (Minecraft'a gecince olmesin diye on plan servisi). */
class ProxyService : Service() {
    private var proxy: BedrockProxy? = null
    private var js: JsHost? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("rp", "Frezie proxy", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "rp").setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentTitle("Frezie proxy çalışıyor").build()
        startForeground(2, n)
        when (i?.action) {
            "STOP" -> { stopProxy(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
            else -> Thread { startProxy(i?.getStringExtra("host") ?: "", i?.getIntExtra("port", 19132) ?: 19132) }
                .also { it.isDaemon = true }.start()
        }
        return START_NOT_STICKY
    }

    @Synchronized private fun startProxy(host: String, port: Int) {
        stopProxy()
        try {
            ProxyState.status = "Xbox oturumu kontrol ediliyor"
            if (XboxAuth.session == null && !XboxAuth.restore(this)) {
                ProxyState.status = "Xbox girisi gerekli"
                return
            }
            val h = JsHost(this)
            h.load()
            val p = BedrockProxy(this, h)
            p.host = host; p.port = port
            p.start(LOCAL_PORT)
            js = h; proxy = p
            ProxyState.status = "hazir: Minecraft'ta 127.0.0.1:$LOCAL_PORT sunucusuna gir"
        } catch (e: Throwable) {
            ProxyState.log("Proxy baslatilamadi: ${e.javaClass.simpleName}: ${e.message}")
            ProxyState.status = "hata: ${e.message}"
        }
    }

    @Synchronized private fun stopProxy() {
        runCatching { proxy?.stop() }
        runCatching { js?.close() }
        proxy = null; js = null
        ProxyState.status = "kapali"
    }

    override fun onDestroy() { stopProxy(); super.onDestroy() }

    companion object {
        const val LOCAL_PORT = 19132
        fun start(c: Context, host: String, port: Int) {
            c.startForegroundService(Intent(c, ProxyService::class.java).putExtra("host", host).putExtra("port", port))
        }
        fun stop(c: Context) {
            c.startForegroundService(Intent(c, ProxyService::class.java).setAction("STOP"))
        }
    }
}
