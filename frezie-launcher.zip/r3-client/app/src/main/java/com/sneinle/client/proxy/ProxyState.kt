package com.sneinle.client.proxy

/** Proxy durumu ve kayitlar (ekranda gostermek icin). */
object ProxyState {
    @Volatile var status: String = "kapali"
    @Volatile var loginCode: String? = null
    @Volatile var loginUrl: String? = null
    @Volatile var account: String? = null
    private val lines = ArrayDeque<String>()

    @Synchronized fun log(s: String) {
        android.util.Log.i("r3proxy", s)
        lines.addLast(s)
        while (lines.size > 60) lines.removeFirst()
    }

    @Synchronized fun logText(): String = lines.joinToString("\n")
}
