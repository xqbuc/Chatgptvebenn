package com.sneinle.client.proxy

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Minecraft Bedrock Realms: liste ve baglanti adresi (Xbox oturumundaki realms XSTS ile). */
object RealmsApi {
    data class Realm(val id: Long, val name: String, val owner: String, val state: String, val expired: Boolean)

    private const val BASE = "https://pocket.realms.minecraft.net"

    private fun authHeader(): String {
        val m: Any = XboxAuth.manager ?: error("Xbox girisi yok")
        AuthReflect.dump("realms", m)
        val h = AuthReflect.methods(m).firstOrNull { it.name == "getRealmsXstsToken" }?.invoke(m)
            ?: error("Realms token yok (tekrar Xbox girisi yap)")
        val xsts: Any = AuthReflect.unwrap(h) ?: error("Realms token bos")
        AuthReflect.dump("realmsXsts", xsts)
        // Surumler arasi isim farki icin reflection.
        AuthReflect.methods(xsts).firstOrNull { it.name == "getAuthorizationHeader" }
            ?.let { return it.invoke(xsts) as String }
        val uh = AuthReflect.methods(xsts).first { it.name == "getUserHash" }.invoke(xsts)
        val tok = AuthReflect.methods(xsts).first { it.name == "getToken" }.invoke(xsts)
        return "XBL3.0 x=$uh;$tok"
    }

    private class HttpErr(val code: Int, msg: String) : Exception(msg)

    private fun get(path: String, version: String): String {
        val c = URL(BASE + path).openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 20000
        c.setRequestProperty("Authorization", authHeader())
        c.setRequestProperty("Client-Version", version)
        c.setRequestProperty("User-Agent", "MCPE/Android")
        c.setRequestProperty("Cache-Control", "no-cache")
        c.setRequestProperty("Accept", "*/*")
        val code = c.responseCode
        val body = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) throw HttpErr(code, "Realms HTTP $code ${body.take(120)}")
        return body
    }

    fun list(version: String): List<Realm> {
        val arr = JSONObject(get("/worlds", version)).optJSONArray("servers") ?: return emptyList()
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Realm(o.optLong("id"), o.optString("name", "Realm ${o.optLong("id")}"), o.optString("owner", ""),
                o.optString("state", ""), o.optBoolean("expired", false))
        }
    }

    /** Realm'in anlik adresi. Realm uyuyorsa (503) birkac kez bekleyip tekrar dener. */
    fun join(id: String, version: String): Pair<String, Int> {
        var last: Exception? = null
        repeat(8) {
            try {
                val addr = JSONObject(get("/worlds/$id/join", version)).getString("address")
                val h = addr.substringBeforeLast(':')
                val p = addr.substringAfterLast(':', "19132").toIntOrNull() ?: 19132
                return h to p
            } catch (e: HttpErr) {
                last = e
                if (e.code != 503 && e.code != 404) throw e
                Thread.sleep(2500)
            }
        }
        throw last ?: IllegalStateException("Realm adresi alinamadi")
    }
}
