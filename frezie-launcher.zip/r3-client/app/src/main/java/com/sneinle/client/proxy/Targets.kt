package com.sneinle.client.proxy

import android.content.Context
import com.sneinle.client.Store
import org.json.JSONArray
import org.json.JSONObject

/** Kayitli hedefler (sunucu adresleri ve realm'ler) ve secili hedef. addr: "host:port" ya da "realm:ID". */
object Targets {
    data class T(val name: String, val addr: String)

    fun list(c: Context): List<T> {
        val s = Store.sp(c).getString("px_servers", null) ?: return emptyList()
        return try {
            val a = JSONArray(s)
            (0 until a.length()).map { T(a.getJSONObject(it).getString("n"), a.getJSONObject(it).getString("a")) }
        } catch (e: Exception) { emptyList() }
    }

    private fun save(c: Context, l: List<T>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("n", it.name).put("a", it.addr)) }
        Store.sp(c).edit().putString("px_servers", a.toString()).apply()
    }

    fun add(c: Context, name: String, addr: String) {
        val l = list(c).filter { it.addr != addr } + T(name, addr)
        save(c, l)
    }

    fun remove(c: Context, addr: String) {
        save(c, list(c).filter { it.addr != addr })
        if (current(c) == addr) select(c, "")
    }

    fun current(c: Context): String = Store.sp(c).getString("px_target", "") ?: ""
    fun select(c: Context, addr: String) = Store.sp(c).edit().putString("px_target", addr).apply()

    fun label(c: Context, addr: String): String =
        list(c).firstOrNull { it.addr == addr }?.name ?: addr
}
