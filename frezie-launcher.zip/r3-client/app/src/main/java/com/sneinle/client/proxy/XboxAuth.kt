package com.sneinle.client.proxy

import android.content.Context
import net.raphimc.minecraftauth.bedrock.BedrockAuthManager
import java.io.File

/** Xbox/Microsoft device code girisi (MinecraftAuth 5.x BedrockAuthManager). Oturum filesDir'de saklanir. */
object XboxAuth {
    @Volatile var manager: BedrockAuthManager? = null
        private set

    /** Eski kodun "session != null" kontrolleri icin. */
    val session: BedrockAuthManager? get() = manager

    private fun file(c: Context) = File(c.filesDir, "xbox_session5.json")

    fun hasSaved(c: Context) = file(c).exists()

    private fun remember(c: Context, m: BedrockAuthManager) {
        manager = m
        file(c).writeText(AuthJava.save(m))
        ProxyState.account = "Xbox hesabi bagli"
        AuthReflect.dump("BedrockAuthManager", m)
    }

    /** Kayitli oturumu yukler. Basarisizsa false. Arka plan thread'inde cagir. */
    fun restore(c: Context): Boolean {
        return try {
            val f = file(c)
            if (!f.exists()) return false
            val m = AuthJava.restore(f.readText())
            // Suresi dolmussa yenile (getter adi surume gore degisebilir; yoksa getUpToDate ilk kullanimda yeniler).
            AuthReflect.findGetter(m, "Minecraft", "Token")?.let { g ->
                val h = g.invoke(m)
                AuthReflect.methods(h!!).firstOrNull { it.name == "refreshIfExpired" }?.invoke(h)
            }
            remember(c, m)
            true
        } catch (e: Throwable) {
            ProxyState.log("Xbox oturum yenilenemedi: ${e.javaClass.simpleName}: ${e.message}")
            false
        }
    }

    /** Device code girisi baslatir. onCode: (url, kod). Bitince onDone(hataMetni veya null). */
    fun login(c: Context, onCode: (String, String) -> Unit, onDone: (String?) -> Unit) {
        Thread {
            try {
                val m = AuthJava.login { dc ->
                    val url = dc.directVerificationUri ?: dc.verificationUri
                    ProxyState.loginUrl = url
                    ProxyState.loginCode = dc.userCode
                    onCode(url, dc.userCode)
                }
                remember(c, m)
                ProxyState.loginCode = null
                onDone(null)
            } catch (e: Throwable) {
                ProxyState.loginCode = null
                onDone("${e.javaClass.simpleName}: ${e.message}")
            }
        }.also { it.isDaemon = true }.start()
    }

    fun logout(c: Context) { manager = null; file(c).delete(); ProxyState.account = null }
}
