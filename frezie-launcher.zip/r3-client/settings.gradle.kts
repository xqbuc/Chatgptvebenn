pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement {
    repositories {
        google()
        mavenCentral()
        maven("https://repo.opencollab.dev/maven-releases/")
        maven("https://repo.opencollab.dev/maven-snapshots/")
        maven("https://maven.lenni0451.net/releases")
        maven("https://maven.lenni0451.net/everything")
    }
}
rootProject.name = "rlauncher"
include(":app")
